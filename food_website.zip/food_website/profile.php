<?php
/**
 * BHOJ HUB - Customer Profile & Settings Page
 */
require_once __DIR__ . '/config/helpers.php';
require_login();

$user = current_user();
$db = getDB();
$errors = [];

// Handle Profile Information Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = clean($_POST['name'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $city = clean($_POST['city'] ?? 'Kathmandu');

    if (empty($name)) $errors[] = 'Full Name is required.';
    if (empty($phone)) $errors[] = 'Phone Number is required.';

    if (empty($errors)) {
        $stmt = $db->prepare("UPDATE users SET name = ?, phone = ?, address = ?, city = ? WHERE id = ?");
        $stmt->execute([$name, $phone, $address, $city, $user['id']]);

        $_SESSION['user_name'] = $name;
        $_SESSION['user_phone'] = $phone;
        $_SESSION['user_address'] = $address;
        $_SESSION['user_city'] = $city;

        set_flash('success', 'Your profile details have been updated successfully!');
        header("Location: " . BASE_URL . "/profile.php");
        exit;
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPass = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_password'] ?? '';

    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $dbPass = $stmt->fetchColumn();

    if (!password_verify($currentPass, $dbPass)) {
        $errors[] = 'Current password is incorrect.';
    } elseif (strlen($newPass) < 6) {
        $errors[] = 'New password must be at least 6 characters long.';
    } elseif ($newPass !== $confirmPass) {
        $errors[] = 'New passwords do not match.';
    } else {
        $hashed = password_hash($newPass, PASSWORD_DEFAULT);
        $upd = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->execute([$hashed, $user['id']]);

        set_flash('success', 'Your password has been changed successfully!');
        header("Location: " . BASE_URL . "/profile.php");
        exit;
    }
}

$pageTitle = 'Manage Profile';
include __DIR__ . '/includes/header.php';
?>

<div class="container py-8">
    <div class="mb-6">
        <span class="badge badge-primary mb-2"><i class="fa-solid fa-user-gear"></i> Account Settings</span>
        <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--secondary);">Customer Profile</h1>
    </div>

    <?php if (!empty($errors)): ?>
        <div style="background: #fee2e2; border: 1px solid #f87171; color: #b91c1c; padding: 14px 18px; border-radius: var(--radius-md); margin-bottom: 24px;">
            <ul style="padding-left: 20px;">
                <?php foreach ($errors as $err): ?>
                    <li><?php echo htmlspecialchars($err); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-2 gap-8">
        <!-- Edit Personal Details -->
        <div class="cart-items-card">
            <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px;">
                <i class="fa-solid fa-address-card text-primary"></i> Personal Details & Address
            </h3>

            <form action="<?php echo BASE_URL; ?>/profile.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Email Address (Read-only)</label>
                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly style="background:#f1f5f9; cursor:not-allowed;">
                </div>

                <div class="form-group">
                    <label class="form-label">Contact Phone</label>
                    <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="form-group">
                        <label class="form-label">Default City / Area</label>
                        <select name="city" class="form-control">
                            <option value="Kathmandu" <?php echo ($user['city'] === 'Kathmandu') ? 'selected' : ''; ?>>Kathmandu</option>
                            <option value="Lalitpur" <?php echo ($user['city'] === 'Lalitpur') ? 'selected' : ''; ?>>Lalitpur</option>
                            <option value="Bhaktapur" <?php echo ($user['city'] === 'Bhaktapur') ? 'selected' : ''; ?>>Bhaktapur</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Street / Landmark Address</label>
                        <input type="text" name="address" class="form-control" placeholder="House/Street/Tole" value="<?php echo htmlspecialchars($user['address']); ?>">
                    </div>
                </div>

                <button type="submit" name="update_profile" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Save Profile Details
                </button>
            </form>
        </div>

        <!-- Change Password Card -->
        <div class="cart-summary-card">
            <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px;">
                <i class="fa-solid fa-key text-primary"></i> Change Password
            </h3>

            <form action="<?php echo BASE_URL; ?>/profile.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Current Password</label>
                    <input type="password" name="current_password" class="form-control" required placeholder="••••••••">
                </div>

                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input type="password" name="new_password" class="form-control" required minlength="6" placeholder="Min 6 characters">
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" required minlength="6" placeholder="Re-enter new password">
                </div>

                <button type="submit" name="change_password" class="btn btn-secondary btn-block">
                    <i class="fa-solid fa-lock"></i> Update Password
                </button>
            </form>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
