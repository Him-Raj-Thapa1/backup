</main>

<!-- Footer Component -->
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Brand Column -->
            <div>
                <div class="brand-logo" style="margin-bottom: 16px;">
                    <div class="logo-symbol">
                        <span>🥟</span>
                    </div>
                    <div class="logo-text-wrap">
                        <span class="logo-main" style="color:white;">BHOJ <span style="color:var(--primary);">HUB</span></span>
                        <span class="logo-sub" style="color:#94a3b8;">AUTHENTIC NEPALI CLOUD KITCHEN</span>
                    </div>
                </div>
                <p style="font-size: 0.9rem; line-height: 1.6; margin-bottom: 20px;">
                    Freshly cooked authentic Nepali feast, steaming dumplings, spicy Newari khaja, and mountain delicacies delivered piping hot straight from our cloud kitchen in Kathmandu.
                </p>
                <div style="display:flex; gap:12px; font-size:1.1rem;">
                    <a href="#" style="color:#cbd5e1; width:36px; height:36px; border-radius:50%; background:#1e293b; display:flex; align-items:center; justify-content:center;"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" style="color:#cbd5e1; width:36px; height:36px; border-radius:50%; background:#1e293b; display:flex; align-items:center; justify-content:center;"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" style="color:#cbd5e1; width:36px; height:36px; border-radius:50%; background:#1e293b; display:flex; align-items:center; justify-content:center;"><i class="fa-brands fa-tiktok"></i></a>
                </div>
            </div>

            <!-- Quick Links -->
            <div>
                <h4 class="footer-title">Quick Menu</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo BASE_URL; ?>/menu.php"><i class="fa-solid fa-angle-right" style="font-size:0.75rem; margin-right:6px; color:var(--primary);"></i> Full Cloud Kitchen Menu</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/menu.php?category=momo-dumplings"><i class="fa-solid fa-angle-right" style="font-size:0.75rem; margin-right:6px; color:var(--primary);"></i> Mo:Mo & Dumplings</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/menu.php?category=nepali-bhoj-thali"><i class="fa-solid fa-angle-right" style="font-size:0.75rem; margin-right:6px; color:var(--primary);"></i> Thakali & Nepali Bhoj</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/menu.php?category=sekuwa-grills"><i class="fa-solid fa-angle-right" style="font-size:0.75rem; margin-right:6px; color:var(--primary);"></i> Sekuwa & Grills</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/menu.php?category=khaja-fast-food"><i class="fa-solid fa-angle-right" style="font-size:0.75rem; margin-right:6px; color:var(--primary);"></i> Newari Khaja Sets</a></li>
                </ul>
            </div>

            <!-- Operating & Delivery Zones -->
            <div>
                <h4 class="footer-title">Kitchen & Delivery</h4>
                <ul class="footer-links" style="font-size:0.9rem;">
                    <li><i class="fa-solid fa-map-pin" style="color:var(--primary); margin-right:8px;"></i> <strong>Hub Location:</strong> Birendranagar, Chitwan</li>
                    <li><i class="fa-solid fa-truck-fast" style="color:var(--primary); margin-right:8px;"></i> <strong>Delivery Zones:</strong> Chitwan, Parsa &  Bharatpur</li>
                    <li><i class="fa-solid fa-clock" style="color:var(--primary); margin-right:8px;"></i> <strong>Kitchen Hours:</strong> 10:00 AM - 10:30 PM</li>
                    <li><i class="fa-solid fa-shield-check" style="color:var(--primary); margin-right:8px;"></i> 100% Hygienic Food Packaging</li>
                </ul>
            </div>

            <!-- Customer Service & Demo Payment -->
            <div>
                <h4 class="footer-title">Customer Help</h4>
                <p style="font-size:0.9rem; margin-bottom:12px;">Need assistance or bulk catering order?</p>
                <div style="background:#1e293b; padding:12px 16px; border-radius:8px; margin-bottom:16px;">
                    <div style="font-size:0.8rem; color:#94a3b8;">HOTLINE ORDERING</div>
                    <div style="font-size:1.15rem; font-weight:800; color:#fb923c;"><?php echo KITCHEN_PHONE; ?></div>
                </div>
                <div style="font-size:0.8rem; color:#94a3b8; margin-bottom:6px;">Accepted Demo Payment Methods:</div>
                <div style="display:flex; gap:10px; font-size:1.4rem; color:#cbd5e1;">
                    <span title="Cash on Delivery"><i class="fa-solid fa-money-bill-wave text-success"></i></span>
                    <span title="eSewa Digital Wallet"><i class="fa-solid fa-wallet text-success"></i></span>
                    <span title="Khalti Wallet"><i class="fa-solid fa-mobile-screen-button text-purple"></i></span>
                    <span title="Debit/Credit Card"><i class="fa-regular fa-credit-card text-info"></i></span>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div>
                &copy; <?php echo date('Y'); ?> <strong><?php echo APP_NAME; ?></strong>. All rights reserved. Built for BCA Cloud Kitchen Presentation.
            </div>
            <div style="display:flex; gap:20px;">
                <?php if (is_admin()): ?>
                    <a href="<?php echo BASE_URL; ?>/admin/index.php" style="color:var(--primary); font-weight:700;"><i class="fa-solid fa-gear"></i> Admin Dashboard</a>
                <?php endif; ?>
                <a href="<?php echo BASE_URL; ?>/database/setup.php" style="color:#64748b;" target="_blank"><i class="fa-solid fa-database"></i> Database Installer</a>
            </div>
        </div>
    </div>
</footer>

<!-- Main Scripts -->
<script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
