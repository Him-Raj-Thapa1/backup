<?php
/**
 * BHOJ HUB - Customer Header Component
 */
require_once __DIR__ . '/../config/helpers.php';
$cartCount = get_cart_count();
$user = current_user();
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . APP_NAME : APP_NAME . ' - ' . APP_TAGLINE; ?></title>
    <meta name="description" content="Order authentic Nepali Bhoj, Mo:Mo, Thakali Thali, Sekuwa and Kathmandu street snacks hot and fresh to your door in Kathmandu Valley.">
    
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    
    <script>
        window.APP_BASE_URL = "<?php echo BASE_URL; ?>";
        window.APP_CURRENCY = "<?php echo APP_CURRENCY; ?>";
    </script>
</head>
<body>

<!-- Header Top Bar -->
<div class="header-topbar">
    <div class="container flex justify-between items-center">
        <div class="flex items-center gap-4">
            <span class="topbar-badge"><i class="fa-solid fa-fire text-primary"></i> Live Kitchen</span>
            <span><i class="fa-solid fa-clock"></i> <?php echo KITCHEN_HOURS; ?></span>
            <span><i class="fa-solid fa-location-dot"></i> Express Delivery in Chitwan</span>
        </div>
        <div class="flex items-center gap-4">
            <a href="tel:<?php echo str_replace(' ', '', KITCHEN_PHONE); ?>"><i class="fa-solid fa-phone"></i> <?php echo KITCHEN_PHONE; ?></a>
            <?php if (is_admin()): ?>
                <a href="<?php echo BASE_URL; ?>/admin/index.php" style="color:#fb923c; font-weight:bold;"><i class="fa-solid fa-shield-halved"></i> Admin Portal</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Main Sticky Navigation -->
<header class="site-header">
    <div class="container">
        <nav class="navbar">
            <!-- Brand Logo -->
            <a href="<?php echo BASE_URL; ?>/index.php" class="brand-logo">
                <div class="logo-symbol">
                    <span>🥟</span>
                </div>
                <div class="logo-text-wrap">
                    <span class="logo-main">BHOJ <span>HUB</span></span>
                    <span class="logo-sub">NEPALI CLOUD KITCHEN</span>
                </div>
            </a>

            <!-- Navigation Links -->
            <ul class="nav-menu" id="nav-menu">
                <li><a href="<?php echo BASE_URL; ?>/index.php" class="nav-link <?php echo ($currentPage == 'index.php') ? 'active' : ''; ?>">Home</a></li>
                <li><a href="<?php echo BASE_URL; ?>/menu.php" class="nav-link <?php echo ($currentPage == 'menu.php') ? 'active' : ''; ?>">Browse Menu</a></li>
                <li><a href="<?php echo BASE_URL; ?>/menu.php?filter=featured" class="nav-link">Chef's Specials</a></li>
                <li><a href="<?php echo BASE_URL; ?>/menu.php?filter=veg" class="nav-link"><span class="diet-indicator veg" style="margin-right:4px;"></span> Pure Veg</a></li>
                <?php if (is_logged_in()): ?>
                    <li><a href="<?php echo BASE_URL; ?>/orders.php" class="nav-link <?php echo ($currentPage == 'orders.php' || $currentPage == 'order_details.php') ? 'active' : ''; ?>">My Orders</a></li>
                <?php endif; ?>
            </ul>

            <!-- Nav Action Buttons & Cart -->
            <div class="nav-actions">
                <!-- Cart Trigger Button -->
                <a href="<?php echo BASE_URL; ?>/cart.php" class="cart-trigger" id="cart-nav-btn" title="View Cart">
                    <i class="fa-solid fa-bag-shopping" style="font-size: 1.15rem;"></i>
                    <span style="font-size:0.9rem;">Cart</span>
                    <span class="cart-badge" id="nav-cart-badge"><?php echo $cartCount; ?></span>
                </a>

                <!-- User Profile / Auth State -->
                <?php if (is_logged_in()): ?>
                    <div class="user-dropdown">
                        <button class="user-btn" id="user-menu-btn" type="button">
                            <div class="user-avatar"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></div>
                            <span style="font-size:0.9rem; max-width: 105px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?php echo htmlspecialchars(explode(' ', $user['name'])[0]); ?>
                            </span>
                            <i class="fa-solid fa-chevron-down" style="font-size:0.75rem; color:#94a3b8;"></i>
                        </button>
                        <div class="dropdown-menu" id="user-dropdown-menu">
                            <div style="padding: 10px 18px 6px; border-bottom: 1px solid var(--border-light);">
                                <div style="font-weight:700; font-size:0.95rem;"><?php echo htmlspecialchars($user['name']); ?></div>
                                <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo htmlspecialchars($user['email']); ?></div>
                            </div>
                            <a href="<?php echo BASE_URL; ?>/orders.php" class="dropdown-item"><i class="fa-solid fa-receipt"></i> Order History</a>
                            <a href="<?php echo BASE_URL; ?>/profile.php" class="dropdown-item"><i class="fa-solid fa-user-pen"></i> Manage Profile</a>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo BASE_URL; ?>/logout.php" class="dropdown-item text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-outline btn-sm">Login</a>
                    <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-primary btn-sm">Register</a>
                <?php endif; ?>

                <!-- Mobile Menu Button -->
                <button class="mobile-toggle" id="mobile-nav-toggle" aria-label="Toggle Menu">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </div>
        </nav>
    </div>
</header>

<!-- Flash Alerts Toast Component -->
<?php
$flash = get_flash();
if ($flash):
?>
<div class="toast-container" id="toast-container">
    <div class="toast toast-<?php echo htmlspecialchars($flash['type']); ?>">
        <i class="fa-solid <?php echo ($flash['type'] === 'success') ? 'fa-circle-check text-success' : 'fa-circle-exclamation text-danger'; ?>"></i>
        <div style="flex:1; font-size:0.9rem; font-weight:500;"><?php echo htmlspecialchars($flash['message']); ?></div>
        <button style="background:none;border:none;color:#94a3b8;cursor:pointer;" onclick="this.parentElement.remove()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
</div>
<?php endif; ?>

<main>
