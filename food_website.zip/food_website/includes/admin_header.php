<?php
/**
 * BHOJ HUB - Admin Top Header Component
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$adminUser = current_user();

// Fetch live pending order count for notification badge
$db = getDB();
$pendingOrdersCount = $db->query("SELECT COUNT(*) FROM orders WHERE order_status = 'Pending'")->fetchColumn();
$lowStockCount = $db->query("SELECT COUNT(*) FROM foods WHERE stock <= 5")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | Admin - ' . APP_NAME : 'Admin Panel | ' . APP_NAME; ?></title>
    
    <!-- FontAwesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Design System CSS -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/admin.css">
    
    <script>
        window.APP_BASE_URL = "<?php echo BASE_URL; ?>";
        window.APP_CURRENCY = "<?php echo APP_CURRENCY; ?>";
    </script>
</head>
<body class="admin-layout">

<?php include __DIR__ . '/admin_sidebar.php'; ?>

<div class="admin-main">
    <header class="admin-topbar">
        <div class="topbar-left">
            <button class="mobile-toggle" id="admin-sidebar-toggle" title="Toggle Sidebar">
                <i class="fa-solid fa-bars"></i>
            </button>
            <h1 class="admin-page-title"><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Admin Dashboard'; ?></h1>
        </div>

        <div class="topbar-right">
            <!-- Kitchen Status -->
            <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.25); color: #34d399; padding: 6px 14px; border-radius: var(--radius-full); font-size: 0.82rem; font-weight: 700; display: flex; align-items: center; gap: 8px;">
                <i class="fa-solid fa-circle" style="font-size: 0.5rem; color: #10b981;"></i> Kitchen Operations Active
            </div>

            <!-- Admin Profile Indicator -->
            <div class="flex items-center gap-3">
                <div class="user-avatar" style="width:36px; height:36px; background:#ea580c;">
                    <i class="fa-solid fa-user-shield"></i>
                </div>
                <div style="font-size:0.85rem; line-height:1.2;">
                    <div style="font-weight:700; color:white;"><?php echo htmlspecialchars($adminUser['name']); ?></div>
                    <div style="color:#94a3b8; font-size:0.75rem;">Cloud Kitchen Admin</div>
                </div>
            </div>
        </div>
    </header>

    <!-- Flash Notifications for Admin -->
    <?php
    $flash = get_flash();
    if ($flash):
    ?>
    <div style="padding: 16px 28px 0;">
        <div class="toast toast-<?php echo htmlspecialchars($flash['type']); ?>" style="max-width:100%; animation:none;">
            <i class="fa-solid <?php echo ($flash['type'] === 'success') ? 'fa-circle-check text-success' : 'fa-circle-exclamation text-danger'; ?>"></i>
            <div style="flex:1; font-size:0.9rem; font-weight:600;"><?php echo htmlspecialchars($flash['message']); ?></div>
        </div>
    </div>
    <?php endif; ?>

    <div class="admin-container">
