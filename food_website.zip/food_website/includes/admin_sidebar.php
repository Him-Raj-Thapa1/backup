<?php
/**
 * BHOJ HUB - Admin Sidebar Navigation
 */
$adminCurrentPage = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
    <div class="sidebar-brand">
        <div class="logo-symbol">
            <span>🥟</span>
        </div>
        <div class="logo-text-wrap">
            <span class="logo-main" style="color:white; font-size:1.15rem;">BHOJ <span style="color:var(--primary);">HUB</span></span>
            <span class="logo-sub" style="color:#94a3b8; font-size:0.65rem;">KITCHEN CONTROL</span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-label">Overview</div>
        <a href="<?php echo BASE_URL; ?>/admin/index.php" class="sidebar-link <?php echo ($adminCurrentPage == 'index.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-pie"></i>
            <span>Dashboard</span>
        </a>

        <div class="nav-section-label">Order Management</div>
        <a href="<?php echo BASE_URL; ?>/admin/orders.php" class="sidebar-link <?php echo ($adminCurrentPage == 'orders.php' || $adminCurrentPage == 'order_view.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-receipt"></i>
            <span>Customer Orders</span>
            <?php if (!empty($pendingOrdersCount) && $pendingOrdersCount > 0): ?>
                <span class="sidebar-badge" title="<?php echo $pendingOrdersCount; ?> Pending Orders"><?php echo $pendingOrdersCount; ?></span>
            <?php endif; ?>
        </a>

        <div class="nav-section-label">Kitchen & Menu</div>
        <a href="<?php echo BASE_URL; ?>/admin/foods.php" class="sidebar-link <?php echo ($adminCurrentPage == 'foods.php' || $adminCurrentPage == 'food_edit.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-utensils"></i>
            <span>Food Inventory</span>
            <?php if (!empty($lowStockCount) && $lowStockCount > 0): ?>
                <span class="sidebar-badge" style="background:#f59e0b;" title="<?php echo $lowStockCount; ?> items low on stock"><?php echo $lowStockCount; ?> low</span>
            <?php endif; ?>
        </a>
        <a href="<?php echo BASE_URL; ?>/admin/food_add.php" class="sidebar-link <?php echo ($adminCurrentPage == 'food_add.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-circle-plus"></i>
            <span>Add New Dish</span>
        </a>
        <a href="<?php echo BASE_URL; ?>/admin/categories.php" class="sidebar-link <?php echo ($adminCurrentPage == 'categories.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-layer-group"></i>
            <span>Categories</span>
        </a>

        <div class="nav-section-label">Administration</div>
        <a href="<?php echo BASE_URL; ?>/admin/users.php" class="sidebar-link <?php echo ($adminCurrentPage == 'users.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-users"></i>
            <span>Customers</span>
        </a>
        <a href="<?php echo BASE_URL; ?>/admin/profile.php" class="sidebar-link <?php echo ($adminCurrentPage == 'profile.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-user-gear"></i>
            <span>Admin Settings</span>
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="<?php echo BASE_URL; ?>/admin/logout.php" class="sidebar-link" style="color:#ef4444;">
            <i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout Admin</span>
        </a>
    </div>
</aside>
