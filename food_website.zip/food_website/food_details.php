<?php
/**
 * BHOJ HUB - Single Food Item Detail Page
 */
require_once __DIR__ . '/config/helpers.php';

$foodId = (int)($_GET['id'] ?? 0);
if ($foodId <= 0) {
    header("Location: " . BASE_URL . "/menu.php");
    exit;
}

$db = getDB();

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    if (!is_logged_in()) {
        set_flash('warning', 'Please log in to submit a review.');
        header("Location: " . BASE_URL . "/login.php?redirect=" . urlencode("food_details.php?id={$foodId}"));
        exit;
    }

    $rating = (int)($_POST['rating'] ?? 5);
    $comment = clean($_POST['comment'] ?? '');
    $userId = $_SESSION['user_id'];

    if ($rating >= 1 && $rating <= 5 && !empty($comment)) {
        $stmt = $db->prepare("INSERT INTO reviews (user_id, food_id, rating, comment) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $foodId, $rating, $comment]);
        set_flash('success', 'Thank you! Your review has been published.');
        header("Location: " . BASE_URL . "/food_details.php?id={$foodId}");
        exit;
    } else {
        set_flash('error', 'Please provide a valid rating and review comment.');
    }
}

// Fetch food details
$stmt = $db->prepare("
    SELECT f.*, c.name AS category_name, c.slug AS category_slug 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.id = ?
");
$stmt->execute([$foodId]);
$food = $stmt->fetch();

if (!$food) {
    set_flash('error', 'Food item not found.');
    header("Location: " . BASE_URL . "/menu.php");
    exit;
}

$pageTitle = $food['name'];
$isInStock = (int)$food['stock'] > 0 && $food['is_available'];
$hasDiscount = !empty($food['discount_price']) && $food['discount_price'] > 0;
$activePrice = $hasDiscount ? $food['discount_price'] : $food['price'];

// Fetch reviews for this food
$revStmt = $db->prepare("
    SELECT r.*, u.name AS user_name 
    FROM reviews r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.food_id = ? 
    ORDER BY r.created_at DESC
");
$revStmt->execute([$foodId]);
$reviews = $revStmt->fetchAll();

// Calculate average rating
$avgRating = 5.0;
if (count($reviews) > 0) {
    $sum = array_sum(array_column($reviews, 'rating'));
    $avgRating = round($sum / count($reviews), 1);
}

// Fetch related items from the same category
$relStmt = $db->prepare("
    SELECT f.*, c.name AS category_name 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.category_id = ? AND f.id != ? AND f.is_available = 1 
    LIMIT 4
");
$relStmt->execute([$food['category_id'], $foodId]);
$relatedFoods = $relStmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="container py-8">
    <!-- Breadcrumb -->
    <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 20px;">
        <a href="<?php echo BASE_URL; ?>/index.php">Home</a> &gt; 
        <a href="<?php echo BASE_URL; ?>/menu.php">Menu</a> &gt; 
        <a href="<?php echo BASE_URL; ?>/menu.php?category=<?php echo urlencode($food['category_slug']); ?>"><?php echo htmlspecialchars($food['category_name']); ?></a> &gt; 
        <span style="color: var(--secondary); font-weight: 600;"><?php echo htmlspecialchars($food['name']); ?></span>
    </div>

    <!-- Main Detail Showcase Card -->
    <div class="food-detail-wrapper">
        <div class="food-detail-grid">
            <!-- Left Column: Image & Badges -->
            <div>
                <div class="food-detail-image-box">
                    <img src="<?php echo food_image($food['image']); ?>" alt="<?php echo htmlspecialchars($food['name']); ?>">
                </div>
            </div>

            <!-- Right Column: Food Specs & Action -->
            <div>
                <div class="flex items-center gap-3 mb-2">
                    <span class="diet-indicator <?php echo $food['is_veg'] ? 'veg' : 'non-veg'; ?>" title="<?php echo $food['is_veg'] ? 'Pure Veg' : 'Non-Veg'; ?>"></span>
                    <span class="badge badge-primary"><?php echo htmlspecialchars($food['category_name']); ?></span>
                    <?php if ($hasDiscount): ?>
                        <span class="badge badge-danger">SAVE <?php echo format_price($food['price'] - $food['discount_price']); ?></span>
                    <?php endif; ?>
                </div>

                <h1 class="food-detail-title"><?php echo htmlspecialchars($food['name']); ?></h1>
                <?php if (!empty($food['nepali_name'])): ?>
                    <div class="food-detail-nepali"><?php echo htmlspecialchars($food['nepali_name']); ?></div>
                <?php endif; ?>

                <!-- Ratings & Reviews Summary -->
                <div class="flex items-center gap-2 mb-4" style="font-size: 0.9rem;">
                    <div style="color: #f59e0b;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fa-<?php echo ($i <= round($avgRating)) ? 'solid' : 'regular'; ?> fa-star"></i>
                        <?php endfor; ?>
                    </div>
                    <span style="font-weight: 700; color: var(--secondary);"><?php echo $avgRating; ?></span>
                    <span style="color: var(--text-muted);">(<?php echo count($reviews); ?> Customer Reviews)</span>
                </div>

                <!-- Price Tag -->
                <div class="food-detail-price">
                    <span><?php echo format_price($activePrice); ?></span>
                    <?php if ($hasDiscount): ?>
                        <span class="original-price" style="font-size: 1.15rem; color: #94a3b8;"><?php echo format_price($food['price']); ?></span>
                    <?php endif; ?>
                </div>

                <!-- Description -->
                <p class="food-detail-desc">
                    <?php echo nl2br(htmlspecialchars($food['description'])); ?>
                </p>

                <!-- Key Attributes -->
                <div class="grid grid-cols-2 gap-4 mb-6" style="background: var(--bg-subtle); padding: 16px 20px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Prep & Cook Time</div>
                        <div style="font-weight: 700; color: var(--secondary);"><i class="fa-regular fa-clock text-primary"></i> <?php echo htmlspecialchars($food['prep_time']); ?></div>
                    </div>
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Spiciness Level</div>
                        <div style="font-weight: 700; color: var(--secondary);">
                            <i class="fa-solid fa-pepper-hot" style="color: <?php echo ($food['spicy_level'] > 1) ? 'var(--primary)' : '#94a3b8'; ?>;"></i>
                            <?php 
                            $spicyLabels = [0 => 'Mild', 1 => 'Medium', 2 => 'Spicy', 3 => 'Fiery Hot'];
                            echo $spicyLabels[$food['spicy_level']] ?? 'Medium';
                            ?>
                        </div>
                    </div>
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Stock Availability</div>
                        <div style="font-weight: 700;">
                            <?php if ($isInStock): ?>
                                <span class="text-success"><i class="fa-solid fa-circle-check"></i> In Stock (<?php echo $food['stock']; ?> available)</span>
                            <?php else: ?>
                                <span class="text-danger"><i class="fa-solid fa-circle-xmark"></i> Currently Out of Stock</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div>
                        <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Dietary Info</div>
                        <div style="font-weight: 700; color: var(--secondary);">
                            <?php echo $food['is_veg'] ? '🌱 100% Vegetarian' : '🍗 Non-Vegetarian'; ?>
                        </div>
                    </div>
                </div>

                <!-- Add to Cart Form Section -->
                <?php if ($isInStock): ?>
                    <div class="flex items-center gap-4 flex-wrap">
                        <div class="qty-control">
                            <button type="button" class="qty-btn qty-adjust-btn" data-action="dec" data-food-id="<?php echo $food['id']; ?>">-</button>
                            <input type="text" id="food-detail-qty" class="qty-val qty-input-<?php echo $food['id']; ?> qty-val-<?php echo $food['id']; ?>" value="1" readonly>
                            <button type="button" class="qty-btn qty-adjust-btn" data-action="inc" data-food-id="<?php echo $food['id']; ?>">+</button>
                        </div>

                        <button class="btn btn-primary btn-lg btn-add-to-cart" data-food-id="<?php echo $food['id']; ?>" style="flex: 1; min-width: 200px;">
                            <i class="fa-solid fa-bag-shopping"></i> Add to Order Tray
                        </button>
                    </div>
                <?php else: ?>
                    <div class="badge badge-danger" style="padding: 12px 20px; font-size: 0.95rem; width: 100%; justify-content: center;">
                        <i class="fa-solid fa-ban"></i> This dish is temporarily sold out for today.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Reviews Section -->
    <div class="grid grid-cols-2 gap-8 mt-8">
        <!-- Customer Feedback List -->
        <div class="cart-items-card">
            <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px;">
                Customer Reviews (<?php echo count($reviews); ?>)
            </h3>

            <?php if (empty($reviews)): ?>
                <p style="color: var(--text-muted); font-style: italic;">No reviews yet for this dish. Be the first to try it and share your feedback!</p>
            <?php else: ?>
                <div style="display: flex; flex-direction: column; gap: 16px;">
                    <?php foreach ($reviews as $rev): ?>
                        <div style="padding: 16px; background: var(--bg-subtle); border-radius: var(--radius-md); border: 1px solid var(--border-light);">
                            <div class="flex justify-between items-center mb-2">
                                <div style="font-weight: 700; color: var(--secondary); font-size: 0.95rem;">
                                    <?php echo htmlspecialchars($rev['user_name']); ?>
                                </div>
                                <div style="color: #f59e0b; font-size: 0.85rem;">
                                    <?php for ($i = 0; $i < $rev['rating']; $i++): ?>
                                        <i class="fa-solid fa-star"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p style="color: #475569; font-size: 0.9rem; line-height: 1.5;">
                                "<?php echo htmlspecialchars($rev['comment']); ?>"
                            </p>
                            <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 8px;">
                                <?php echo date('M d, Y', strtotime($rev['created_at'])); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Write a Review Box -->
        <div class="cart-summary-card">
            <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--secondary); margin-bottom: 12px;">
                Share Your Food Experience
            </h3>
            <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 20px;">
                Help fellow food lovers discover the best flavors from Bhoj Hub.
            </p>

            <?php if (is_logged_in()): ?>
                <form action="<?php echo BASE_URL; ?>/food_details.php?id=<?php echo $food['id']; ?>" method="POST">
                    <div class="form-group">
                        <label class="form-label">Your Star Rating</label>
                        <select name="rating" class="form-control" required>
                            <option value="5">⭐⭐⭐⭐⭐ (5/5) Outstanding & Delicious</option>
                            <option value="4">⭐⭐⭐⭐ (4/5) Very Good</option>
                            <option value="3">⭐⭐⭐ (3/5) Average</option>
                            <option value="2">⭐⭐ (2/5) Below Expectations</option>
                            <option value="1">⭐ (1/5) Poor</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Your Review / Comments</label>
                        <textarea name="comment" class="form-control" placeholder="What did you love about this dish? (e.g. flavor, spiciness, portion size)" required></textarea>
                    </div>

                    <button type="submit" name="submit_review" class="btn btn-primary btn-block">
                        <i class="fa-solid fa-paper-plane"></i> Submit Review
                    </button>
                </form>
            <?php else: ?>
                <div style="text-align: center; padding: 24px 0;">
                    <p style="color: var(--text-muted); margin-bottom: 16px;">Please login to submit your review for this dish.</p>
                    <a href="<?php echo BASE_URL; ?>/login.php?redirect=<?php echo urlencode("food_details.php?id={$foodId}"); ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fa-solid fa-right-to-bracket"></i> Login to Review
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Related Foods Grid -->
    <?php if (!empty($relatedFoods)): ?>
        <div class="mt-12">
            <div class="section-header">
                <div>
                    <span class="badge badge-primary mb-2">More from this Category</span>
                    <h2 class="section-title">You Might Also Like</h2>
                </div>
            </div>

            <div class="food-grid">
                <?php foreach ($relatedFoods as $relFood): ?>
                    <?php
                    $relInStock = (int)$relFood['stock'] > 0;
                    $relPrice = (!empty($relFood['discount_price']) && $relFood['discount_price'] > 0) ? $relFood['discount_price'] : $relFood['price'];
                    ?>
                    <div class="food-card">
                        <div class="food-image-container" style="height: 160px;">
                            <img src="<?php echo food_image($relFood['image']); ?>" alt="<?php echo htmlspecialchars($relFood['name']); ?>">
                            <div class="food-badge-top-left">
                                <span class="diet-indicator <?php echo $relFood['is_veg'] ? 'veg' : 'non-veg'; ?>"></span>
                            </div>
                        </div>
                        <div class="food-card-body" style="padding: 14px;">
                            <h4 class="food-title" style="font-size: 1rem;">
                                <a href="<?php echo BASE_URL; ?>/food_details.php?id=<?php echo $relFood['id']; ?>">
                                    <?php echo htmlspecialchars($relFood['name']); ?>
                                </a>
                            </h4>
                            <div class="food-footer mt-2">
                                <span class="current-price" style="font-size: 1.05rem;"><?php echo format_price($relPrice); ?></span>
                                <?php if ($relInStock): ?>
                                    <button class="btn btn-primary btn-sm btn-add-to-cart" data-food-id="<?php echo $relFood['id']; ?>">
                                        <i class="fa-solid fa-plus"></i> Add
                                    </button>
                                <?php else: ?>
                                    <span class="badge badge-danger">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
