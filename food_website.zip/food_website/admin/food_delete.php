<?php
/**
 * BHOJ HUB - Delete Food Item Handler (Admin)
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$foodId = (int)($_GET['id'] ?? 0);
if ($foodId <= 0) {
    header("Location: " . BASE_URL . "/admin/foods.php");
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT name FROM foods WHERE id = ?");
$stmt->execute([$foodId]);
$name = $stmt->fetchColumn();

if ($name) {
    $del = $db->prepare("DELETE FROM foods WHERE id = ?");
    $del->execute([$foodId]);
    set_flash('success', "Food item '{$name}' has been deleted from the system.");
} else {
    set_flash('error', 'Food item not found.');
}

header("Location: " . BASE_URL . "/admin/foods.php");
exit;
