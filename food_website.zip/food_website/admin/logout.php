<?php
/**
 * BHOJ HUB - Admin Logout Handler
 */
require_once __DIR__ . '/../config/helpers.php';

unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);
unset($_SESSION['user_phone']);
unset($_SESSION['user_address']);
unset($_SESSION['user_city']);
unset($_SESSION['user_role']);

set_flash('info', 'Admin session logged out successfully.');
header("Location: " . BASE_URL . "/login.php?type=admin");
exit;
