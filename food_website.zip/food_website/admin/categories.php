<?php
/**
 * BHOJ HUB - Category Management (Admin CRUD)
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Category Management';
$db = getDB();
$errors = [];

// Handle Add Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = clean($_POST['name'] ?? '');
    $nepaliName = clean($_POST['nepali_name'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $icon = clean($_POST['icon'] ?? 'fa-utensils');
    $sortOrder = (int)($_POST['sort_order'] ?? 0);

    if (empty($name)) {
        $errors[] = 'Category Name is required.';
    } else {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
        $check = $db->prepare("SELECT id FROM categories WHERE slug = ?");
        $check->execute([$slug]);
        if ($check->fetch()) {
            $slug .= '-' . time();
        }

        $stmt = $db->prepare("INSERT INTO categories (name, nepali_name, slug, description, icon, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([$name, $nepaliName, $slug, $description, $icon, $sortOrder]);

        set_flash('success', "Category '{$name}' created successfully!");
        header("Location: " . BASE_URL . "/admin/categories.php");
        exit;
    }
}

// Handle Edit Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_category'])) {
    $catId = (int)$_POST['category_id'];
    $name = clean($_POST['name'] ?? '');
    $nepaliName = clean($_POST['nepali_name'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $icon = clean($_POST['icon'] ?? 'fa-utensils');
    $sortOrder = (int)($_POST['sort_order'] ?? 0);
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if (empty($name)) {
        $errors[] = 'Category Name is required.';
    } else {
        $stmt = $db->prepare("UPDATE categories SET name = ?, nepali_name = ?, description = ?, icon = ?, sort_order = ?, is_active = ? WHERE id = ?");
        $stmt->execute([$name, $nepaliName, $description, $icon, $sortOrder, $isActive, $catId]);

        set_flash('success', "Category '{$name}' updated successfully.");
        header("Location: " . BASE_URL . "/admin/categories.php");
        exit;
    }
}

// Handle Delete Category
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $delStmt = $db->prepare("DELETE FROM categories WHERE id = ?");
    $delStmt->execute([$delId]);

    set_flash('success', 'Category removed from system.');
    header("Location: " . BASE_URL . "/admin/categories.php");
    exit;
}

// Fetch all categories with food count
$categories = $db->query("
    SELECT c.*, COUNT(f.id) as food_count 
    FROM categories c 
    LEFT JOIN foods f ON c.id = f.category_id 
    GROUP BY c.id 
    ORDER BY c.sort_order ASC, c.id ASC
")->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Menu Categories</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">Organize dishes into browsing sections (Mo:Mo, Thali, Sekuwa, Snacks, etc.)</p>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div style="background: #7f1d1d; border: 1px solid #dc2626; color: #fca5a5; padding: 14px 18px; border-radius: var(--radius-md); margin-bottom: 24px;">
        <ul style="padding-left: 20px;">
            <?php foreach ($errors as $err): ?>
                <li><?php echo htmlspecialchars($err); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="grid grid-cols-2 gap-8">
    <!-- Existing Categories List -->
    <div class="admin-card">
        <div class="admin-card-header">
            <div class="admin-card-title">
                <i class="fa-solid fa-layer-group text-primary"></i> Categories (<?php echo count($categories); ?>)
            </div>
        </div>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Icon & Name</th>
                        <th>Nepali Name</th>
                        <th>Dishes</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <div style="width: 36px; height: 36px; border-radius: 50%; background: #1e293b; color: #fb923c; display: flex; align-items: center; justify-content: center;">
                                        <i class="fa-solid <?php echo htmlspecialchars($cat['icon'] ?: 'fa-utensils'); ?>"></i>
                                    </div>
                                    <div>
                                        <div style="font-weight: 700; color: white;"><?php echo htmlspecialchars($cat['name']); ?></div>
                                        <div style="font-size: 0.75rem; color: #64748b;">slug: <?php echo htmlspecialchars($cat['slug']); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td style="color: #cbd5e1;"><?php echo htmlspecialchars($cat['nepali_name'] ?: '-'); ?></td>
                            <td>
                                <span class="badge badge-dark"><?php echo $cat['food_count']; ?> dishes</span>
                            </td>
                            <td>
                                <?php if ($cat['is_active']): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Hidden</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="flex gap-2">
                                    <a href="<?php echo BASE_URL; ?>/admin/categories.php?delete=<?php echo $cat['id']; ?>" class="btn btn-outline btn-sm" style="color: #ef4444;" onclick="return confirm('Delete this category? Dishes inside this category will also be removed!');">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create New Category Form -->
    <div class="admin-card" style="padding: 24px;">
        <div class="admin-card-title mb-4" style="font-size: 1.15rem; font-weight: 800; color: white;">
            <i class="fa-solid fa-circle-plus text-primary"></i> Add New Category
        </div>

        <form action="<?php echo BASE_URL; ?>/admin/categories.php" method="POST">
            <div class="admin-form-group">
                <label class="admin-form-label">Category Name (English) *</label>
                <input type="text" name="name" class="admin-form-control" placeholder="e.g. Traditional Nepali Khaja" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">Nepali Name / Translation</label>
                <input type="text" name="nepali_name" class="admin-form-control" placeholder="e.g. परम्परागत नेपाली खाजा">
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="admin-form-group">
                    <label class="admin-form-label">FontAwesome Icon Class</label>
                    <input type="text" name="icon" class="admin-form-control" value="fa-utensils" placeholder="e.g. fa-bowl-food">
                </div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Sort Order Index</label>
                    <input type="number" name="sort_order" class="admin-form-control" value="10">
                </div>
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">Description</label>
                <textarea name="description" class="admin-form-control" rows="3" placeholder="Brief description of this food category..."></textarea>
            </div>

            <button type="submit" name="add_category" class="btn btn-primary btn-block btn-lg mt-4">
                <i class="fa-solid fa-plus"></i> Save Category
            </button>
        </form>
    </div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
