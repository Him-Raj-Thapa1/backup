<?php
/**
 * BHOJ HUB - Unified Admin Login
 * Redirects to the single common BHOJ HUB login page
 */
require_once __DIR__ . '/../config/helpers.php';

if (is_admin()) {
    header("Location: " . BASE_URL . "/admin/index.php");
    exit;
}

header("Location: " . BASE_URL . "/login.php?type=admin");
exit;
