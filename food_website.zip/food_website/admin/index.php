<?php
/**
 * BHOJ HUB - Admin Dashboard Overview
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Kitchen Operations Dashboard';
$db = getDB();

// 1. KPI Metrics
$totalRevenue = $db->query("SELECT COALESCE(SUM(grand_total), 0) FROM orders WHERE order_status != 'Cancelled'")->fetchColumn();
$totalOrders = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$activeOrders = $db->query("SELECT COUNT(*) FROM orders WHERE order_status NOT IN ('Delivered', 'Cancelled')")->fetchColumn();
$totalFoods = $db->query("SELECT COUNT(*) FROM foods")->fetchColumn();
$lowStockFoods = $db->query("SELECT COUNT(*) FROM foods WHERE stock <= 5")->fetchColumn();
$totalUsers = $db->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

// 2. Orders Status Distribution
$statusCounts = $db->query("
    SELECT order_status, COUNT(*) as count 
    FROM orders 
    GROUP BY order_status
")->fetchAll(PDO::FETCH_KEY_PAIR);

// 3. Recent 8 Orders
$recentOrders = $db->query("
    SELECT o.*, COUNT(oi.id) as item_count 
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    GROUP BY o.id 
    ORDER BY o.created_at DESC 
    LIMIT 8
")->fetchAll();

// 4. Low Stock Dishes
$lowStockList = $db->query("
    SELECT f.*, c.name as category_name 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.stock <= 5 
    ORDER BY f.stock ASC 
    LIMIT 5
")->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<!-- KPI Stat Cards Grid -->
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Total Revenue</span>
            <div class="stat-icon green"><i class="fa-solid fa-coins"></i></div>
        </div>
        <div class="stat-value"><?php echo format_price($totalRevenue); ?></div>
        <div class="stat-subtext"><i class="fa-solid fa-arrow-trend-up text-success"></i> Gross Sales</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Active Orders</span>
            <div class="stat-icon orange"><i class="fa-solid fa-fire-burner"></i></div>
        </div>
        <div class="stat-value"><?php echo $activeOrders; ?></div>
        <div class="stat-subtext"><i class="fa-solid fa-clock"></i> Currently in Kitchen / Delivery</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Total Orders</span>
            <div class="stat-icon blue"><i class="fa-solid fa-receipt"></i></div>
        </div>
        <div class="stat-value"><?php echo $totalOrders; ?></div>
        <div class="stat-subtext">Lifetime Customer Orders</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Food Menu Items</span>
            <div class="stat-icon purple"><i class="fa-solid fa-utensils"></i></div>
        </div>
        <div class="stat-value"><?php echo $totalFoods; ?></div>
        <div class="stat-subtext"><?php echo $lowStockFoods; ?> Low Stock Items</div>
    </div>
</div>

<!-- Order Status Quick Breakdown Strip -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="admin-card-title">
            <i class="fa-solid fa-chart-pie text-primary"></i> Order Pipeline Status
        </div>
        <a href="<?php echo BASE_URL; ?>/admin/orders.php" class="btn btn-outline-primary btn-sm">
            Manage All Orders <i class="fa-solid fa-arrow-right"></i>
        </a>
    </div>
    <div style="padding: 18px 24px; display: flex; gap: 16px; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 140px; background: #111827; padding: 14px; border-radius: var(--radius-md); border: 1px solid #1f2937;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">PENDING</div>
            <div style="font-size: 1.4rem; font-weight: 800; color: #f59e0b;"><?php echo $statusCounts['Pending'] ?? 0; ?></div>
        </div>
        <div style="flex: 1; min-width: 140px; background: #111827; padding: 14px; border-radius: var(--radius-md); border: 1px solid #1f2937;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">CONFIRMED</div>
            <div style="font-size: 1.4rem; font-weight: 800; color: #0284c7;"><?php echo $statusCounts['Confirmed'] ?? 0; ?></div>
        </div>
        <div style="flex: 1; min-width: 140px; background: #111827; padding: 14px; border-radius: var(--radius-md); border: 1px solid #1f2937;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">PREPARING</div>
            <div style="font-size: 1.4rem; font-weight: 800; color: #ea580c;"><?php echo $statusCounts['Preparing'] ?? 0; ?></div>
        </div>
        <div style="flex: 1; min-width: 140px; background: #111827; padding: 14px; border-radius: var(--radius-md); border: 1px solid #1f2937;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">OUT FOR DELIVERY</div>
            <div style="font-size: 1.4rem; font-weight: 800; color: #8b5cf6;"><?php echo $statusCounts['Out for Delivery'] ?? 0; ?></div>
        </div>
        <div style="flex: 1; min-width: 140px; background: #111827; padding: 14px; border-radius: var(--radius-md); border: 1px solid #1f2937;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 600;">DELIVERED</div>
            <div style="font-size: 1.4rem; font-weight: 800; color: #10b981;"><?php echo $statusCounts['Delivered'] ?? 0; ?></div>
        </div>
    </div>
</div>

<!-- Main 2-Column Section: Recent Orders & Inventory Alerts -->
<div class="grid grid-cols-1 gap-6">
    <!-- Recent Customer Orders Table -->
    <div class="admin-card">
        <div class="admin-card-header">
            <div class="admin-card-title">
                <i class="fa-solid fa-bell-concierge text-primary"></i> Live Kitchen Orders (Recent)
            </div>
            <a href="<?php echo BASE_URL; ?>/admin/orders.php" class="btn btn-outline btn-sm">
                View All Orders
            </a>
        </div>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Address / City</th>
                        <th>Total</th>
                        <th>Payment</th>
                        <th>Status (Live Updater)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentOrders)): ?>
                        <tr><td colspan="7" style="text-align:center; padding: 30px; color:#94a3b8;">No customer orders placed yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td>
                                    <a href="<?php echo BASE_URL; ?>/admin/order_view.php?id=<?php echo $order['id']; ?>" style="font-weight: 700; color: #fb923c;">
                                        <?php echo htmlspecialchars($order['order_number']); ?>
                                    </a>
                                    <div style="font-size:0.75rem; color:#64748b;"><?php echo date('h:i A', strtotime($order['created_at'])); ?></div>
                                </td>
                                <td>
                                    <div style="font-weight: 600; color: white;"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                    <div style="font-size: 0.75rem; color: #94a3b8;"><?php echo htmlspecialchars($order['customer_phone']); ?></div>
                                </td>
                                <td>
                                    <div style="font-size: 0.85rem; max-width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                        <?php echo htmlspecialchars($order['delivery_address'] . ', ' . $order['delivery_city']); ?>
                                    </div>
                                </td>
                                <td style="font-weight: 700; color: #fb923c;">
                                    <?php echo format_price($order['grand_total']); ?>
                                </td>
                                <td>
                                    <?php if ($order['payment_status'] === 'paid'): ?>
                                        <span class="badge badge-success"><?php echo strtoupper($order['payment_method']); ?> - PAID</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">COD - PENDING</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- Dynamic Quick Status Changer Dropdown -->
                                    <select class="status-select admin-order-status-select" 
                                            data-order-id="<?php echo $order['id']; ?>" 
                                            data-order-number="<?php echo htmlspecialchars($order['order_number']); ?>"
                                            data-current-status="<?php echo htmlspecialchars($order['order_status']); ?>">
                                        <option value="Pending" <?php echo ($order['order_status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Confirmed" <?php echo ($order['order_status'] === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                                        <option value="Preparing" <?php echo ($order['order_status'] === 'Preparing') ? 'selected' : ''; ?>>Preparing</option>
                                        <option value="Ready" <?php echo ($order['order_status'] === 'Ready') ? 'selected' : ''; ?>>Ready</option>
                                        <option value="Out for Delivery" <?php echo ($order['order_status'] === 'Out for Delivery') ? 'selected' : ''; ?>>Out for Delivery</option>
                                        <option value="Delivered" <?php echo ($order['order_status'] === 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="Cancelled" <?php echo ($order['order_status'] === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                </td>
                                <td>
                                    <a href="<?php echo BASE_URL; ?>/admin/order_view.php?id=<?php echo $order['id']; ?>" class="btn btn-outline btn-sm">
                                        <i class="fa-solid fa-eye"></i> Details
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Low Stock Inventory Alerts -->
    <?php if (!empty($lowStockList)): ?>
        <div class="admin-card">
            <div class="admin-card-header" style="background: rgba(239, 68, 68, 0.1);">
                <div class="admin-card-title" style="color: #f87171;">
                    <i class="fa-solid fa-triangle-exclamation"></i> Low Kitchen Stock Warnings (Restock Needed)
                </div>
                <a href="<?php echo BASE_URL; ?>/admin/foods.php" class="btn btn-primary btn-sm">
                    Manage Food Stock &rarr;
                </a>
            </div>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Dish</th>
                            <th>Category</th>
                            <th>Current Stock</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lowStockList as $dish): ?>
                            <tr>
                                <td style="font-weight: 700; color: white;">
                                    <?php echo htmlspecialchars($dish['name']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($dish['category_name']); ?></td>
                                <td>
                                    <span class="badge <?php echo ($dish['stock'] == 0) ? 'badge-danger' : 'badge-warning'; ?>" style="font-size: 0.85rem;">
                                        <?php echo $dish['stock']; ?> units remaining
                                    </span>
                                </td>
                                <td>
                                    <?php echo ($dish['stock'] > 0) ? '<span class="text-warning">Low Stock</span>' : '<span class="text-danger">Out of Stock</span>'; ?>
                                </td>
                                <td>
                                    <a href="<?php echo BASE_URL; ?>/admin/food_edit.php?id=<?php echo $dish['id']; ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fa-solid fa-pen-to-square"></i> Restock
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
