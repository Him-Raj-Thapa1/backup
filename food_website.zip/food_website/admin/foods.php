<?php
/**
 * BHOJ HUB - Admin Food Items & Inventory Management
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Food Items & Kitchen Inventory';
$db = getDB();

// Handle quick stock or availability update via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_update'])) {
    $foodId = (int)$_POST['food_id'];
    $stock = (int)$_POST['stock'];
    $isAvailable = isset($_POST['is_available']) ? 1 : 0;

    $stmt = $db->prepare("UPDATE foods SET stock = ?, is_available = ? WHERE id = ?");
    $stmt->execute([$stock, $isAvailable, $foodId]);

    set_flash('success', 'Food inventory updated successfully.');
    header("Location: " . BASE_URL . "/admin/foods.php");
    exit;
}

$categoryFilter = clean($_GET['category'] ?? 'all');
$searchQuery = clean($_GET['search'] ?? '');

$sql = "
    SELECT f.*, c.name AS category_name 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE 1=1
";
$params = [];

if (!empty($categoryFilter) && $categoryFilter !== 'all') {
    $sql .= " AND f.category_id = ?";
    $params[] = (int)$categoryFilter;
}

if (!empty($searchQuery)) {
    $sql .= " AND (f.name LIKE ? OR f.nepali_name LIKE ? OR f.description LIKE ?)";
    $term = "%{$searchQuery}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$sql .= " ORDER BY f.category_id ASC, f.id ASC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$foods = $stmt->fetchAll();

$categories = $db->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6 flex-wrap gap-4">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Cloud Kitchen Menu & Inventory</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">Manage food descriptions, pricing, live stock, and availability</p>
    </div>
    <a href="<?php echo BASE_URL; ?>/admin/food_add.php" class="btn btn-primary">
        <i class="fa-solid fa-circle-plus"></i> Add New Food Item
    </a>
</div>

<!-- Search & Filter Bar -->
<div class="admin-card mb-6" style="padding: 16px 20px;">
    <form action="<?php echo BASE_URL; ?>/admin/foods.php" method="GET" class="flex gap-4 items-center flex-wrap">
        <div style="flex: 1; min-width: 260px;">
            <input type="text" name="search" class="admin-form-control" placeholder="Search dish name, Nepali name..." value="<?php echo htmlspecialchars($searchQuery); ?>">
        </div>
        <div>
            <select name="category" class="admin-form-control" onchange="this.form.submit()">
                <option value="all">All Categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo ($categoryFilter == $c['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($c['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-filter"></i> Filter
        </button>
        <?php if (!empty($searchQuery) || $categoryFilter !== 'all'): ?>
            <a href="<?php echo BASE_URL; ?>/admin/foods.php" class="btn btn-outline btn-sm">
                <i class="fa-solid fa-rotate-left"></i> Reset
            </a>
        <?php endif; ?>
    </form>
</div>

<!-- Food Items Data Table -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="admin-card-title">
            <i class="fa-solid fa-utensils text-primary"></i> Dishes List (<?php echo count($foods); ?> Items)
        </div>
    </div>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Dish</th>
                    <th>Category</th>
                    <th>Selling Price</th>
                    <th>Stock Qty</th>
                    <th>Diet / Spice</th>
                    <th>Availability</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($foods)): ?>
                    <tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8;">No food items found matching your filters.</td></tr>
                <?php else: ?>
                    <?php foreach ($foods as $food): ?>
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <img src="<?php echo food_image($food['image']); ?>" class="table-food-thumb" alt="<?php echo htmlspecialchars($food['name']); ?>">
                                    <div>
                                        <div style="font-weight: 700; color: white;"><?php echo htmlspecialchars($food['name']); ?></div>
                                        <?php if (!empty($food['nepali_name'])): ?>
                                            <div style="font-size: 0.75rem; color: #fb923c;"><?php echo htmlspecialchars($food['nepali_name']); ?></div>
                                        <?php endif; ?>
                                        <div style="font-size: 0.75rem; color: #64748b;"><?php echo htmlspecialchars($food['prep_time']); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-dark"><?php echo htmlspecialchars($food['category_name']); ?></span>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: white;"><?php echo format_price($food['price']); ?></div>
                                <?php if (!empty($food['discount_price']) && $food['discount_price'] > 0): ?>
                                    <div style="font-size: 0.75rem; color: #10b981; font-weight: 600;">Disc: <?php echo format_price($food['discount_price']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form action="<?php echo BASE_URL; ?>/admin/foods.php" method="POST" class="flex items-center gap-2">
                                    <input type="hidden" name="quick_update" value="1">
                                    <input type="hidden" name="food_id" value="<?php echo $food['id']; ?>">
                                    <input type="hidden" name="is_available" value="<?php echo $food['is_available']; ?>">
                                    <input type="number" name="stock" value="<?php echo $food['stock']; ?>" min="0" class="admin-form-control" style="width: 75px; padding: 4px 8px; font-size: 0.85rem; text-align: center;">
                                    <button type="submit" class="btn btn-outline btn-sm" title="Quick Update Stock">
                                        <i class="fa-solid fa-check"></i>
                                    </button>
                                </form>
                                <?php if ($food['stock'] <= 0): ?>
                                    <span class="badge badge-danger mt-1" style="font-size: 0.7rem;">Out of Stock</span>
                                <?php elseif ($food['stock'] <= 5): ?>
                                    <span class="badge badge-warning mt-1" style="font-size: 0.7rem;">Low (<?php echo $food['stock']; ?>)</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="flex items-center gap-2">
                                    <span class="diet-indicator <?php echo $food['is_veg'] ? 'veg' : 'non-veg'; ?>" title="<?php echo $food['is_veg'] ? 'Pure Veg' : 'Non-Veg'; ?>"></span>
                                    <span style="font-size: 0.8rem; color: #94a3b8;">
                                        <i class="fa-solid fa-pepper-hot" style="color: <?php echo ($food['spicy_level'] > 1) ? '#ea580c' : '#64748b'; ?>;"></i>
                                        Lvl <?php echo $food['spicy_level']; ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <?php if ($food['is_available'] && $food['stock'] > 0): ?>
                                    <span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Available</span>
                                <?php else: ?>
                                    <span class="badge badge-danger"><i class="fa-solid fa-circle-xmark"></i> Unavailable</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="flex gap-2">
                                    <a href="<?php echo BASE_URL; ?>/admin/food_edit.php?id=<?php echo $food['id']; ?>" class="btn btn-outline-primary btn-sm" title="Edit Item">
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </a>
                                    <a href="<?php echo BASE_URL; ?>/admin/food_delete.php?id=<?php echo $food['id']; ?>" class="btn btn-outline btn-sm" style="color: #ef4444;" onclick="return confirm('Are you sure you want to delete \'<?php echo addslashes($food['name']); ?>\' from the menu?');" title="Delete Item">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
