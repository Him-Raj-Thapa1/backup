<?php
/**
 * BHOJ HUB - Admin Single Order View & Kitchen Ticket
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$orderId = (int)($_GET['id'] ?? 0);
if ($orderId <= 0) {
    header("Location: " . BASE_URL . "/admin/orders.php");
    exit;
}

$db = getDB();

// Handle Order Update from form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order'])) {
    $orderStatus = clean($_POST['order_status'] ?? 'Pending');
    $paymentStatus = clean($_POST['payment_status'] ?? 'pending');

    $stmt = $db->prepare("UPDATE orders SET order_status = ?, payment_status = ? WHERE id = ?");
    $stmt->execute([$orderStatus, $paymentStatus, $orderId]);

    set_flash('success', "Order #{$orderId} details updated successfully.");
    header("Location: " . BASE_URL . "/admin/order_view.php?id={$orderId}");
    exit;
}

// Fetch order
$stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    set_flash('error', 'Order not found.');
    header("Location: " . BASE_URL . "/admin/orders.php");
    exit;
}

// Fetch items
$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$orderId]);
$items = $itemStmt->fetchAll();

$pageTitle = "Order #{$order['order_number']}";
include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6 flex-wrap gap-4 no-print">
    <div>
        <div style="font-size: 0.85rem; color: #94a3b8;">
            <a href="<?php echo BASE_URL; ?>/admin/orders.php" style="color:#fb923c;">&larr; Back to Orders List</a>
        </div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white; margin-top: 4px;">
            Order Management: #<?php echo htmlspecialchars($order['order_number']); ?>
        </h2>
    </div>
    <div class="flex gap-3">
        <button onclick="window.print()" class="btn btn-outline btn-sm">
            <i class="fa-solid fa-print"></i> Print Kitchen KOT / Receipt
        </button>
    </div>
</div>

<div class="grid grid-cols-1 gap-6">
    <!-- Quick Update Action Card -->
    <div class="admin-card no-print" style="padding: 22px 28px; background: #1a233a; border-color: #3b82f6;">
        <form action="<?php echo BASE_URL; ?>/admin/order_view.php?id=<?php echo $orderId; ?>" method="POST" class="flex justify-between items-center flex-wrap gap-4">
            <div class="flex items-center gap-6 flex-wrap">
                <div>
                    <label class="admin-form-label">Order Kitchen Stage</label>
                    <select name="order_status" class="admin-form-control" style="font-weight: 700; width: 200px;">
                        <option value="Pending" <?php echo ($order['order_status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                        <option value="Confirmed" <?php echo ($order['order_status'] === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                        <option value="Preparing" <?php echo ($order['order_status'] === 'Preparing') ? 'selected' : ''; ?>>Preparing</option>
                        <option value="Ready" <?php echo ($order['order_status'] === 'Ready') ? 'selected' : ''; ?>>Ready</option>
                        <option value="Out for Delivery" <?php echo ($order['order_status'] === 'Out for Delivery') ? 'selected' : ''; ?>>Out for Delivery</option>
                        <option value="Delivered" <?php echo ($order['order_status'] === 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                        <option value="Cancelled" <?php echo ($order['order_status'] === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <div>
                    <label class="admin-form-label">Payment Status</label>
                    <select name="payment_status" class="admin-form-control" style="font-weight: 700; width: 180px;">
                        <option value="pending" <?php echo ($order['payment_status'] === 'pending') ? 'selected' : ''; ?>>Pending (COD)</option>
                        <option value="paid" <?php echo ($order['payment_status'] === 'paid') ? 'selected' : ''; ?>>Paid</option>
                        <option value="failed" <?php echo ($order['payment_status'] === 'failed') ? 'selected' : ''; ?>>Failed</option>
                    </select>
                </div>
            </div>

            <button type="submit" name="update_order" class="btn btn-primary" style="align-self: flex-end;">
                <i class="fa-solid fa-floppy-disk"></i> Update Order Status
            </button>
        </form>
    </div>

    <!-- Main Order Details Grid -->
    <div class="grid grid-cols-2 gap-6">
        <!-- Order Items Breakdown -->
        <div class="admin-card" style="padding: 24px;">
            <div class="admin-card-title mb-4">
                <i class="fa-solid fa-utensils text-primary"></i> Order Items & Cooking Breakdown
            </div>

            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Dish</th>
                            <th style="text-align: center;">Price</th>
                            <th style="text-align: center;">Qty</th>
                            <th style="text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $it): ?>
                            <tr>
                                <td style="font-weight: 700; color: white;"><?php echo htmlspecialchars($it['food_name']); ?></td>
                                <td style="text-align: center; color: #94a3b8;"><?php echo format_price($it['price']); ?></td>
                                <td style="text-align: center; font-weight: 700; color: #fb923c;">× <?php echo $it['quantity']; ?></td>
                                <td style="text-align: right; font-weight: 700; color: white;"><?php echo format_price($it['subtotal']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top: 20px; padding-top: 16px; border-top: 1px dashed #334155; max-width: 280px; margin-left: auto;">
                <div class="flex justify-between mb-2" style="font-size: 0.9rem; color: #94a3b8;">
                    <span>Food Subtotal:</span>
                    <strong style="color: white;"><?php echo format_price($order['subtotal']); ?></strong>
                </div>
                <div class="flex justify-between mb-2" style="font-size: 0.9rem; color: #94a3b8;">
                    <span>Delivery Charge:</span>
                    <strong style="color: white;"><?php echo ($order['delivery_fee'] == 0) ? 'FREE' : format_price($order['delivery_fee']); ?></strong>
                </div>
                <div class="flex justify-between pt-2" style="border-top: 2px solid #334155; font-size: 1.2rem; font-weight: 800; color: #fb923c;">
                    <span>Grand Total:</span>
                    <span><?php echo format_price($order['grand_total']); ?></span>
                </div>
            </div>
        </div>

        <!-- Customer & Delivery Info -->
        <div class="admin-card" style="padding: 24px;">
            <div class="admin-card-title mb-4">
                <i class="fa-solid fa-user-tag text-primary"></i> Customer & Delivery Destination
            </div>

            <div style="line-height: 1.8; color: #cbd5e1; font-size: 0.95rem;">
                <div>
                    <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Customer Name:</span><br>
                    <strong style="font-size: 1.1rem; color: white;"><?php echo htmlspecialchars($order['customer_name']); ?></strong>
                </div>

                <div class="grid grid-cols-2 gap-4 mt-3">
                    <div>
                        <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Mobile Phone:</span><br>
                        <a href="tel:<?php echo htmlspecialchars($order['customer_phone']); ?>" style="color: #38bdf8; font-weight: 700;">
                            <i class="fa-solid fa-phone"></i> <?php echo htmlspecialchars($order['customer_phone']); ?>
                        </a>
                    </div>
                    <div>
                        <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Email:</span><br>
                        <span style="color: white;"><?php echo htmlspecialchars($order['customer_email']); ?></span>
                    </div>
                </div>

                <div class="mt-3 pt-3" style="border-top: 1px solid #1f2937;">
                    <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Delivery Address:</span><br>
                    <div style="color: white; font-weight: 600;">
                        <?php echo htmlspecialchars($order['delivery_address']); ?>, <?php echo htmlspecialchars($order['delivery_city']); ?>
                    </div>
                </div>

                <?php if (!empty($order['delivery_notes'])): ?>
                    <div class="mt-3" style="background: rgba(234, 88, 12, 0.15); border: 1px solid rgba(234, 88, 12, 0.3); padding: 12px; border-radius: var(--radius-md);">
                        <span style="color: #fb923c; font-size: 0.8rem; font-weight: 700; text-transform: uppercase;">Special Kitchen Instructions:</span><br>
                        <span style="color: #fed7aa;"><?php echo htmlspecialchars($order['delivery_notes']); ?></span>
                    </div>
                <?php endif; ?>

                <div class="mt-3 pt-3" style="border-top: 1px solid #1f2937;">
                    <div class="flex justify-between items-center">
                        <div>
                            <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Payment Option:</span><br>
                            <span style="text-transform: uppercase; font-weight: 700; color: white;"><?php echo htmlspecialchars($order['payment_method']); ?></span>
                        </div>
                        <div>
                            <span style="color: #94a3b8; font-size: 0.8rem; text-transform: uppercase;">Payment Status:</span><br>
                            <?php if ($order['payment_status'] === 'paid'): ?>
                                <span class="badge badge-success">PAID</span>
                            <?php else: ?>
                                <span class="badge badge-warning">PENDING (COD)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .admin-sidebar, .admin-topbar, .no-print { display: none !important; }
    body, .admin-main, .admin-card { background: white !important; color: black !important; border: 1px solid #ddd !important; }
    .admin-table th, .admin-table td { color: black !important; border-bottom: 1px solid #ccc !important; }
}
</style>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
