<?php
/**
 * BHOJ HUB - Admin Customer Directory
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Registered Customers';
$db = getDB();

// Fetch customers with their total orders and lifetime spent
$sql = "
    SELECT u.*, 
           COUNT(o.id) as total_orders, 
           COALESCE(SUM(CASE WHEN o.order_status != 'Cancelled' THEN o.grand_total ELSE 0 END), 0) as total_spent 
    FROM users u 
    LEFT JOIN orders o ON u.id = o.user_id 
    WHERE u.role = 'customer' 
    GROUP BY u.id 
    ORDER BY u.created_at DESC
";
$customers = $db->query($sql)->fetchAll();

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Customer Directory</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">View registered customer accounts, order history totals, and contact information</p>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <div class="admin-card-title">
            <i class="fa-solid fa-users text-primary"></i> Registered Customers (<?php echo count($customers); ?>)
        </div>
        <div style="width: 250px;">
            <input type="text" id="admin-table-search" class="admin-form-control" placeholder="Search customer name, email, phone...">
        </div>
    </div>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Email Address</th>
                    <th>Mobile Phone</th>
                    <th>Default Address / City</th>
                    <th>Total Orders</th>
                    <th>Lifetime Spent</th>
                    <th>Joined Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($customers)): ?>
                    <tr><td colspan="7" style="text-align:center; padding:30px; color:#94a3b8;">No registered customers yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($customers as $cust): ?>
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <div class="user-avatar" style="width:34px; height:34px; font-size:0.85rem;">
                                        <?php echo strtoupper(substr($cust['name'], 0, 1)); ?>
                                    </div>
                                    <div style="font-weight: 700; color: white;">
                                        <?php echo htmlspecialchars($cust['name']); ?>
                                    </div>
                                </div>
                            </td>
                            <td style="color: #94a3b8;"><?php echo htmlspecialchars($cust['email']); ?></td>
                            <td>
                                <a href="tel:<?php echo htmlspecialchars($cust['phone']); ?>" style="color: #38bdf8; font-weight:600;">
                                    <?php echo htmlspecialchars($cust['phone']); ?>
                                </a>
                            </td>
                            <td>
                                <div style="color: #cbd5e1;"><?php echo htmlspecialchars($cust['address'] ?: 'Not set'); ?></div>
                                <div style="font-size: 0.75rem; color: #64748b;"><?php echo htmlspecialchars($cust['city']); ?></div>
                            </td>
                            <td>
                                <span class="badge badge-dark"><?php echo $cust['total_orders']; ?> orders</span>
                            </td>
                            <td style="font-weight: 700; color: #fb923c;">
                                <?php echo format_price($cust['total_spent']); ?>
                            </td>
                            <td style="font-size: 0.85rem; color: #64748b;">
                                <?php echo date('M d, Y', strtotime($cust['created_at'])); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
