<?php
/**
 * BHOJ HUB - Edit Food Item (Admin)
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$foodId = (int)($_GET['id'] ?? 0);
if ($foodId <= 0) {
    header("Location: " . BASE_URL . "/admin/foods.php");
    exit;
}

$db = getDB();
$errors = [];

// Fetch existing food
$stmt = $db->prepare("SELECT * FROM foods WHERE id = ?");
$stmt->execute([$foodId]);
$food = $stmt->fetch();

if (!$food) {
    set_flash('error', 'Food item not found.');
    header("Location: " . BASE_URL . "/admin/foods.php");
    exit;
}

// Fetch categories for dropdown
$categories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? '');
    $nepaliName = clean($_POST['nepali_name'] ?? '');
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
    $stock = (int)($_POST['stock'] ?? 0);
    $isAvailable = isset($_POST['is_available']) ? 1 : 0;
    $isVeg = isset($_POST['is_veg']) ? (int)$_POST['is_veg'] : 0;
    $spicyLevel = (int)($_POST['spicy_level'] ?? 1);
    $prepTime = clean($_POST['prep_time'] ?? '20-25 mins');
    $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
    $description = clean($_POST['description'] ?? '');

    // Validation
    if (empty($name)) $errors[] = 'Food Name is required.';
    if ($categoryId <= 0) $errors[] = 'Please select a Category.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';

    // Handle Image (Online URL or File Upload)
    $imageUrl = clean($_POST['image_url'] ?? '');
    $imageFilename = !empty($imageUrl) ? $imageUrl : $food['image'];

    if (!empty($_FILES['image']['name'])) {
        $file = $_FILES['image'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];

        if (!in_array($ext, $allowed)) {
            $errors[] = 'Image must be JPG, PNG, WEBP, or SVG.';
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $errors[] = 'Image size cannot exceed 5MB.';
        } else {
            $uploadedName = 'dish_' . time() . '_' . rand(100, 999) . '.' . $ext;
            $uploadPath = __DIR__ . '/../assets/images/foods/' . $uploadedName;
            if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                $imageFilename = $uploadedName;
            } else {
                $errors[] = 'Failed to save uploaded image.';
            }
        }
    }

    if (empty($errors)) {
        $updStmt = $db->prepare("
            UPDATE foods SET 
                category_id = ?, 
                name = ?, 
                nepali_name = ?, 
                description = ?, 
                price = ?, 
                discount_price = ?, 
                image = ?, 
                stock = ?, 
                is_available = ?, 
                is_veg = ?, 
                spicy_level = ?, 
                prep_time = ?, 
                is_featured = ?
            WHERE id = ?
        ");

        $updStmt->execute([
            $categoryId,
            $name,
            $nepaliName,
            $description,
            $price,
            $discountPrice,
            $imageFilename,
            $stock,
            $isAvailable,
            $isVeg,
            $spicyLevel,
            $prepTime,
            $isFeatured,
            $foodId
        ]);

        set_flash('success', "Food item '{$name}' has been updated successfully.");
        header("Location: " . BASE_URL . "/admin/foods.php");
        exit;
    }
}

$pageTitle = "Edit Dish - " . htmlspecialchars($food['name']);
include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Edit Dish Details</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">Update information for <?php echo htmlspecialchars($food['name']); ?></p>
    </div>
    <a href="<?php echo BASE_URL; ?>/admin/foods.php" class="btn btn-outline btn-sm">
        <i class="fa-solid fa-arrow-left"></i> Back to Foods List
    </a>
</div>

<?php if (!empty($errors)): ?>
    <div style="background: #7f1d1d; border: 1px solid #dc2626; color: #fca5a5; padding: 14px 18px; border-radius: var(--radius-md); margin-bottom: 24px;">
        <ul style="padding-left: 20px;">
            <?php foreach ($errors as $err): ?>
                <li><?php echo htmlspecialchars($err); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="admin-card" style="padding: 28px;">
    <form action="<?php echo BASE_URL; ?>/admin/food_edit.php?id=<?php echo $foodId; ?>" method="POST" enctype="multipart/form-data">
        <div class="grid grid-cols-2 gap-6">
            <!-- Left Column: Name & Category -->
            <div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Dish Name (English) *</label>
                    <input type="text" name="name" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['name'] ?? $food['name']); ?>" required>
                </div>

                <div class="admin-form-group">
                    <label class="admin-form-label">Nepali Name / Subtitle</label>
                    <input type="text" name="nepali_name" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['nepali_name'] ?? $food['nepali_name'] ?? ''); ?>">
                </div>

                <div class="admin-form-group">
                    <label class="admin-form-label">Menu Category *</label>
                    <select name="category_id" class="admin-form-control" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['id']; ?>" <?php echo (($food['category_id']) == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="admin-form-group">
                        <label class="admin-form-label">Regular Price (Rs.) *</label>
                        <input type="number" name="price" step="0.01" min="1" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['price'] ?? $food['price']); ?>" required>
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label">Discount Price (Rs.)</label>
                        <input type="number" name="discount_price" step="0.01" min="0" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['discount_price'] ?? $food['discount_price'] ?? ''); ?>">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="admin-form-group">
                        <label class="admin-form-label">Stock Quantity in Kitchen *</label>
                        <input type="number" name="stock" min="0" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['stock'] ?? $food['stock']); ?>" required>
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label">Prep & Cook Time</label>
                        <input type="text" name="prep_time" class="admin-form-control" value="<?php echo htmlspecialchars($_POST['prep_time'] ?? $food['prep_time']); ?>">
                    </div>
                </div>
            </div>

            <!-- Right Column: Specs, Image, Toggles -->
            <div>
                <div class="admin-form-group">
                    <label class="admin-form-label">Food Image Online URL</label>
                    <input type="url" name="image_url" id="food-image-url" class="admin-form-control" placeholder="https://images.unsplash.com/... or paste any web food image URL" value="<?php echo htmlspecialchars($_POST['image_url'] ?? ((str_starts_with($food['image'] ?? '', 'http://') || str_starts_with($food['image'] ?? '', 'https://')) ? $food['image'] : '')); ?>">
                    <span style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px; display: block;">Paste any direct web image URL (recommended) or choose a local file below.</span>
                </div>

                <div class="admin-form-group">
                    <label class="admin-form-label">Or Upload New Local Image</label>
                    <div class="flex items-center gap-4 mb-2">
                        <img src="<?php echo food_image($food['image']); ?>" id="food-image-current" alt="Current" style="width: 90px; height: 65px; object-fit: cover; border-radius: 6px; border: 1px solid #334155;">
                        <span style="font-size: 0.8rem; color: #94a3b8;">Current active dish image shown on left.</span>
                    </div>
                    <input type="file" name="image" id="food-image-upload" class="admin-form-control" accept="image/*">
                    <div style="margin-top: 10px;">
                        <img id="food-image-preview" src="#" alt="New Preview" style="display:none; max-width: 240px; height: 140px; object-fit: cover; border-radius: 8px; border: 1px solid #334155;">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="admin-form-group">
                        <label class="admin-form-label">Dietary Preference</label>
                        <select name="is_veg" class="admin-form-control">
                            <option value="0" <?php echo ($food['is_veg'] == 0) ? 'selected' : ''; ?>>Non-Vegetarian (Meat / Egg)</option>
                            <option value="1" <?php echo ($food['is_veg'] == 1) ? 'selected' : ''; ?>>🌱 Pure Vegetarian</option>
                        </select>
                    </div>
                    <div class="admin-form-group">
                        <label class="admin-form-label">Spiciness Level</label>
                        <select name="spicy_level" class="admin-form-control">
                            <option value="0" <?php echo ($food['spicy_level'] == 0) ? 'selected' : ''; ?>>0 - Mild (No Chilly)</option>
                            <option value="1" <?php echo ($food['spicy_level'] == 1) ? 'selected' : ''; ?>>1 - Medium (Balanced)</option>
                            <option value="2" <?php echo ($food['spicy_level'] == 2) ? 'selected' : ''; ?>>2 - Spicy (Authentic Nepali)</option>
                            <option value="3" <?php echo ($food['spicy_level'] == 3) ? 'selected' : ''; ?>>3 - Fiery Hot (Timur & Chilly)</option>
                        </select>
                    </div>
                </div>

                <div class="admin-form-group">
                    <label class="admin-form-label">Description & Ingredients</label>
                    <textarea name="description" class="admin-form-control" rows="4"><?php echo htmlspecialchars($_POST['description'] ?? $food['description'] ?? ''); ?></textarea>
                </div>

                <!-- Toggles -->
                <div class="flex gap-6 mt-4">
                    <label class="flex items-center gap-3" style="color: white; font-weight: 600; cursor: pointer;">
                        <input type="checkbox" name="is_available" value="1" <?php echo ($food['is_available'] == 1) ? 'checked' : ''; ?> style="width:18px; height:18px; accent-color: var(--veg);">
                        <span>Available for Ordering</span>
                    </label>

                    <label class="flex items-center gap-3" style="color: white; font-weight: 600; cursor: pointer;">
                        <input type="checkbox" name="is_featured" value="1" <?php echo ($food['is_featured'] == 1) ? 'checked' : ''; ?> style="width:18px; height:18px; accent-color: var(--primary);">
                        <span>Feature on Homepage</span>
                    </label>
                </div>
            </div>
        </div>

        <div class="mt-8 pt-4 flex gap-4" style="border-top: 1px solid #1f2937;">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="fa-solid fa-floppy-disk"></i> Update Dish
            </button>
            <a href="<?php echo BASE_URL; ?>/admin/foods.php" class="btn btn-outline btn-lg">
                Cancel
            </a>
        </div>
    </form>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
