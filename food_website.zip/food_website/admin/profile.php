<?php
/**
 * BHOJ HUB - Admin Settings & Profile
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Admin Profile & Settings';
$admin = current_user();
$db = getDB();
$errors = [];

// Handle Admin Details Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_admin'])) {
    $name = clean($_POST['name'] ?? '');
    $phone = clean($_POST['phone'] ?? '');

    if (empty($name)) $errors[] = 'Name is required.';

    if (empty($errors)) {
        $stmt = $db->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
        $stmt->execute([$name, $phone, $admin['id']]);

        $_SESSION['user_name'] = $name;
        $_SESSION['user_phone'] = $phone;

        set_flash('success', 'Admin details updated successfully.');
        header("Location: " . BASE_URL . "/admin/profile.php");
        exit;
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_admin_pass'])) {
    $currentPass = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_password'] ?? '';

    $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$admin['id']]);
    $dbPass = $stmt->fetchColumn();

    if (!password_verify($currentPass, $dbPass)) {
        $errors[] = 'Current password does not match.';
    } elseif (strlen($newPass) < 6) {
        $errors[] = 'New password must be at least 6 characters.';
    } elseif ($newPass !== $confirmPass) {
        $errors[] = 'New passwords do not match.';
    } else {
        $hashed = password_hash($newPass, PASSWORD_DEFAULT);
        $upd = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upd->execute([$hashed, $admin['id']]);

        set_flash('success', 'Admin master password changed successfully.');
        header("Location: " . BASE_URL . "/admin/profile.php");
        exit;
    }
}

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Admin Profile & Security</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">Manage kitchen manager account settings and security credentials</p>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div style="background: #7f1d1d; border: 1px solid #dc2626; color: #fca5a5; padding: 14px 18px; border-radius: var(--radius-md); margin-bottom: 24px;">
        <ul style="padding-left: 20px;">
            <?php foreach ($errors as $err): ?>
                <li><?php echo htmlspecialchars($err); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="grid grid-cols-2 gap-8">
    <!-- Admin Personal Info -->
    <div class="admin-card" style="padding: 24px;">
        <div class="admin-card-title mb-4">
            <i class="fa-solid fa-user-shield text-primary"></i> Manager Information
        </div>

        <form action="<?php echo BASE_URL; ?>/admin/profile.php" method="POST">
            <div class="admin-form-group">
                <label class="admin-form-label">Full Name</label>
                <input type="text" name="name" class="admin-form-control" value="<?php echo htmlspecialchars($admin['name']); ?>" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">Admin Email (Login Username)</label>
                <input type="email" class="admin-form-control" value="<?php echo htmlspecialchars($admin['email']); ?>" readonly style="background: #1e293b; color: #94a3b8; cursor: not-allowed;">
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">Kitchen Phone</label>
                <input type="tel" name="phone" class="admin-form-control" value="<?php echo htmlspecialchars($admin['phone']); ?>">
            </div>

            <button type="submit" name="update_admin" class="btn btn-primary mt-2">
                <i class="fa-solid fa-floppy-disk"></i> Update Admin Details
            </button>
        </form>
    </div>

    <!-- Password Change -->
    <div class="admin-card" style="padding: 24px;">
        <div class="admin-card-title mb-4">
            <i class="fa-solid fa-key text-primary"></i> Change Admin Password
        </div>

        <form action="<?php echo BASE_URL; ?>/admin/profile.php" method="POST">
            <div class="admin-form-group">
                <label class="admin-form-label">Current Password</label>
                <input type="password" name="current_password" class="admin-form-control" placeholder="••••••••" required>
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">New Password (Min 6 Chars)</label>
                <input type="password" name="new_password" class="admin-form-control" placeholder="••••••••" required minlength="6">
            </div>

            <div class="admin-form-group">
                <label class="admin-form-label">Confirm New Password</label>
                <input type="password" name="confirm_password" class="admin-form-control" placeholder="••••••••" required minlength="6">
            </div>

            <button type="submit" name="change_admin_pass" class="btn btn-secondary btn-block mt-2">
                <i class="fa-solid fa-lock"></i> Update Password
            </button>
        </form>
    </div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
