<?php
/**
 * BHOJ HUB - Admin Order Management
 */
require_once __DIR__ . '/../config/helpers.php';
require_admin();

$pageTitle = 'Customer Orders';
$db = getDB();

$statusFilter = clean($_GET['status'] ?? 'all');
$searchQuery = clean($_GET['search'] ?? '');

$sql = "
    SELECT o.*, COUNT(oi.id) as item_count 
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    WHERE 1=1
";
$params = [];

if (!empty($statusFilter) && $statusFilter !== 'all') {
    $sql .= " AND o.order_status = ?";
    $params[] = $statusFilter;
}

if (!empty($searchQuery)) {
    $sql .= " AND (o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ? OR o.delivery_address LIKE ?)";
    $term = "%{$searchQuery}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$sql .= " GROUP BY o.id ORDER BY o.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get status counts for filter tabs
$tabCounts = $db->query("SELECT order_status, COUNT(*) as cnt FROM orders GROUP BY order_status")->fetchAll(PDO::FETCH_KEY_PAIR);
$allCount = array_sum($tabCounts);

include __DIR__ . '/../includes/admin_header.php';
?>

<div class="flex justify-between items-center mb-6 flex-wrap gap-4">
    <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: white;">Customer Orders & Kitchen Pipeline</h2>
        <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">Track orders, update kitchen preparation stages, and manage delivery</p>
    </div>
</div>

<!-- Status Filter Tabs -->
<div class="category-chips mb-6" style="padding-top: 0;">
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=all" class="category-chip <?php echo ($statusFilter === 'all') ? 'active' : ''; ?>">
        All Orders (<?php echo $allCount; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Pending" class="category-chip <?php echo ($statusFilter === 'Pending') ? 'active' : ''; ?>">
        Pending (<?php echo $tabCounts['Pending'] ?? 0; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Confirmed" class="category-chip <?php echo ($statusFilter === 'Confirmed') ? 'active' : ''; ?>">
        Confirmed (<?php echo $tabCounts['Confirmed'] ?? 0; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Preparing" class="category-chip <?php echo ($statusFilter === 'Preparing') ? 'active' : ''; ?>">
        Preparing (<?php echo $tabCounts['Preparing'] ?? 0; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Ready" class="category-chip <?php echo ($statusFilter === 'Ready') ? 'active' : ''; ?>">
        Ready (<?php echo $tabCounts['Ready'] ?? 0; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Out+for+Delivery" class="category-chip <?php echo ($statusFilter === 'Out for Delivery') ? 'active' : ''; ?>">
        Out for Delivery (<?php echo $tabCounts['Out for Delivery'] ?? 0; ?>)
    </a>
    <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=Delivered" class="category-chip <?php echo ($statusFilter === 'Delivered') ? 'active' : ''; ?>">
        Delivered (<?php echo $tabCounts['Delivered'] ?? 0; ?>)
    </a>
</div>

<!-- Search Input -->
<div class="admin-card mb-6" style="padding: 16px 20px;">
    <form action="<?php echo BASE_URL; ?>/admin/orders.php" method="GET" class="flex gap-4 items-center">
        <input type="hidden" name="status" value="<?php echo htmlspecialchars($statusFilter); ?>">
        <div style="flex: 1;">
            <input type="text" name="search" class="admin-form-control" placeholder="Search by Order #, Customer Name, Phone, or Delivery Location..." value="<?php echo htmlspecialchars($searchQuery); ?>">
        </div>
        <button type="submit" class="btn btn-secondary btn-sm">
            <i class="fa-solid fa-magnifying-glass"></i> Search
        </button>
        <?php if (!empty($searchQuery)): ?>
            <a href="<?php echo BASE_URL; ?>/admin/orders.php?status=<?php echo urlencode($statusFilter); ?>" class="btn btn-outline btn-sm">Clear</a>
        <?php endif; ?>
    </form>
</div>

<!-- Orders Table -->
<div class="admin-card">
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Order # & Time</th>
                    <th>Customer Info</th>
                    <th>Delivery Location</th>
                    <th>Amount</th>
                    <th>Payment</th>
                    <th>Order Status (Quick Change)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan="7" style="text-align:center; padding: 40px; color: #94a3b8;">No orders found matching this criteria.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>
                                <a href="<?php echo BASE_URL; ?>/admin/order_view.php?id=<?php echo $order['id']; ?>" style="font-weight: 800; color: #fb923c;">
                                    <?php echo htmlspecialchars($order['order_number']); ?>
                                </a>
                                <div style="font-size: 0.75rem; color: #64748b;"><?php echo date('M d, h:i A', strtotime($order['created_at'])); ?></div>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: white;"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                <div style="font-size: 0.75rem; color: #94a3b8;"><?php echo htmlspecialchars($order['customer_phone']); ?></div>
                            </td>
                            <td>
                                <div style="font-size: 0.85rem; color: #cbd5e1; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    <?php echo htmlspecialchars($order['delivery_address']); ?>
                                </div>
                                <div style="font-size: 0.75rem; color: #64748b;"><?php echo htmlspecialchars($order['delivery_city']); ?></div>
                            </td>
                            <td>
                                <div style="font-weight: 800; color: #fb923c;"><?php echo format_price($order['grand_total']); ?></div>
                                <div style="font-size: 0.75rem; color: #64748b;"><?php echo $order['item_count']; ?> dish items</div>
                            </td>
                            <td>
                                <?php if ($order['payment_status'] === 'paid'): ?>
                                    <span class="badge badge-success"><?php echo strtoupper($order['payment_method']); ?> • PAID</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">COD • PENDING</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- Dynamic AJAX Order Status Selector -->
                                <select class="status-select admin-order-status-select" 
                                        data-order-id="<?php echo $order['id']; ?>" 
                                        data-order-number="<?php echo htmlspecialchars($order['order_number']); ?>"
                                        data-current-status="<?php echo htmlspecialchars($order['order_status']); ?>">
                                    <option value="Pending" <?php echo ($order['order_status'] === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Confirmed" <?php echo ($order['order_status'] === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                                    <option value="Preparing" <?php echo ($order['order_status'] === 'Preparing') ? 'selected' : ''; ?>>Preparing</option>
                                    <option value="Ready" <?php echo ($order['order_status'] === 'Ready') ? 'selected' : ''; ?>>Ready</option>
                                    <option value="Out for Delivery" <?php echo ($order['order_status'] === 'Out for Delivery') ? 'selected' : ''; ?>>Out for Delivery</option>
                                    <option value="Delivered" <?php echo ($order['order_status'] === 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="Cancelled" <?php echo ($order['order_status'] === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </td>
                            <td>
                                <a href="<?php echo BASE_URL; ?>/admin/order_view.php?id=<?php echo $order['id']; ?>" class="btn btn-outline-primary btn-sm">
                                    <i class="fa-solid fa-eye"></i> View Order
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</div>
</div>
</body>
</html>
