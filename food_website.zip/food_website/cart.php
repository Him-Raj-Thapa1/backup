<?php
/**
 * BHOJ HUB - Interactive Shopping Cart Page
 */
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'Your Order Tray';
$cart = get_cart();
$totals = get_cart_totals();

include __DIR__ . '/includes/header.php';
?>

<div class="container py-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <span class="badge badge-primary mb-2"><i class="fa-solid fa-basket-shopping"></i> Review Your Selection</span>
            <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--secondary);">Order Tray & Cart</h1>
        </div>
        <?php if (!empty($cart)): ?>
            <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-outline-primary btn-sm">
                <i class="fa-solid fa-plus"></i> Add More Food
            </a>
        <?php endif; ?>
    </div>

    <?php if (empty($cart)): ?>
        <!-- Empty Cart State -->
        <div style="text-align: center; padding: 80px 20px; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px dashed var(--border-light); max-width: 650px; margin: 0 auto;">
            <div style="font-size: 4rem; margin-bottom: 16px;">🥟</div>
            <h2 style="font-size: 1.6rem; font-weight: 800; color: var(--secondary); margin-bottom: 8px;">Your Food Tray is Empty</h2>
            <p style="color: var(--text-muted); font-size: 1rem; max-width: 450px; margin: 0 auto 24px;">
                Looks like you haven't added any authentic Nepali dishes yet. Check out our steaming Mo:Mo, Thakali Thalis, and Sekuwa!
            </p>
            <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-primary btn-lg">
                <i class="fa-solid fa-utensils"></i> Explore BHOJ HUB Menu
            </a>
        </div>
    <?php else: ?>
        <!-- Cart Layout -->
        <div class="cart-layout">
            <!-- Items Table List -->
            <div class="cart-items-card">
                <div class="flex justify-between items-center pb-4 mb-4" style="border-bottom: 2px solid var(--border-light);">
                    <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary);">
                        Items in Your Order (<?php echo $totals['item_count']; ?>)
                    </h3>
                    <button type="button" class="btn btn-outline btn-sm" onclick="if(confirm('Clear all items from your cart?')) { fetch('api/cart.php?action=clear').then(() => location.reload()); }">
                        <i class="fa-solid fa-trash-can"></i> Clear All
                    </button>
                </div>

                <div class="cart-items-container">
                    <?php foreach ($cart as $foodId => $item): ?>
                        <div class="cart-item-row" id="cart-row-<?php echo $foodId; ?>">
                            <!-- Thumbnail -->
                            <div class="cart-item-thumb">
                                <img src="<?php echo food_image($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>

                            <!-- Name & Unit Price -->
                            <div>
                                <h4 class="cart-item-name">
                                    <a href="<?php echo BASE_URL; ?>/food_details.php?id=<?php echo $foodId; ?>">
                                        <?php echo htmlspecialchars($item['name']); ?>
                                    </a>
                                </h4>
                                <?php if (!empty($item['nepali_name'])): ?>
                                    <div style="font-size: 0.8rem; color: #78716c; margin-bottom: 4px;"><?php echo htmlspecialchars($item['nepali_name']); ?></div>
                                <?php endif; ?>
                                <div class="cart-item-price"><?php echo format_price($item['price']); ?> each</div>
                            </div>

                            <!-- Quantity Controller -->
                            <div>
                                <div class="qty-control">
                                    <button type="button" class="qty-btn qty-adjust-btn cart-page-btn" data-action="dec" data-food-id="<?php echo $foodId; ?>">-</button>
                                    <input type="text" id="cart-qty-<?php echo $foodId; ?>" class="qty-val qty-val-<?php echo $foodId; ?>" value="<?php echo $item['quantity']; ?>" readonly>
                                    <button type="button" class="qty-btn qty-adjust-btn cart-page-btn" data-action="inc" data-food-id="<?php echo $foodId; ?>">+</button>
                                </div>
                            </div>

                            <!-- Total & Delete -->
                            <div class="flex items-center gap-4">
                                <div class="cart-item-total">
                                    <?php echo format_price($item['price'] * $item['quantity']); ?>
                                </div>
                                <button type="button" class="cart-remove-btn btn-remove-cart" data-food-id="<?php echo $foodId; ?>" title="Remove item">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="mt-6 pt-4 flex justify-between items-center" style="border-top: 1px solid var(--border-light);">
                    <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-outline btn-sm">
                        <i class="fa-solid fa-arrow-left"></i> Continue Shopping
                    </a>
                </div>
            </div>

            <!-- Order Summary Sidebar -->
            <div class="cart-summary-card">
                <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 16px;">
                    Order Summary
                </h3>

                <!-- Free Delivery Progress Bar -->
                <div class="delivery-progress-wrap">
                    <div id="summary-free-notice" style="font-size: 0.85rem; color: #9a3412;">
                        <?php if ($totals['needs_more_for_free'] > 0): ?>
                            Add <strong><?php echo format_price($totals['needs_more_for_free']); ?></strong> more for <strong>FREE Delivery</strong>!
                        <?php else: ?>
                            <i class="fa-solid fa-gift text-success"></i> <strong>Congratulations!</strong> You unlocked FREE Delivery!
                        <?php endif; ?>
                    </div>
                    <div class="delivery-progress-bar">
                        <?php
                        $freePct = min(100, ($totals['subtotal'] / $totals['free_delivery_threshold']) * 100);
                        ?>
                        <div class="delivery-progress-fill" id="summary-free-fill" style="width: <?php echo $freePct; ?>%;"></div>
                    </div>
                </div>

                <!-- Breakdown Rows -->
                <div class="summary-row">
                    <span>Food Subtotal</span>
                    <strong id="summary-subtotal"><?php echo format_price($totals['subtotal']); ?></strong>
                </div>

                <div class="summary-row">
                    <span>Delivery Charge (KTM Valley)</span>
                    <strong id="summary-delivery-fee" class="<?php echo ($totals['delivery_fee'] == 0) ? 'text-success' : ''; ?>">
                        <?php echo ($totals['delivery_fee'] == 0) ? 'FREE' : format_price($totals['delivery_fee']); ?>
                    </strong>
                </div>

                <div class="summary-row total">
                    <span>Grand Total</span>
                    <span id="summary-grand-total" style="color: var(--primary);"><?php echo format_price($totals['grand_total']); ?></span>
                </div>

                <!-- Checkout Button -->
                <a href="<?php echo BASE_URL; ?>/checkout.php" class="btn btn-primary btn-lg btn-block">
                    Proceed to Checkout <i class="fa-solid fa-arrow-right"></i>
                </a>

                <div class="flex items-center justify-center gap-3 mt-4" style="font-size: 0.8rem; color: var(--text-muted);">
                    <i class="fa-solid fa-shield-check text-success"></i> 100% Safe & Secure Ordering
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
