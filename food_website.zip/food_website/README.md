# BHOJ HUB - Nepali Cloud Kitchen Food Ordering & Management System

**BHOJ HUB (भोज हब)** is a complete, modern, and authentic Nepali cloud-kitchen food ordering and restaurant management platform developed in **PHP, MySQL, HTML5, Vanilla CSS3, and JavaScript**, built for deployment on **XAMPP**.

---

## 🌟 Key Highlights & Features

### 1. Customer Portal
- **Interactive Menu & Category Browsing**:
  - Browse authentic dishes organized across *Mo:Mo & Dumplings, Nepali Bhoj & Thali, Sekuwa & Tandoor Grills, Kathmandu Noodles, Khaja & Fast Food, Desserts & Mithai, and Beverages & Lassi*.
  - Veg / Non-Veg diet indicator and Spice Level meters (0=Mild to 3=Fiery Timur).
- **Dynamic Real-Time Food Search & Filter**:
  - Instant search filtering by dish name, Nepali name, or ingredients with real-time UI filtering without page reload.
  - Price sorting (Low to High, High to Low) and pure veg toggling.
- **Dynamic AJAX Order Tray (Cart)**:
  - Add to cart with animated toast alerts and live navbar badge updating.
  - Quantity increment/decrement and item removal.
  - Live calculation of subtotal, flat delivery charge (Rs. 60 within Kathmandu Valley), and **Free Delivery Progress Bar** (unlocked for orders $\ge$ Rs. 1000).
- **Checkout & Demo Online Payment Simulator**:
  - Delivery details: Street address, Kathmandu / Lalitpur / Bhaktapur selector, contact phone, cooking & delivery instructions.
  - Payment options: **Cash on Delivery (COD)** and **Demo Online Payment** (eSewa / Khalti / Card sandbox simulator with OTP / authorization confirmation).
- **Real-Time 6-Stage Order Tracker**:
  - Live progress tracker: `Pending` ➔ `Confirmed` ➔ `Preparing` ➔ `Ready` ➔ `Out for Delivery` ➔ `Delivered`.
  - Automatic background polling every 10 seconds.
  - Itemized printable invoice and receipt format (`window.print()`).
- **Customer Account Management**:
  - Signup, login, profile editing, default delivery address management, and password change.
  - Customer review submission system for dishes.

### 2. Admin & Kitchen Management Portal
- **KPI Metrics & Analytics Dashboard**:
  - Total Revenue, Active In-Kitchen Orders, Lifetime Orders, Total Dishes, Low Stock Warnings.
  - Live 6-stage order pipeline count cards.
- **Order Management & Quick Status Updater**:
  - Filter orders by status tabs (`All`, `Pending`, `Confirmed`, `Preparing`, `Ready`, `Out for Delivery`, `Delivered`, `Cancelled`).
  - Instant dropdown status update via AJAX without leaving the page.
  - Kitchen Order Ticket (KOT) and printable receipt.
- **Food Inventory Management (CRUD)**:
  - Add, edit, and delete food items with image uploads and live preview.
  - Quick inline stock editor and availability toggling.
  - Stock auto-deducts upon customer orders. Out-of-stock items automatically show "Out of Stock" to customers.
- **Category Management (CRUD)**:
  - Add, edit, and delete categories with icon selections and sort orders.
- **Customer Directory**:
  - Customer directory with lifetime spend, total orders, contact number, and joined date.

---

## 🛠️ Database Setup (`fooddb`)

The application is configured to connect to the existing **`fooddb`** database in XAMPP:
- **Host**: `127.0.0.1` (or `localhost`)
- **Port**: `3306`
- **Database**: `fooddb`
- **User**: `root`
- **Password**: `""` (Empty string)

### 1-Click Database Setup & Seeding:
Open your browser and visit:
```
http://localhost/food_website/database/setup.php
```
Or run via command line:
```bash
php c:\xampp\htdocs\food_website\database\setup.php
```

---

## 🔑 Demo Login Credentials

### Administrator Portal
- **URL**: `http://localhost/food_website/admin/login.php`
- **Email**: `admin@bhojhub.com`
- **Password**: `admin123`

### Customer Portal Demo Account
- **URL**: `http://localhost/food_website/login.php`
- **Email**: `demo@bhojhub.com`
- **Password**: `user123`
*(Or register any new account on `register.php`)*

---

## 📁 File Structure

```
food_website/
├── config/
│   ├── database.php          # PDO MySQL connection
│   ├── constants.php         # App constants, currency (Rs.), delivery rules
│   └── helpers.php           # Session, CSRF, flash alerts, cart operations
├── database/
│   ├── schema.sql            # Table definitions
│   ├── seed.sql              # Rich Nepali cloud kitchen seed data
│   └── setup.php             # Automated DB migration and seed installer
├── assets/
│   ├── css/
│   │   ├── style.css         # Customer UI & core design system
│   │   └── admin.css         # Admin dashboard layout & components
│   ├── js/
│   │   ├── main.js           # AJAX cart, live search, demo payment modal, tracker
│   │   └── admin.js          # Admin status changer, table search, image preview
│   └── images/
│       ├── generate_assets.php # SVG food graphics generator
│       ├── foods/            # Dish illustrations and photography
│       └── categories/       # Category banners
├── includes/
│   ├── header.php            # Navigation bar & cart counter
│   ├── footer.php            # Footer with kitchen details
│   ├── admin_header.php      # Admin top navigation
│   └── admin_sidebar.php     # Admin sidebar
├── api/
│   ├── cart.php              # AJAX cart API
│   ├── search.php            # Live search & filter JSON API
│   ├── order_status.php      # Order status polling endpoint
│   └── update_order_status.php # Quick admin status changer API
├── index.php                 # Homepage (Hero, Categories, Featured, Specials)
├── menu.php                  # Interactive full menu page
├── food_details.php          # Detailed dish view with customer reviews
├── cart.php                  # Interactive cart page
├── checkout.php              # Checkout with demo payment simulator
├── order_success.php         # Order confirmation & receipt
├── orders.php                # Customer order history
├── order_details.php         # 6-Stage real-time progress tracker
├── profile.php               # Customer profile & password change
├── login.php                 # Customer login
├── register.php              # Customer registration
├── logout.php                # Logout handler
├── admin/
│   ├── index.php             # Admin operations dashboard
│   ├── login.php             # Admin login
│   ├── foods.php             # Food inventory management
│   ├── food_add.php          # Add dish form
│   ├── food_edit.php         # Edit dish form
│   ├── food_delete.php       # Delete dish handler
│   ├── categories.php        # Category CRUD
│   ├── orders.php            # Order pipeline management
│   ├── order_view.php        # Order detail & KOT print view
│   ├── users.php             # Customer directory
│   ├── profile.php           # Admin account settings
│   └── logout.php            # Admin logout
└── README.md
```
