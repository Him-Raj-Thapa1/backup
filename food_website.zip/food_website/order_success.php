<?php
/**
 * BHOJ HUB - Order Success / Confirmation Receipt Page
 */
require_once __DIR__ . '/config/helpers.php';

$orderNumber = clean($_GET['order'] ?? '');
if (empty($orderNumber)) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->execute([$orderNumber]);
$order = $stmt->fetch();

if (!$order) {
    set_flash('error', 'Order not found.');
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

// Fetch order items
$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$order['id']]);
$items = $itemStmt->fetchAll();

$pageTitle = "Order Confirmed - #{$orderNumber}";
include __DIR__ . '/includes/header.php';
?>

<div class="container py-12">
    <div style="max-width: 680px; margin: 0 auto; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px solid var(--border-light); box-shadow: var(--shadow-lg); overflow: hidden;">
        <!-- Header Banner -->
        <div style="background: linear-gradient(135deg, #065f46 0%, #047857 100%); color: white; padding: 36px 30px; text-align: center;">
            <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 2.2rem;">
                <i class="fa-solid fa-check"></i>
            </div>
            <h1 style="font-size: 1.85rem; font-weight: 800; margin-bottom: 6px;">Order Placed Successfully!</h1>
            <p style="font-size: 1rem; color: #a7f3d0;">
                Thank you for ordering with BHOJ HUB. Your food is being forwarded to our kitchen.
            </p>
        </div>

        <!-- Body Details -->
        <div style="padding: 30px;">
            <div class="grid grid-cols-2 gap-4 mb-6" style="background: var(--bg-subtle); padding: 18px; border-radius: var(--radius-md); border: 1px solid var(--border-light);">
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Order Reference</div>
                    <div style="font-size: 1.2rem; font-weight: 800; color: var(--secondary);"><?php echo htmlspecialchars($order['order_number']); ?></div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Payment Status</div>
                    <div>
                        <?php if ($order['payment_status'] === 'paid'): ?>
                            <span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Paid Online (<?php echo strtoupper($order['payment_method']); ?>)</span>
                        <?php else: ?>
                            <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Cash on Delivery (Pending)</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Delivery To</div>
                    <div style="font-weight: 700; color: var(--secondary);"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                    <div style="font-size: 0.85rem; color: var(--text-muted);"><?php echo htmlspecialchars($order['delivery_address'] . ', ' . $order['delivery_city']); ?></div>
                </div>
                <div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Estimated Delivery Time</div>
                    <div style="font-weight: 700; color: var(--primary);"><i class="fa-solid fa-person-biking"></i> 30 - 40 Minutes</div>
                </div>
            </div>

            <!-- Ordered Items List -->
            <h4 style="font-size: 1.05rem; font-weight: 800; color: var(--secondary); margin-bottom: 12px;">Dishes in this Order</h4>
            <div style="border: 1px solid var(--border-light); border-radius: var(--radius-md); overflow: hidden; margin-bottom: 24px;">
                <?php foreach ($items as $it): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-bottom: 1px solid var(--border-light); font-size: 0.9rem;">
                        <div>
                            <strong><?php echo htmlspecialchars($it['food_name']); ?></strong>
                            <span style="color: var(--text-muted); font-size: 0.8rem; margin-left: 8px;">× <?php echo $it['quantity']; ?></span>
                        </div>
                        <div style="font-weight: 700; color: var(--secondary);">
                            <?php echo format_price($it['subtotal']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div style="background: var(--bg-subtle); padding: 12px 16px; display: flex; justify-content: space-between; font-weight: 800; font-size: 1.1rem; color: var(--primary);">
                    <span>Total Paid</span>
                    <span><?php echo format_price($order['grand_total']); ?></span>
                </div>
            </div>

            <!-- Actions -->
            <div class="flex gap-4 flex-wrap">
                <a href="<?php echo BASE_URL; ?>/order_details.php?order=<?php echo urlencode($order['order_number']); ?>" class="btn btn-primary btn-block" style="flex: 1;">
                    <i class="fa-solid fa-satellite-dish"></i> Track Real-Time Order Status
                </a>
                <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-outline btn-block" style="flex: 1;">
                    <i class="fa-solid fa-house"></i> Back to Menu
                </a>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
