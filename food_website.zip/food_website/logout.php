<?php
/**
 * BHOJ HUB - Logout Handler
 */
require_once __DIR__ . '/config/helpers.php';

// Unset all user sessions
unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
unset($_SESSION['user_email']);
unset($_SESSION['user_phone']);
unset($_SESSION['user_address']);
unset($_SESSION['user_city']);
unset($_SESSION['user_role']);

set_flash('info', 'You have been logged out securely.');
header("Location: " . BASE_URL . "/index.php");
exit;
