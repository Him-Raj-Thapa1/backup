<?php
/**
 * BHOJ HUB - Order Details & 6-Stage Real-Time Tracker Page
 */
require_once __DIR__ . '/config/helpers.php';

$orderNumber = clean($_GET['order'] ?? '');
if (empty($orderNumber)) {
    header("Location: " . BASE_URL . "/orders.php");
    exit;
}

$db = getDB();
$stmt = $db->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->execute([$orderNumber]);
$order = $stmt->fetch();

if (!$order) {
    set_flash('error', 'Order not found.');
    header("Location: " . BASE_URL . "/orders.php");
    exit;
}

// Fetch order items
$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$order['id']]);
$items = $itemStmt->fetchAll();

// Order pipeline definition
$pipeline = [
    'Pending'          => ['label' => 'Order Placed', 'icon' => 'fa-clipboard-list', 'desc' => 'Waiting for kitchen confirmation'],
    'Confirmed'        => ['label' => 'Confirmed', 'icon' => 'fa-circle-check', 'desc' => 'Accepted by head chef'],
    'Preparing'        => ['label' => 'Cooking Now', 'icon' => 'fa-fire-burner', 'desc' => 'Freshly prepared in cloud kitchen'],
    'Ready'            => ['label' => 'Packed & Ready', 'icon' => 'fa-box-open', 'desc' => 'Hygienically packed in thermal box'],
    'Out for Delivery' => ['label' => 'On the Way', 'icon' => 'fa-motorcycle', 'desc' => 'Rider is speeding to your address'],
    'Delivered'        => ['label' => 'Delivered', 'icon' => 'fa-house-chimney-check', 'desc' => 'Enjoy your authentic Nepali feast!']
];

$pipelineKeys = array_keys($pipeline);
$currentStatus = $order['order_status'];
$currentIndex = array_search($currentStatus, $pipelineKeys);
if ($currentIndex === false) {
    $currentIndex = ($currentStatus === 'Cancelled') ? -1 : 0;
}

$progressPercentage = ($currentIndex >= 0) ? ($currentIndex / (count($pipelineKeys) - 1)) * 100 : 0;

$pageTitle = "Track Order #{$orderNumber}";
include __DIR__ . '/includes/header.php';
?>

<div class="container py-8" id="printable-order-section">
    <!-- Breadcrumb & Print Actions -->
    <div class="flex justify-between items-center mb-6 flex-wrap gap-4 no-print">
        <div style="font-size: 0.85rem; color: var(--text-muted);">
            <a href="<?php echo BASE_URL; ?>/index.php">Home</a> &gt; 
            <a href="<?php echo BASE_URL; ?>/orders.php">Orders</a> &gt; 
            <span style="color: var(--secondary); font-weight: 700;">#<?php echo htmlspecialchars($order['order_number']); ?></span>
        </div>
        <div class="flex gap-3">
            <button onclick="window.print()" class="btn btn-outline btn-sm">
                <i class="fa-solid fa-print"></i> Print Bill / Invoice
            </button>
            <a href="<?php echo BASE_URL; ?>/orders.php" class="btn btn-outline-primary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> All Orders
            </a>
        </div>
    </div>

    <!-- 6-Stage Real-Time Pipeline Tracker Card -->
    <div class="order-tracker-card" id="live-order-tracker" data-order-number="<?php echo htmlspecialchars($order['order_number']); ?>">
        <div class="flex justify-between items-center flex-wrap gap-4 pb-4" style="border-bottom: 1px solid var(--border-light);">
            <div>
                <span class="badge badge-primary mb-2"><i class="fa-solid fa-satellite-dish fa-spin"></i> Live Kitchen Status</span>
                <h2 style="font-size: 1.6rem; font-weight: 800; color: var(--secondary);">
                    Order Progress: <span class="text-primary" id="order-status-badge"><?php echo htmlspecialchars($order['order_status']); ?></span>
                </h2>
                <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">
                    Order Reference: <strong><?php echo htmlspecialchars($order['order_number']); ?></strong> • Placed at <?php echo date('M d, Y - h:i A', strtotime($order['created_at'])); ?>
                </div>
            </div>
            <div>
                <?php if ($order['order_status'] === 'Delivered'): ?>
                    <span class="badge badge-success" style="font-size: 0.95rem; padding: 8px 18px;">
                        <i class="fa-solid fa-circle-check"></i> Successfully Delivered
                    </span>
                <?php elseif ($order['order_status'] === 'Cancelled'): ?>
                    <span class="badge badge-danger" style="font-size: 0.95rem; padding: 8px 18px;">
                        <i class="fa-solid fa-circle-xmark"></i> Order Cancelled
                    </span>
                <?php else: ?>
                    <div style="text-align: right;">
                        <div style="font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Est. Time Remaining</div>
                        <div style="font-size: 1.25rem; font-weight: 800; color: var(--primary);">20 - 30 mins</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($order['order_status'] !== 'Cancelled'): ?>
            <!-- 6-Stage Visual Timeline -->
            <div class="order-timeline">
                <div class="order-timeline-progress" id="order-timeline-progress-bar" style="width: <?php echo $progressPercentage; ?>%;"></div>
                <?php foreach ($pipeline as $stKey => $step): ?>
                    <?php
                    $stepIdx = array_search($stKey, $pipelineKeys);
                    $stepState = 'upcoming';
                    if ($stepIdx < $currentIndex) $stepState = 'completed';
                    elseif ($stepIdx === $currentIndex) $stepState = 'current';
                    ?>
                    <div class="timeline-step <?php echo $stepState; ?>">
                        <div class="timeline-icon-box">
                            <i class="fa-solid <?php echo $step['icon']; ?>"></i>
                        </div>
                        <div class="timeline-title"><?php echo $step['label']; ?></div>
                        <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 4px; display: none;" class="step-desc-mobile"><?php echo $step['desc']; ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="padding: 24px; background: #fee2e2; border-radius: var(--radius-md); color: #b91c1c; margin-top: 20px; font-weight: 600;">
                <i class="fa-solid fa-circle-exclamation"></i> This order was cancelled by the kitchen or user. For queries, call <?php echo KITCHEN_PHONE; ?>.
            </div>
        <?php endif; ?>
    </div>

    <!-- Order Breakdown & Invoice -->
    <div class="cart-layout">
        <!-- Itemized Food Receipt -->
        <div class="cart-items-card">
            <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px;">
                Ordered Dishes & Receipt
            </h3>

            <div class="admin-table-wrap">
                <table class="admin-table" style="background: white; border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--border-light);">
                    <thead>
                        <tr style="background: var(--bg-subtle);">
                            <th style="color: var(--secondary);">Dish Name</th>
                            <th style="color: var(--secondary); text-align: center;">Price</th>
                            <th style="color: var(--secondary); text-align: center;">Qty</th>
                            <th style="color: var(--secondary); text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td style="color: var(--secondary); font-weight: 700;">
                                    <?php echo htmlspecialchars($item['food_name']); ?>
                                </td>
                                <td style="color: var(--text-muted); text-align: center;">
                                    <?php echo format_price($item['price']); ?>
                                </td>
                                <td style="color: var(--secondary); font-weight: 700; text-align: center;">
                                    × <?php echo $item['quantity']; ?>
                                </td>
                                <td style="color: var(--secondary); font-weight: 800; text-align: right;">
                                    <?php echo format_price($item['subtotal']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Total Calculations -->
            <div style="margin-top: 20px; max-width: 320px; margin-left: auto;">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <strong><?php echo format_price($order['subtotal']); ?></strong>
                </div>
                <div class="summary-row">
                    <span>Delivery Charge:</span>
                    <strong class="<?php echo ($order['delivery_fee'] == 0) ? 'text-success' : ''; ?>">
                        <?php echo ($order['delivery_fee'] == 0) ? 'FREE' : format_price($order['delivery_fee']); ?>
                    </strong>
                </div>
                <div class="summary-row total">
                    <span>Final Amount:</span>
                    <span style="color: var(--primary);"><?php echo format_price($order['grand_total']); ?></span>
                </div>
            </div>
        </div>

        <!-- Delivery & Payment Information Sidebar -->
        <div>
            <div class="cart-summary-card mb-6">
                <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--secondary); margin-bottom: 16px;">
                    <i class="fa-solid fa-location-dot text-primary"></i> Delivery Location
                </h3>
                <div style="line-height: 1.6; font-size: 0.9rem; color: var(--text-main);">
                    <div style="font-weight: 700; font-size: 1rem; color: var(--secondary);"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                    <div><i class="fa-solid fa-phone" style="color:#94a3b8; font-size:0.8rem; margin-right:6px;"></i> <?php echo htmlspecialchars($order['customer_phone']); ?></div>
                    <div><i class="fa-solid fa-envelope" style="color:#94a3b8; font-size:0.8rem; margin-right:6px;"></i> <?php echo htmlspecialchars($order['customer_email']); ?></div>
                    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border-light);">
                        <strong>Address:</strong><br>
                        <?php echo htmlspecialchars($order['delivery_address']); ?>, <?php echo htmlspecialchars($order['delivery_city']); ?>
                    </div>
                    <?php if (!empty($order['delivery_notes'])): ?>
                        <div style="margin-top: 8px; background: #fff7ed; padding: 10px; border-radius: var(--radius-sm); font-size: 0.85rem; color: #9a3412;">
                            <strong>Instructions:</strong> <?php echo htmlspecialchars($order['delivery_notes']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="cart-summary-card">
                <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--secondary); margin-bottom: 16px;">
                    <i class="fa-solid fa-wallet text-primary"></i> Payment Summary
                </h3>
                <div style="font-size: 0.9rem; line-height: 1.6;">
                    <div class="flex justify-between items-center mb-2">
                        <span style="color: var(--text-muted);">Payment Method:</span>
                        <strong style="text-transform: uppercase;"><?php echo htmlspecialchars($order['payment_method']); ?></strong>
                    </div>
                    <div class="flex justify-between items-center mb-2">
                        <span style="color: var(--text-muted);">Payment Status:</span>
                        <?php if ($order['payment_status'] === 'paid'): ?>
                            <span class="badge badge-success"><i class="fa-solid fa-check"></i> Paid</span>
                        <?php else: ?>
                            <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Cash on Delivery</span>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($order['transaction_id'])): ?>
                        <div class="flex justify-between items-center">
                            <span style="color: var(--text-muted);">Txn Ref:</span>
                            <code style="font-size: 0.8rem;"><?php echo htmlspecialchars($order['transaction_id']); ?></code>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .site-header, .site-footer, .no-print, .header-topbar { display: none !important; }
    body { background: white !important; color: black !important; }
    .cart-layout { grid-template-columns: 1fr !important; }
    .order-tracker-card { border: 1px solid #ccc !important; box-shadow: none !important; }
}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>
