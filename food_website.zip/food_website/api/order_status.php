<?php
/**
 * BHOJ HUB - Order Status API Endpoint
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/helpers.php';

$orderNumber = clean($_GET['order_number'] ?? '');

if (empty($orderNumber)) {
    echo json_encode(['success' => false, 'message' => 'Order number required.']);
    exit;
}

$pipeline = ['Pending', 'Confirmed', 'Preparing', 'Ready', 'Out for Delivery', 'Delivered'];

try {
    $db = getDB();
    $stmt = $db->prepare("SELECT id, order_number, order_status, payment_status, created_at, updated_at FROM orders WHERE order_number = ?");
    $stmt->execute([$orderNumber]);
    $order = $stmt->fetch();

    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found.']);
        exit;
    }

    $currentStatus = $order['order_status'];
    $stepIndex = array_search($currentStatus, $pipeline);
    if ($stepIndex === false) {
        $stepIndex = ($currentStatus === 'Cancelled') ? -1 : 0;
    }

    echo json_encode([
        'success' => true,
        'order_number' => $order['order_number'],
        'status' => $currentStatus,
        'step_index' => $stepIndex,
        'is_cancelled' => ($currentStatus === 'Cancelled'),
        'payment_status' => $order['payment_status'],
        'updated_at' => $order['updated_at']
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
