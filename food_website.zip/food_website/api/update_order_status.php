<?php
/**
 * BHOJ HUB - Admin Order Status Quick Updater API
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/helpers.php';

if (!is_admin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized. Admin login required.']);
    exit;
}

$orderId = (int)($_POST['order_id'] ?? 0);
$newStatus = clean($_POST['order_status'] ?? '');
$paymentStatus = clean($_POST['payment_status'] ?? '');

if ($orderId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid order ID.']);
    exit;
}

$allowedStatuses = ['Pending', 'Confirmed', 'Preparing', 'Ready', 'Out for Delivery', 'Delivered', 'Cancelled'];

try {
    $db = getDB();

    if (!empty($newStatus)) {
        if (!in_array($newStatus, $allowedStatuses)) {
            echo json_encode(['success' => false, 'message' => 'Invalid order status value.']);
            exit;
        }

        // If status marked Delivered and payment is COD, optionally auto-mark payment as paid
        if ($newStatus === 'Delivered') {
            $stmt = $db->prepare("UPDATE orders SET order_status = ?, payment_status = 'paid' WHERE id = ?");
            $stmt->execute([$newStatus, $orderId]);
        } else {
            $stmt = $db->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
            $stmt->execute([$newStatus, $orderId]);
        }
    }

    if (!empty($paymentStatus)) {
        $stmt = $db->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
        $stmt->execute([$paymentStatus, $orderId]);
    }

    echo json_encode([
        'success' => true,
        'message' => "Order #{$orderId} status successfully updated to {$newStatus}!"
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
