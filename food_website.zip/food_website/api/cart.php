<?php
/**
 * BHOJ HUB - Cart AJAX Endpoint
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/helpers.php';

$action = clean($_POST['action'] ?? $_GET['action'] ?? 'get');
$foodId = (int)($_POST['food_id'] ?? $_GET['food_id'] ?? 0);
$quantity = (int)($_POST['quantity'] ?? 1);

switch ($action) {
    case 'add':
        if ($foodId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid food item.']);
            exit;
        }
        $response = add_to_cart($foodId, max(1, $quantity));
        echo json_encode($response);
        break;

    case 'update':
        if ($foodId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid food item.']);
            exit;
        }
        $response = update_cart_quantity($foodId, $quantity);
        echo json_encode($response);
        break;

    case 'remove':
        if ($foodId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid food item.']);
            exit;
        }
        $response = remove_from_cart($foodId);
        echo json_encode($response);
        break;

    case 'clear':
        clear_cart();
        echo json_encode([
            'success' => true,
            'message' => 'Cart cleared.',
            'cart_count' => 0,
            'totals' => get_cart_totals()
        ]);
        break;

    case 'get':
    default:
        echo json_encode([
            'success' => true,
            'cart' => get_cart(),
            'cart_count' => get_cart_count(),
            'totals' => get_cart_totals()
        ]);
        break;
}
