<?php
/**
 * BHOJ HUB - Dynamic Search & Filter API Endpoint
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/helpers.php';

$query = clean($_GET['q'] ?? '');
$categorySlug = clean($_GET['category'] ?? '');
$isVeg = isset($_GET['veg']) ? (int)$_GET['veg'] : null;
$isFeatured = isset($_GET['featured']) ? (int)$_GET['featured'] : (clean($_GET['filter'] ?? '') === 'featured' ? 1 : null);
$sortBy = clean($_GET['sort'] ?? 'popular');

try {
    $db = getDB();
    $sql = "SELECT f.*, c.name AS category_name, c.slug AS category_slug 
            FROM foods f 
            JOIN categories c ON f.category_id = c.id 
            WHERE f.is_available = 1";
    
    $params = [];

    if (!empty($query)) {
        $sql .= " AND (f.name LIKE ? OR f.nepali_name LIKE ? OR f.description LIKE ?)";
        $term = "%{$query}%";
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    if (!empty($categorySlug) && $categorySlug !== 'all' && $categorySlug !== 'featured') {
        $sql .= " AND c.slug = ?";
        $params[] = $categorySlug;
    } elseif ($categorySlug === 'featured') {
        $isFeatured = 1;
    }

    if ($isFeatured !== null) {
        $sql .= " AND f.is_featured = ?";
        $params[] = $isFeatured;
    }

    if ($isVeg !== null) {
        $sql .= " AND f.is_veg = ?";
        $params[] = $isVeg;
    }

    // Sort order
    if ($sortBy === 'price_asc') {
        $sql .= " ORDER BY (CASE WHEN f.discount_price > 0 THEN f.discount_price ELSE f.price END) ASC";
    } elseif ($sortBy === 'price_desc') {
        $sql .= " ORDER BY (CASE WHEN f.discount_price > 0 THEN f.discount_price ELSE f.price END) DESC";
    } else {
        $sql .= " ORDER BY f.is_featured DESC, f.id ASC";
    }

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $foods = $stmt->fetchAll();

    foreach ($foods as &$food) {
        $food['formatted_price'] = format_price($food['price']);
        $food['formatted_discount_price'] = $food['discount_price'] ? format_price($food['discount_price']) : null;
        $food['image_url'] = food_image($food['image']);
        $food['is_in_stock'] = (int)$food['stock'] > 0;
    }

    echo json_encode([
        'success' => true,
        'count' => count($foods),
        'foods' => $foods
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
