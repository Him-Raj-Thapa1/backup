<?php
/**
 * BHOJ HUB - Helper Functions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/database.php';

/**
 * Sanitize user input
 */
function clean($data) {
    if (is_array($data)) {
        return array_map('clean', $data);
    }
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

/**
 * Flash messaging system
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'error', 'warning', 'info'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * CSRF Protection
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function verify_csrf() {
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die("CSRF Token verification failed.");
    }
    return true;
}

/**
 * Authentication Helpers
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function current_user() {
    if (!is_logged_in()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? 'User',
        'email' => $_SESSION['user_email'] ?? '',
        'phone' => $_SESSION['user_phone'] ?? '',
        'address' => $_SESSION['user_address'] ?? '',
        'city' => $_SESSION['user_city'] ?? 'Kathmandu',
        'role' => $_SESSION['user_role'] ?? 'customer'
    ];
}

function require_login($redirect = 'login.php') {
    if (!is_logged_in()) {
        set_flash('warning', 'Please log in to continue.');
        $target = $redirect;
        if (!empty($_SERVER['REQUEST_URI']) && $redirect === 'login.php') {
            $target = 'login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']);
        }
        header("Location: " . BASE_URL . "/" . ltrim($target, '/'));
        exit;
    }
}

function require_admin() {
    if (!is_logged_in()) {
        set_flash('warning', 'Please log in with an administrator account to continue.');
        header("Location: " . BASE_URL . "/login.php?type=admin");
        exit;
    }
    if (!is_admin()) {
        set_flash('error', 'Access denied. You do not have permission to access the Admin Dashboard.');
        header("Location: " . BASE_URL . "/index.php");
        exit;
    }
}

/**
 * Formatting Helpers
 */
function format_price($amount) {
    return APP_CURRENCY . ' ' . number_format((float)$amount, 2);
}

function food_image($filename) {
    if (!empty($filename)) {
        if (str_starts_with($filename, 'http://') || str_starts_with($filename, 'https://') || str_starts_with($filename, '//')) {
            return $filename;
        }
        if (file_exists(__DIR__ . '/../assets/images/foods/' . $filename)) {
            return BASE_URL . '/assets/images/foods/' . $filename;
        }
    }
    return BASE_URL . '/assets/images/food_placeholder.svg';
}

function category_image($filename) {
    if (!empty($filename)) {
        if (str_starts_with($filename, 'http://') || str_starts_with($filename, 'https://') || str_starts_with($filename, '//')) {
            return $filename;
        }
        if (file_exists(__DIR__ . '/../assets/images/categories/' . $filename)) {
            return BASE_URL . '/assets/images/categories/' . $filename;
        }
    }
    return BASE_URL . '/assets/images/category_placeholder.svg';
}

/**
 * Cart Management (Session & DB Aware)
 */
function get_cart() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

function get_cart_count() {
    $cart = get_cart();
    $count = 0;
    foreach ($cart as $item) {
        $count += (int)($item['quantity'] ?? 0);
    }
    return $count;
}

function get_cart_totals() {
    $cart = get_cart();
    $subtotal = 0.00;
    $itemCount = 0;

    foreach ($cart as $item) {
        $price = (float)$item['price'];
        $qty = (int)$item['quantity'];
        $subtotal += ($price * $qty);
        $itemCount += $qty;
    }

    $deliveryFee = 0.00;
    if ($subtotal > 0) {
        $deliveryFee = ($subtotal >= FREE_DELIVERY_THRESHOLD) ? 0.00 : DELIVERY_FEE;
    }

    $grandTotal = $subtotal + $deliveryFee;

    return [
        'item_count' => $itemCount,
        'subtotal' => $subtotal,
        'delivery_fee' => $deliveryFee,
        'free_delivery_threshold' => FREE_DELIVERY_THRESHOLD,
        'needs_more_for_free' => max(0, FREE_DELIVERY_THRESHOLD - $subtotal),
        'grand_total' => $grandTotal
    ];
}

function add_to_cart($foodId, $quantity = 1) {
    $db = getDB();
    $stmt = $db->prepare("SELECT id, name, nepali_name, price, discount_price, image, stock, is_available FROM foods WHERE id = ?");
    $stmt->execute([$foodId]);
    $food = $stmt->fetch();

    if (!$food || !$food['is_available'] || $food['stock'] <= 0) {
        return ['success' => false, 'message' => 'Item is currently unavailable or out of stock.'];
    }

    $finalPrice = (!empty($food['discount_price']) && $food['discount_price'] > 0) ? (float)$food['discount_price'] : (float)$food['price'];
    
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    $currentQty = isset($_SESSION['cart'][$foodId]) ? $_SESSION['cart'][$foodId]['quantity'] : 0;
    $newQty = $currentQty + $quantity;

    if ($newQty > $food['stock']) {
        return ['success' => false, 'message' => "Only {$food['stock']} units available in kitchen stock."];
    }

    $_SESSION['cart'][$foodId] = [
        'id' => $food['id'],
        'name' => $food['name'],
        'nepali_name' => $food['nepali_name'],
        'price' => $finalPrice,
        'original_price' => (float)$food['price'],
        'image' => $food['image'],
        'stock' => $food['stock'],
        'quantity' => $newQty
    ];

    return [
        'success' => true, 
        'message' => "{$food['name']} added to your order tray!",
        'cart_count' => get_cart_count(),
        'totals' => get_cart_totals()
    ];
}

function update_cart_quantity($foodId, $quantity) {
    $foodId = (int)$foodId;
    $quantity = (int)$quantity;

    if (!isset($_SESSION['cart'][$foodId])) {
        return ['success' => false, 'message' => 'Item not found in cart.'];
    }

    if ($quantity <= 0) {
        unset($_SESSION['cart'][$foodId]);
        return [
            'success' => true,
            'message' => 'Item removed from cart.',
            'cart_count' => get_cart_count(),
            'totals' => get_cart_totals()
        ];
    }

    // Verify stock
    $db = getDB();
    $stmt = $db->prepare("SELECT stock, is_available FROM foods WHERE id = ?");
    $stmt->execute([$foodId]);
    $food = $stmt->fetch();

    if (!$food || !$food['is_available']) {
        unset($_SESSION['cart'][$foodId]);
        return ['success' => false, 'message' => 'Item is no longer available.'];
    }

    if ($quantity > $food['stock']) {
        $_SESSION['cart'][$foodId]['quantity'] = (int)$food['stock'];
        return [
            'success' => false,
            'message' => "Max stock reached. Set to {$food['stock']} units.",
            'cart_count' => get_cart_count(),
            'totals' => get_cart_totals()
        ];
    }

    $_SESSION['cart'][$foodId]['quantity'] = $quantity;
    return [
        'success' => true,
        'message' => 'Cart updated.',
        'cart_count' => get_cart_count(),
        'totals' => get_cart_totals()
    ];
}

function remove_from_cart($foodId) {
    $foodId = (int)$foodId;
    if (isset($_SESSION['cart'][$foodId])) {
        $name = $_SESSION['cart'][$foodId]['name'];
        unset($_SESSION['cart'][$foodId]);
        return [
            'success' => true,
            'message' => "{$name} removed from your cart.",
            'cart_count' => get_cart_count(),
            'totals' => get_cart_totals()
        ];
    }
    return ['success' => false, 'message' => 'Item was not in cart.'];
}

function clear_cart() {
    $_SESSION['cart'] = [];
}

/**
 * Generate Unique Order Number
 */
function generate_order_number() {
    return 'BH-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
}
