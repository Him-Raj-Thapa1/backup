<?php
/**
 * BHOJ HUB - Application Constants & Configuration
 */

// Application Info
define('APP_NAME', 'BHOJ HUB');
define('APP_TAGLINE', 'Authentic Nepali Cloud Kitchen & Fast Delivery');
define('APP_SLOGAN', 'Taste of Tradition, Delivered Hot & Fresh');
define('APP_CURRENCY', 'Rs.');
define('APP_CURRENCY_CODE', 'NPR');

// Delivery & Charges
define('DELIVERY_FEE', 60.00); // Standard flat delivery fee inside valley
define('FREE_DELIVERY_THRESHOLD', 1000.00); // Free delivery for orders >= Rs. 1000

// URLs & Paths (Detect Base URL automatically)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$baseDir = '/food_website'; // Default XAMPP subfolder
define('BASE_URL', $protocol . $host . $baseDir);
define('ADMIN_URL', BASE_URL . '/admin');

// Kitchen Details
define('KITCHEN_PHONE', '+977 1-4789000');
define('KITCHEN_MOBILE', '+977 9801234567');
define('KITCHEN_EMAIL', 'order@bhojhub.com');
define('KITCHEN_LOCATION', 'New Baneshwor, Kathmandu, Nepal');
define('KITCHEN_HOURS', '10:00 AM - 10:30 PM (7 Days a Week)');

// Order Status Pipeline
$ORDER_STATUSES = [
    'Pending'          => ['label' => 'Pending', 'badge' => 'warning', 'icon' => 'fa-clock'],
    'Confirmed'        => ['label' => 'Confirmed', 'badge' => 'info', 'icon' => 'fa-clipboard-check'],
    'Preparing'        => ['label' => 'Preparing', 'badge' => 'primary', 'icon' => 'fa-fire-burner'],
    'Ready'            => ['label' => 'Ready for Pickup', 'badge' => 'indigo', 'icon' => 'fa-box-open'],
    'Out for Delivery' => ['label' => 'Out for Delivery', 'badge' => 'purple', 'icon' => 'fa-motorcycle'],
    'Delivered'        => ['label' => 'Delivered', 'badge' => 'success', 'icon' => 'fa-circle-check'],
    'Cancelled'        => ['label' => 'Cancelled', 'badge' => 'danger', 'icon' => 'fa-circle-xmark'],
];
