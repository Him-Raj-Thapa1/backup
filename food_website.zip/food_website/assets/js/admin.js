/**
 * BHOJ HUB - Admin Dashboard JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
  initAdminOrderStatusChanger();
  initImagePreviews();
  initSidebarToggle();
  initTableSearch();
});

function initAdminOrderStatusChanger() {
  document.querySelectorAll('.admin-order-status-select').forEach(select => {
    select.addEventListener('change', (e) => {
      const orderId = select.dataset.orderId;
      const newStatus = select.value;
      const prevValue = select.dataset.currentStatus || '';

      if (!confirm(`Are you sure you want to update order #${select.dataset.orderNumber || orderId} status to "${newStatus}"?`)) {
        select.value = prevValue;
        return;
      }

      const formData = new FormData();
      formData.append('order_id', orderId);
      formData.append('order_status', newStatus);

      fetch((window.APP_BASE_URL || '') + '/api/update_order_status.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          select.dataset.currentStatus = newStatus;
          if (window.showToast) {
            showToast('success', data.message || 'Order status updated successfully.');
          } else {
            alert(data.message || 'Order status updated.');
          }
        } else {
          select.value = prevValue;
          alert('Error: ' + data.message);
        }
      })
      .catch(err => {
        select.value = prevValue;
        alert('Failed to update status. Please check connection.');
      });
    });
  });
}

function initImagePreviews() {
  const imageInput = document.getElementById('food-image-upload');
  const urlInput = document.getElementById('food-image-url');
  const previewImg = document.getElementById('food-image-preview');

  if (urlInput && previewImg) {
    urlInput.addEventListener('input', (e) => {
      const url = e.target.value.trim();
      if (url) {
        previewImg.src = url;
        previewImg.style.display = 'block';
      }
    });
  }

  if (imageInput && previewImg) {
    imageInput.addEventListener('change', () => {
      const file = imageInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          previewImg.src = e.target.result;
          previewImg.style.display = 'block';
        };
        reader.readAsDataURL(file);
      }
    });
  }
}

function initSidebarToggle() {
  const toggleBtn = document.getElementById('admin-sidebar-toggle');
  const sidebar = document.querySelector('.admin-sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }
}

function initTableSearch() {
  const searchInput = document.getElementById('admin-table-search');
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.admin-table tbody tr');

    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(term) ? '' : 'none';
    });
  });
}
