/**
 * BHOJ HUB - Main JavaScript
 * Handles dynamic Cart, Live Search, Demo Payment modal, and UI interactions
 */

document.addEventListener('DOMContentLoaded', () => {
  initCartListeners();
  initSearchAndFilter();
  initUserDropdown();
  initMobileMenu();
  initDemoPayment();
  initLiveOrderTracker();
});

/* =====================================================
   Toast Notification System
   ===================================================== */
function showToast(type, message) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = 'fa-circle-info';
  if (type === 'success') icon = 'fa-circle-check';
  if (type === 'error') icon = 'fa-triangle-exclamation';
  if (type === 'warning') icon = 'fa-circle-exclamation';

  toast.innerHTML = `
    <i class="fa-solid ${icon}"></i>
    <div style="flex:1; font-size:0.9rem; font-weight:500;">${message}</div>
    <button style="background:none;border:none;color:#94a3b8;cursor:pointer;" onclick="this.parentElement.remove()">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/* =====================================================
   AJAX Cart System
   ===================================================== */
function initCartListeners() {
  // Add to cart buttons
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-add-to-cart');
    if (!btn) return;

    e.preventDefault();
    const foodId = btn.dataset.foodId;
    const qtyInput = document.querySelector(`.qty-input-${foodId}`) || document.getElementById('food-detail-qty');
    const quantity = qtyInput ? parseInt(qtyInput.value, 10) : 1;

    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Adding...';

    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('food_id', foodId);
    formData.append('quantity', quantity);

    fetch((window.APP_BASE_URL || '') + '/api/cart.php', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(data => {
      btn.disabled = false;
      btn.innerHTML = originalHtml;

      if (data.success) {
        showToast('success', data.message);
        updateCartBadges(data.cart_count);
        // Animate cart badge
        const badge = document.querySelector('.cart-badge');
        if (badge) {
          badge.classList.add('pulse');
          setTimeout(() => badge.classList.remove('pulse'), 500);
        }
      } else {
        showToast('error', data.message);
      }
    })
    .catch(err => {
      btn.disabled = false;
      btn.innerHTML = originalHtml;
      showToast('error', 'Could not update cart. Please try again.');
      console.error(err);
    });
  });

  // Quantity increase / decrease buttons
  document.addEventListener('click', (e) => {
    const qtyBtn = e.target.closest('.qty-adjust-btn');
    if (!qtyBtn) return;

    const action = qtyBtn.dataset.action; // 'inc' or 'dec'
    const foodId = qtyBtn.dataset.foodId;
    const qtyInput = document.getElementById(`cart-qty-${foodId}`) || document.querySelector(`.qty-val-${foodId}`);
    if (!qtyInput) return;

    let currentQty = parseInt(qtyInput.value, 10) || 1;
    let newQty = action === 'inc' ? currentQty + 1 : currentQty - 1;

    if (newQty < 1 && !qtyBtn.classList.contains('cart-page-btn')) {
      newQty = 1;
    }

    qtyInput.value = newQty;

    // If on cart page, trigger update
    if (qtyBtn.classList.contains('cart-page-btn')) {
      updateCartItemQuantity(foodId, newQty);
    }
  });

  // Cart page remove item button
  document.addEventListener('click', (e) => {
    const removeBtn = e.target.closest('.btn-remove-cart');
    if (!removeBtn) return;

    e.preventDefault();
    const foodId = removeBtn.dataset.foodId;
    removeCartItem(foodId);
  });
}

function updateCartBadges(count) {
  document.querySelectorAll('.cart-badge').forEach(el => {
    el.textContent = count;
  });
}

function updateCartItemQuantity(foodId, quantity) {
  const formData = new FormData();
  formData.append('action', 'update');
  formData.append('food_id', foodId);
  formData.append('quantity', quantity);

  fetch((window.APP_BASE_URL || '') + '/api/cart.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      if (quantity <= 0) {
        const itemRow = document.getElementById(`cart-row-${foodId}`);
        if (itemRow) itemRow.remove();
        showToast('info', 'Item removed from cart.');
      } else {
        showToast('success', 'Quantity updated.');
      }
      updateCartBadges(data.cart_count);
      refreshCartSummaryUI(data.totals);
      if (data.cart_count === 0) {
        location.reload();
      }
    } else {
      showToast('error', data.message);
    }
  })
  .catch(err => {
    showToast('error', 'Failed to update item quantity.');
    console.error(err);
  });
}

function removeCartItem(foodId) {
  const formData = new FormData();
  formData.append('action', 'remove');
  formData.append('food_id', foodId);

  fetch((window.APP_BASE_URL || '') + '/api/cart.php', {
    method: 'POST',
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      const itemRow = document.getElementById(`cart-row-${foodId}`);
      if (itemRow) {
        itemRow.style.opacity = '0';
        itemRow.style.transform = 'translateX(20px)';
        setTimeout(() => {
          itemRow.remove();
          if (data.cart_count === 0) {
            location.reload();
          }
        }, 250);
      }
      showToast('info', data.message);
      updateCartBadges(data.cart_count);
      refreshCartSummaryUI(data.totals);
    } else {
      showToast('error', data.message);
    }
  });
}

function refreshCartSummaryUI(totals) {
  if (!totals) return;
  const subtotalEl = document.getElementById('summary-subtotal');
  const deliveryFeeEl = document.getElementById('summary-delivery-fee');
  const grandTotalEl = document.getElementById('summary-grand-total');
  const freeNoticeEl = document.getElementById('summary-free-notice');
  const freeFillEl = document.getElementById('summary-free-fill');

  const curr = window.APP_CURRENCY || 'Rs.';

  if (subtotalEl) subtotalEl.textContent = `${curr} ${parseFloat(totals.subtotal).toFixed(2)}`;
  if (deliveryFeeEl) {
    if (totals.delivery_fee > 0) {
      deliveryFeeEl.textContent = `${curr} ${parseFloat(totals.delivery_fee).toFixed(2)}`;
      deliveryFeeEl.classList.remove('text-success');
    } else {
      deliveryFeeEl.textContent = 'FREE';
      deliveryFeeEl.classList.add('text-success');
    }
  }
  if (grandTotalEl) grandTotalEl.textContent = `${curr} ${parseFloat(totals.grand_total).toFixed(2)}`;

  if (freeNoticeEl && freeFillEl) {
    if (totals.needs_more_for_free > 0) {
      freeNoticeEl.innerHTML = `Add <strong>${curr} ${totals.needs_more_for_free.toFixed(2)}</strong> more for <strong>FREE Delivery</strong>!`;
      const pct = Math.min(100, (totals.subtotal / totals.free_delivery_threshold) * 100);
      freeFillEl.style.width = `${pct}%`;
    } else {
      freeNoticeEl.innerHTML = `<i class="fa-solid fa-gift text-success"></i> <strong>Congratulations!</strong> You unlocked FREE Delivery!`;
      freeFillEl.style.width = '100%';
    }
  }
}

/* =====================================================
   Live Search & Filter
   ===================================================== */
function initSearchAndFilter() {
  const searchInput = document.getElementById('food-search-input');
  const categoryChips = document.querySelectorAll('.category-chip');
  const foodCards = document.querySelectorAll('.food-grid-item');
  const vegOnlyToggle = document.getElementById('veg-only-filter');
  const sortSelect = document.getElementById('sort-price-filter');
  const noResultsEl = document.getElementById('no-food-results');

  // Check URL params
  const urlParams = new URLSearchParams(window.location.search);
  const urlCategory = urlParams.get('category') || '';
  const urlFilter = urlParams.get('filter') || '';
  const urlSearch = urlParams.get('search') || '';

  let activeCategory = 'all';
  if (urlFilter === 'featured') {
    activeCategory = 'featured';
  } else if (urlCategory) {
    activeCategory = urlCategory;
  } else {
    const activeChip = document.querySelector('.category-chip.active');
    if (activeChip && activeChip.dataset.category) {
      activeCategory = activeChip.dataset.category;
    }
  }

  let searchTerm = urlSearch ? urlSearch.trim().toLowerCase() : (searchInput ? searchInput.value.trim().toLowerCase() : '');
  let vegOnly = (urlFilter === 'veg') || (vegOnlyToggle ? vegOnlyToggle.checked : false);
  let currentSort = sortSelect ? sortSelect.value : 'default';

  // Sync veg checkbox if urlFilter === 'veg'
  if (urlFilter === 'veg' && vegOnlyToggle) {
    vegOnlyToggle.checked = true;
    vegOnly = true;
  }

  function filterCards() {
    let visibleCount = 0;

    foodCards.forEach(card => {
      const name = (card.dataset.name || '').toLowerCase();
      const desc = (card.dataset.desc || '').toLowerCase();
      const nepali = (card.dataset.nepali || '').toLowerCase();
      const category = card.dataset.category || 'all';
      const isVeg = card.dataset.isVeg === '1';
      const isFeatured = card.dataset.isFeatured === '1';

      const matchesSearch = !searchTerm || name.includes(searchTerm) || desc.includes(searchTerm) || nepali.includes(searchTerm);
      
      let matchesCat = true;
      if (activeCategory === 'featured') {
        matchesCat = isFeatured;
      } else if (activeCategory !== 'all') {
        matchesCat = category === activeCategory;
      }

      const matchesVeg = !vegOnly || isVeg;

      if (matchesSearch && matchesCat && matchesVeg) {
        card.style.display = 'flex';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    if (noResultsEl) {
      noResultsEl.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }

  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        searchTerm = e.target.value.trim().toLowerCase();
        filterCards();
      }, 150);
    });
  }

  categoryChips.forEach(chip => {
    chip.addEventListener('click', () => {
      categoryChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      activeCategory = chip.dataset.category || 'all';
      filterCards();
    });
  });

  if (vegOnlyToggle) {
    vegOnlyToggle.addEventListener('change', (e) => {
      vegOnly = e.target.checked;
      filterCards();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentSort = e.target.value;
      sortCardsGrid(currentSort);
    });
  }

  // Run immediately on page load to apply any pre-selected filter (e.g. Pure Veg or Chef's Specials)
  filterCards();
}

function sortCardsGrid(sortOrder) {
  const grid = document.querySelector('.food-grid');
  if (!grid) return;
  const cards = Array.from(grid.querySelectorAll('.food-grid-item'));

  cards.sort((a, b) => {
    const priceA = parseFloat(a.dataset.price || 0);
    const priceB = parseFloat(b.dataset.price || 0);

    if (sortOrder === 'price_asc') return priceA - priceB;
    if (sortOrder === 'price_desc') return priceB - priceA;
    return 0;
  });

  cards.forEach(card => grid.appendChild(card));
}

/* =====================================================
   User Menu Dropdown & Mobile Nav
   ===================================================== */
function initUserDropdown() {
  const userBtn = document.getElementById('user-menu-btn');
  const dropdown = document.getElementById('user-dropdown-menu');

  if (userBtn && dropdown) {
    userBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('show');
    });

    document.addEventListener('click', () => {
      dropdown.classList.remove('show');
    });
  }
}

function initMobileMenu() {
  const toggleBtn = document.getElementById('mobile-nav-toggle');
  const navMenu = document.getElementById('nav-menu');

  if (toggleBtn && navMenu) {
    toggleBtn.addEventListener('click', () => {
      navMenu.classList.toggle('show');
    });
  }
}

/* =====================================================
   Demo Online Payment Modal (eSewa / Khalti / Fonepay / Card)
   ===================================================== */
function initDemoPayment() {
  const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
  const checkoutForm = document.getElementById('checkout-form');
  const paymentModal = document.getElementById('demo-payment-modal');
  const paymentCards = document.querySelectorAll('.payment-card-option');

  if (!checkoutForm) return;

  paymentCards.forEach(card => {
    card.addEventListener('click', () => {
      paymentCards.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const radio = card.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });

  // Handle checkout form submission
  checkoutForm.addEventListener('submit', (e) => {
    const selectedMethod = document.querySelector('input[name="payment_method"]:checked')?.value || 'cod';

    // If online demo payment chosen, show simulation popup
    if (selectedMethod !== 'cod' && !window.paymentSimulationCompleted) {
      e.preventDefault();
      openDemoPaymentModal(selectedMethod);
    }
  });
}

function openDemoPaymentModal(method) {
  const modal = document.getElementById('demo-payment-modal');
  const modalTitle = document.getElementById('modal-payment-title');
  const modalIcon = document.getElementById('modal-payment-icon');
  const modalAmount = document.getElementById('modal-payment-amount');
  const totalAmountEl = document.getElementById('summary-grand-total');

  if (!modal) return;

  let title = 'eSewa Mobile Wallet';
  let iconClass = 'fa-wallet text-success';
  let color = '#4ade80';

  if (method === 'khalti') {
    title = 'Khalti Digital Wallet';
    iconClass = 'fa-mobile-screen-button text-purple';
  } else if (method === 'card') {
    title = 'Debit / Credit Card';
    iconClass = 'fa-credit-card text-info';
  }

  if (modalTitle) modalTitle.textContent = `Demo ${title}`;
  if (modalAmount && totalAmountEl) modalAmount.textContent = totalAmountEl.textContent;

  modal.classList.add('show');
}

function closeDemoPaymentModal() {
  const modal = document.getElementById('demo-payment-modal');
  if (modal) modal.classList.remove('show');
}

function simulateDemoPaymentSuccess() {
  const confirmBtn = document.getElementById('btn-confirm-demo-payment');
  if (confirmBtn) {
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Verifying Demo Payment...';
  }

  setTimeout(() => {
    showToast('success', 'Demo payment authorized successfully!');
    window.paymentSimulationCompleted = true;
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
      // Add transaction id
      const txInput = document.createElement('input');
      txInput.type = 'hidden';
      txInput.name = 'demo_tx_id';
      txInput.value = 'TXN-' + Math.floor(100000 + Math.random() * 900000);
      checkoutForm.appendChild(txInput);
      checkoutForm.submit();
    }
  }, 1200);
}

/* =====================================================
   Live Order Status Checker (Real-time Order Tracking)
   ===================================================== */
function initLiveOrderTracker() {
  const orderTracker = document.getElementById('live-order-tracker');
  if (!orderTracker) return;

  const orderNumber = orderTracker.dataset.orderNumber;
  if (!orderNumber) return;

  // Poll order status every 10 seconds for real-time status updates
  setInterval(() => {
    fetch((window.APP_BASE_URL || '') + `/api/order_status.php?order_number=${encodeURIComponent(orderNumber)}`)
      .then(res => res.json())
      .then(data => {
        if (data.success && data.status) {
          updateOrderStatusTrackerUI(data.status, data.step_index);
        }
      })
      .catch(err => console.log('Tracker poll sync'));
  }, 10000);
}

function updateOrderStatusTrackerUI(status, stepIndex) {
  const statusBadge = document.getElementById('order-status-badge');
  const progressBar = document.getElementById('order-timeline-progress-bar');
  const steps = document.querySelectorAll('.timeline-step');

  if (statusBadge) statusBadge.textContent = status;

  if (steps && steps.length > 0) {
    steps.forEach((step, idx) => {
      step.classList.remove('completed', 'current', 'upcoming');
      if (idx < stepIndex) {
        step.classList.add('completed');
      } else if (idx === stepIndex) {
        step.classList.add('current');
      } else {
        step.classList.add('upcoming');
      }
    });

    if (progressBar) {
      const pct = (stepIndex / (steps.length - 1)) * 100;
      progressBar.style.width = `${pct}%`;
    }
  }
}
