<?php
/**
 * BHOJ HUB - Asset Generator for Food Items and Categories
 * Generates beautiful styled SVG graphics for all dishes
 */

$foodsDir = __DIR__ . '/foods';
$catsDir = __DIR__ . '/categories';

if (!is_dir($foodsDir)) mkdir($foodsDir, 0777, true);
if (!is_dir($catsDir)) mkdir($catsDir, 0777, true);

function generateFoodSvg($filename, $title, $nepali, $bg1, $bg2, $emoji, $veg = false) {
    $dietColor = $veg ? '#10b981' : '#ef4444';
    $dietLabel = $veg ? 'VEG' : 'NON-VEG';
    
    $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 450" width="100%" height="100%">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{$bg1}" />
      <stop offset="100%" stop-color="{$bg2}" />
    </linearGradient>
    <radialGradient id="plateGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.18" />
      <stop offset="100%" stop-color="#000000" stop-opacity="0.45" />
    </radialGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000000" flood-opacity="0.4" />
    </filter>
  </defs>

  <!-- Background Canvas -->
  <rect width="600" height="450" fill="url(#grad)" />

  <!-- Subtle Nepali Mandala Grid Pattern Elements -->
  <circle cx="300" cy="205" r="180" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-opacity="0.08" stroke-dasharray="6,6" />
  <circle cx="300" cy="205" r="140" fill="none" stroke="#ffffff" stroke-width="1.5" stroke-opacity="0.12" />

  <!-- Main Plate Surface -->
  <circle cx="300" cy="205" r="115" fill="#1e293b" filter="url(#shadow)" stroke="#334155" stroke-width="3" />
  <circle cx="300" cy="205" r="100" fill="url(#plateGlow)" />

  <!-- Center Food Emoji Icon -->
  <text x="300" y="232" font-size="76" text-anchor="middle" font-family="'Segoe UI Emoji', 'Apple Color Emoji', sans-serif">{$emoji}</text>

  <!-- Diet Badge (Top Right) -->
  <g transform="translate(480, 25)">
    <rect width="95" height="28" rx="14" fill="#0f172a" stroke="{$dietColor}" stroke-width="1.5" />
    <circle cx="18" cy="14" r="5" fill="{$dietColor}" />
    <text x="56" y="19" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="11" font-weight="bold" fill="#ffffff" text-anchor="middle">{$dietLabel}</text>
  </g>

  <!-- Bottom Details Banner -->
  <rect x="0" y="340" width="600" height="110" fill="#090d16" fill-opacity="0.92" />
  <line x1="0" y1="340" x2="600" y2="340" stroke="#ea580c" stroke-width="3" />

  <!-- Food Names -->
  <text x="300" y="380" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="22" font-weight="bold" fill="#ffffff" text-anchor="middle">{$title}</text>
  <text x="300" y="412" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="15" font-weight="600" fill="#fb923c" text-anchor="middle">{$nepali} • BHOJ HUB</text>
</svg>
SVG;

    file_put_contents($filename, $svg);
}

// Generate all food items
$items = [
    // Mo:Mo
    ['chicken_steam_momo.jpg', 'Classic Steamed Chicken Mo:Mo', 'चिकेन स्टिम म:म', '#831843', '#4c0519', '🥟', false],
    ['jhol_momo.jpg', 'Kathmandu Special Jhol Mo:Mo', 'झोल म:म (चिकेन)', '#9a3412', '#431407', '🍲', false],
    ['buff_fried_momo.jpg', 'Crispy Fried Buff Mo:Mo', 'बफ फ्राइड म:म', '#7c2d12', '#3f1a08', '🥟', false],
    ['chilli_c_momo.jpg', 'Chilli Chicken C-Mo:Mo', 'चिल्ली चिकेन सी-म:म', '#991b1b', '#450a0a', '🌶️', false],
    ['paneer_momo.jpg', 'Paneer & Cheese Steam Mo:Mo', 'पनीर र चिज म:म', '#065f46', '#022c22', '🥟', true],

    // Thali & Bhoj
    ['thakali_chicken_thali.jpg', 'Thakali Chicken Thali Set', 'थकाली चिकेन थाली सेट', '#78350f', '#451a03', '🍛', false],
    ['thakali_mutton_thali.jpg', 'Royal Thakali Mutton Thali', 'शाही थकाली खसीको थाली', '#713f12', '#361e05', '🍖', false],
    ['veg_thakali_thali.jpg', 'Organic Veg Thakali Bhoj', 'अर्गानिक भेज थाली', '#064e3b', '#022c22', '🥗', true],

    // Sekuwa
    ['chicken_sekuwa.jpg', 'Dharane Chicken Sekuwa', 'धरान स्पेशल चिकेन सेकुवा', '#9a3412', '#7c2d12', '🍢', false],
    ['mutton_sekuwa.jpg', 'Himalayan Mutton Sekuwa Plate', 'हिमालयन खसीको सेकुवा', '#881337', '#4c0519', '🥩', false],
    ['paneer_tikka.jpg', 'Paneer Tikka Sekuwa Special', 'पनीर टिक्का सेकुवा', '#14532d', '#052e16', '🧀', true],

    // Khaja
    ['samay_baji_set.jpg', 'Bhoj Hub Special Newari Khaja Set', 'नेवारी समय् बजी', '#78350f', '#291b00', '🍱', false],
    ['spicy_chatpate.jpg', 'Kathmandu Spicy Chatpate Box', 'काठमाडौँ स्पाइसी चटपटे', '#c2410c', '#7c2d12', '🥣', true],
    ['pani_puri.jpg', 'Pani Puri Platter (10 pcs)', 'पानी पुरी कम्बो', '#15803d', '#14532d', '🫓', true],
    ['chicken_choila.jpg', 'Spicy Chicken Choila with Chiura', 'चिकेन छोइला र चिउरा', '#b91c1c', '#7f1d1d', '🍗', false],

    // Chowmein
    ['chicken_chowmein.jpg', 'Kathmandu Chicken Chowmein', 'काठमाडौँ चिकेन चाउमिन', '#b45309', '#78350f', '🍝', false],
    ['keema_noodles.jpg', 'Spicy Keema Noodles', 'काठमाडौँ किमा चाउचाउ', '#991b1b', '#581c87', '🍜', false],
    ['veg_chowmein.jpg', 'Veg Hakka Chowmein Bowl', 'भेज हक्का चाउमिन', '#1e3a8a', '#14532d', '🥦', true],

    // Desserts
    ['gulab_jamun.jpg', 'Royal Gulab Jamun (2 Pcs)', 'शाही गुलाब जामुन', '#831843', '#4a044e', '🧆', true],
    ['juju_dhau.jpg', 'Bhaktapur Juju Dhau & Sikarni', 'जुजु धौ र सिकर्नी', '#854d0e', '#3f2c00', '🍮', true],

    // Beverages
    ['sweet_lassi.jpg', 'Sweet Dry-Fruit Creamy Lassi', 'ड्राइ फ्रुट स्वीट लस्सी', '#d97706', '#92400e', '🥛', true],
    ['masala_chiya.jpg', 'Himalayan Spiced Masala Chiya', 'हिमालयन मसला चिया', '#78350f', '#451a03', '☕', true],
    ['mint_cooler.jpg', 'Mint Lemon Lime Cooler', 'पुदिना कागती कुलर', '#047857', '#064e3b', '🍹', true]
];

foreach ($items as $item) {
    generateFoodSvg($foodsDir . '/' . $item[0], $item[1], $item[2], $item[3], $item[4], $item[5], $item[6]);
}

// Generate category icons/placeholders
$categories = [
    ['category_momo.jpg', 'Mo:Mo & Dumplings', '#831843', '#4c0519', '🥟'],
    ['category_thali.jpg', 'Nepali Bhoj & Thali', '#78350f', '#451a03', '🍛'],
    ['category_sekuwa.jpg', 'Sekuwa & Tandoori Grills', '#9a3412', '#7c2d12', '🍢'],
    ['category_khaja.jpg', 'Khaja & Fast Food', '#c2410c', '#7c2d12', '🍱'],
    ['category_noodles.jpg', 'Chowmein & Noodles', '#b45309', '#78350f', '🍝'],
    ['category_desserts.jpg', 'Desserts & Mithai', '#831843', '#4a044e', '🧆'],
    ['category_beverages.jpg', 'Beverages & Lassi', '#d97706', '#92400e', '🍹']
];

foreach ($categories as $cat) {
    generateFoodSvg($catsDir . '/' . $cat[0], $cat[1], 'नेपाली स्वाद', $cat[2], $cat[3], $cat[4], true);
}

// Generate default placeholder & logo
file_put_contents(__DIR__ . '/food_placeholder.svg', <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 450" width="100%" height="100%">
  <rect width="600" height="450" fill="#1e293b" />
  <circle cx="300" cy="200" r="80" fill="#334155" />
  <text x="300" y="225" font-size="60" text-anchor="middle">🍲</text>
  <text x="300" y="340" font-family="sans-serif" font-size="20" font-weight="bold" fill="#94a3b8" text-anchor="middle">BHOJ HUB KITCHEN</text>
</svg>
SVG
);

file_put_contents(__DIR__ . '/logo.svg', <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 50" width="200" height="50">
  <rect x="0" y="5" width="40" height="40" rx="10" fill="#ea580c" />
  <text x="20" y="32" font-size="22" text-anchor="middle" fill="#ffffff">🥟</text>
  <text x="50" y="28" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="22" font-weight="900" fill="#0f172a">BHOJ <tspan fill="#ea580c">HUB</tspan></text>
  <text x="50" y="42" font-family="'Plus Jakarta Sans', Arial, sans-serif" font-size="9" font-weight="700" fill="#64748b" letter-spacing="1">CLOUD KITCHEN KTM</text>
</svg>
SVG
);

echo "Assets generated successfully.\n";
