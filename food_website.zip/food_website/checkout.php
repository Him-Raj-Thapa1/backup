<?php
/**
 * BHOJ HUB - Checkout & Demo Payment Page
 */
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'Checkout & Delivery';
$cart = get_cart();
$totals = get_cart_totals();
$user = current_user();

if (empty($cart)) {
    set_flash('warning', 'Your order tray is empty. Please select food items first.');
    header("Location: " . BASE_URL . "/menu.php");
    exit;
}

$db = getDB();
$errors = [];

// Handle Order Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName = clean($_POST['customer_name'] ?? '');
    $customerEmail = clean($_POST['customer_email'] ?? '');
    $customerPhone = clean($_POST['customer_phone'] ?? '');
    $deliveryAddress = clean($_POST['delivery_address'] ?? '');
    $deliveryCity = clean($_POST['delivery_city'] ?? 'Kathmandu');
    $deliveryNotes = clean($_POST['delivery_notes'] ?? '');
    $paymentMethod = clean($_POST['payment_method'] ?? 'cod');
    $demoTxId = clean($_POST['demo_tx_id'] ?? '');

    // Validation
    if (empty($customerName)) $errors[] = 'Full Name is required.';
    if (empty($customerEmail) || !filter_var($customerEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid Email Address is required.';
    if (empty($customerPhone) || strlen($customerPhone) < 7) $errors[] = 'Valid Mobile Phone number is required.';
    if (empty($deliveryAddress)) $errors[] = 'Delivery Address / Landmark is required.';

    // Validate payment method
    $validMethods = ['cod', 'esewa', 'khalti', 'card'];
    if (!in_array($paymentMethod, $validMethods)) {
        $paymentMethod = 'cod';
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();

            // 1. Verify stock for all items
            foreach ($cart as $foodId => $item) {
                $checkStmt = $db->prepare("SELECT id, name, stock, is_available FROM foods WHERE id = ? FOR UPDATE");
                $checkStmt->execute([$foodId]);
                $food = $checkStmt->fetch();

                if (!$food || !$food['is_available'] || $food['stock'] < $item['quantity']) {
                    throw new Exception("Sorry, '{$item['name']}' has insufficient stock. Only " . ($food['stock'] ?? 0) . " units available.");
                }
            }

            // 2. Determine payment status
            $paymentStatus = ($paymentMethod === 'cod') ? 'pending' : 'paid';
            $orderStatus = 'Pending';
            $orderNumber = generate_order_number();
            $userId = is_logged_in() ? $_SESSION['user_id'] : null;

            // 3. Insert order record
            $orderStmt = $db->prepare("
                INSERT INTO orders (
                    order_number, user_id, customer_name, customer_email, customer_phone, 
                    delivery_address, delivery_city, delivery_notes, subtotal, delivery_fee, 
                    discount, grand_total, payment_method, payment_status, order_status, transaction_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $orderStmt->execute([
                $orderNumber,
                $userId,
                $customerName,
                $customerEmail,
                $customerPhone,
                $deliveryAddress,
                $deliveryCity,
                $deliveryNotes,
                $totals['subtotal'],
                $totals['delivery_fee'],
                0.00,
                $totals['grand_total'],
                $paymentMethod,
                $paymentStatus,
                $orderStatus,
                $demoTxId ?: null
            ]);

            $orderId = $db->lastInsertId();

            // 4. Insert order items & deduct stock
            $itemStmt = $db->prepare("
                INSERT INTO order_items (order_id, food_id, food_name, price, quantity, subtotal) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $deductStockStmt = $db->prepare("
                UPDATE foods 
                SET stock = stock - ?,
                    is_available = CASE WHEN (stock - ?) <= 0 THEN 0 ELSE is_available END 
                WHERE id = ?
            ");

            foreach ($cart as $foodId => $item) {
                $lineTotal = $item['price'] * $item['quantity'];
                $itemStmt->execute([
                    $orderId,
                    $foodId,
                    $item['name'],
                    $item['price'],
                    $item['quantity'],
                    $lineTotal
                ]);

                $deductStockStmt->execute([
                    $item['quantity'],
                    $item['quantity'],
                    $foodId
                ]);
            }

            $db->commit();

            // Clear session cart
            clear_cart();

            set_flash('success', "Your order #{$orderNumber} has been placed successfully!");
            header("Location: " . BASE_URL . "/order_success.php?order=" . urlencode($orderNumber));
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="container py-8">
    <div class="mb-6">
        <span class="badge badge-primary mb-2"><i class="fa-solid fa-truck-fast"></i> Step 2 of 2</span>
        <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--secondary);">Checkout & Delivery Details</h1>
    </div>

    <?php if (!empty($errors)): ?>
        <div style="background: #fee2e2; border: 1px solid #f87171; color: #b91c1c; padding: 16px 20px; border-radius: var(--radius-md); margin-bottom: 24px;">
            <div style="font-weight: 700; margin-bottom: 6px;"><i class="fa-solid fa-triangle-exclamation"></i> Please fix the following errors:</div>
            <ul style="padding-left: 20px; list-style: disc;">
                <?php foreach ($errors as $err): ?>
                    <li><?php echo htmlspecialchars($err); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo BASE_URL; ?>/checkout.php" method="POST" id="checkout-form">
        <div class="cart-layout">
            <!-- Left Column: Delivery & Payment Details -->
            <div>
                <!-- Contact & Delivery Address Card -->
                <div class="cart-items-card mb-6">
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-location-dot text-primary"></i> 1. Contact & Delivery Location
                    </h3>

                    <?php if (!is_logged_in()): ?>
                        <div style="background: #fff7ed; border: 1px solid #fed7aa; padding: 12px 16px; border-radius: var(--radius-md); font-size: 0.85rem; margin-bottom: 20px;">
                            Already have an account? <a href="<?php echo BASE_URL; ?>/login.php?redirect=checkout.php" style="color: var(--primary); font-weight: 700;">Login here</a> to auto-fill your saved address.
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="customer_name" class="form-control" placeholder="e.g. Aayush Shrestha" value="<?php echo htmlspecialchars($_POST['customer_name'] ?? $user['name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone Number *</label>
                            <input type="tel" name="customer_phone" class="form-control" placeholder="e.g. 9841234567" value="<?php echo htmlspecialchars($_POST['customer_phone'] ?? $user['phone'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Email Address *</label>
                            <input type="email" name="customer_email" class="form-control" placeholder="e.g. aayush@example.com" value="<?php echo htmlspecialchars($_POST['customer_email'] ?? $user['email'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">City / Region *</label>
                            <select name="delivery_city" class="form-control" required>
                                <option value="Kathmandu" <?php echo (($user['city'] ?? '') === 'Kathmandu') ? 'selected' : ''; ?>>Kathmandu Valley</option>
                                <option value="Lalitpur" <?php echo (($user['city'] ?? '') === 'Lalitpur') ? 'selected' : ''; ?>>Lalitpur / Patan</option>
                                <option value="Bhaktapur" <?php echo (($user['city'] ?? '') === 'Bhaktapur') ? 'selected' : ''; ?>>Bhaktapur Area</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Delivery Street Address & Landmark *</label>
                        <input type="text" name="delivery_address" class="form-control" placeholder="House/Flat No, Street Name, Near Landmark (e.g. Near Bhatbhateni Baneshwor)" value="<?php echo htmlspecialchars($_POST['delivery_address'] ?? $user['address'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label">Special Cooking / Delivery Instructions (Optional)</label>
                        <textarea name="delivery_notes" class="form-control" placeholder="e.g. Extra spicy achar, ring the bell upon arrival, or call on arrival..."><?php echo htmlspecialchars($_POST['delivery_notes'] ?? ''); ?></textarea>
                    </div>
                </div>

                <!-- Payment Method Selector Card -->
                <div class="cart-items-card">
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                        <i class="fa-solid fa-wallet text-primary"></i> 2. Choose Payment Method
                    </h3>

                    <div class="payment-grid">
                        <!-- Cash on Delivery -->
                        <label class="payment-card-option selected">
                            <input type="radio" name="payment_method" value="cod" checked>
                            <i class="fa-solid fa-money-bill-wave payment-brand-icon text-success"></i>
                            <div class="payment-card-title">Cash on Delivery</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Pay with cash upon arrival</div>
                        </label>

                        <!-- eSewa Demo -->
                        <label class="payment-card-option">
                            <input type="radio" name="payment_method" value="esewa">
                            <i class="fa-solid fa-wallet payment-brand-icon text-success"></i>
                            <div class="payment-card-title">eSewa (Demo)</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Instant Mobile Wallet</div>
                        </label>

                        <!-- Khalti Demo -->
                        <label class="payment-card-option">
                            <input type="radio" name="payment_method" value="khalti">
                            <i class="fa-solid fa-mobile-screen-button payment-brand-icon text-purple"></i>
                            <div class="payment-card-title">Khalti (Demo)</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Khalti Digital Pay</div>
                        </label>

                        <!-- Card Demo -->
                        <label class="payment-card-option">
                            <input type="radio" name="payment_method" value="card">
                            <i class="fa-solid fa-credit-card payment-brand-icon text-info"></i>
                            <div class="payment-card-title">Debit/Credit Card</div>
                            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Visa / Mastercard Demo</div>
                        </label>
                    </div>

                    <div style="font-size: 0.8rem; color: #94a3b8; line-height: 1.5;">
                        <i class="fa-solid fa-circle-info"></i> Note: Online payment options run a safe, interactive demo simulation for testing and presentation purposes.
                    </div>
                </div>
            </div>

            <!-- Right Column: Order Summary Review -->
            <div>
                <div class="cart-summary-card">
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--secondary); margin-bottom: 16px;">
                        Order Items (<?php echo $totals['item_count']; ?>)
                    </h3>

                    <div style="max-height: 240px; overflow-y: auto; margin-bottom: 16px; padding-right: 4px;">
                        <?php foreach ($cart as $foodId => $item): ?>
                            <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid var(--border-light); font-size: 0.9rem;">
                                <div>
                                    <div style="font-weight: 700; color: var(--secondary);"><?php echo htmlspecialchars($item['name']); ?></div>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);"><?php echo $item['quantity']; ?> x <?php echo format_price($item['price']); ?></div>
                                </div>
                                <div style="font-weight: 700; color: var(--secondary);">
                                    <?php echo format_price($item['price'] * $item['quantity']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <strong><?php echo format_price($totals['subtotal']); ?></strong>
                    </div>

                    <div class="summary-row">
                        <span>Delivery Fee</span>
                        <strong class="<?php echo ($totals['delivery_fee'] == 0) ? 'text-success' : ''; ?>">
                            <?php echo ($totals['delivery_fee'] == 0) ? 'FREE' : format_price($totals['delivery_fee']); ?>
                        </strong>
                    </div>

                    <div class="summary-row total">
                        <span>Total to Pay</span>
                        <span id="summary-grand-total" style="color: var(--primary);"><?php echo format_price($totals['grand_total']); ?></span>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg btn-block" id="btn-place-order">
                        <i class="fa-solid fa-lock"></i> Place Your Order
                    </button>

                    <div style="text-align: center; margin-top: 14px;">
                        <a href="<?php echo BASE_URL; ?>/cart.php" style="font-size: 0.85rem; color: var(--text-muted);">
                            <i class="fa-solid fa-arrow-left"></i> Edit Order Items
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Demo Online Payment Simulation Modal -->
<div class="modal-backdrop" id="demo-payment-modal">
    <div class="modal-dialog">
        <div class="modal-header">
            <div class="flex items-center gap-3">
                <i class="fa-solid fa-shield-halved text-success" style="font-size: 1.4rem;"></i>
                <h4 style="font-size: 1.15rem; font-weight: 800; color: var(--secondary);" id="modal-payment-title">Demo Online Payment</h4>
            </div>
            <button type="button" style="background:none; border:none; font-size:1.2rem; cursor:pointer; color:#94a3b8;" onclick="closeDemoPaymentModal()">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>

        <div class="modal-body">
            <div style="background: #f8fafc; border-radius: var(--radius-md); padding: 16px; text-align: center; margin-bottom: 20px; border: 1px solid var(--border-light);">
                <div style="font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700;">Amount to Authorize</div>
                <div style="font-size: 1.8rem; font-weight: 800; color: var(--primary);" id="modal-payment-amount">
                    <?php echo format_price($totals['grand_total']); ?>
                </div>
                <div style="font-size: 0.8rem; color: #16a34a; font-weight: 600;">Merchant: BHOJ HUB CLOUD KITCHEN</div>
            </div>

            <div class="form-group">
                <label class="form-label">Demo Wallet ID / Mobile Number</label>
                <input type="text" class="form-control" value="9841000000" readonly style="background:#f1f5f9;">
            </div>

            <div class="form-group">
                <label class="form-label">Simulated Security PIN / OTP</label>
                <input type="password" class="form-control" value="1234" readonly style="letter-spacing: 4px; font-weight: bold; background:#f1f5f9;">
                <span style="font-size: 0.75rem; color: #64748b; margin-top: 4px; display: block;">Simulated sandbox environment - click confirm to authorize.</span>
            </div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-outline btn-sm" onclick="closeDemoPaymentModal()">Cancel</button>
            <button type="button" class="btn btn-primary btn-sm" id="btn-confirm-demo-payment" onclick="simulateDemoPaymentSuccess()">
                <i class="fa-solid fa-check"></i> Authorize & Place Order
            </button>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
