<?php
/**
 * BHOJ HUB - Customer Order History & Tracking List Page
 */
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'My Food Orders';
$db = getDB();

// If user is logged in, show their orders; if guest, provide order number lookup
$user = current_user();
$orders = [];

if (is_logged_in()) {
    $stmt = $db->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user['id']]);
    $orders = $stmt->fetchAll();
} elseif (isset($_GET['lookup_order'])) {
    $lookupNum = clean($_GET['lookup_order']);
    $stmt = $db->prepare("SELECT * FROM orders WHERE order_number = ? ORDER BY created_at DESC");
    $stmt->execute([$lookupNum]);
    $orders = $stmt->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<div class="container py-8">
    <div class="flex justify-between items-center mb-6 flex-wrap gap-4">
        <div>
            <span class="badge badge-primary mb-2"><i class="fa-solid fa-clock-rotate-left"></i> Real-time Order Log</span>
            <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--secondary);">Order History & Tracking</h1>
        </div>
        <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus"></i> Place New Order
        </a>
    </div>

    <!-- Quick Order Number Lookup for Guest Orders -->
    <?php if (!is_logged_in()): ?>
        <div style="background: var(--bg-surface); padding: 24px; border-radius: var(--radius-lg); border: 1px solid var(--border-light); margin-bottom: 30px; box-shadow: var(--shadow-sm);">
            <h3 style="font-size: 1.15rem; font-weight: 700; color: var(--secondary); margin-bottom: 8px;">Track a Guest Order</h3>
            <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 16px;">
                Enter your order number (e.g. <code>BH-2026-XXXX</code>) to check its live cooking and delivery progress.
            </p>
            <form action="<?php echo BASE_URL; ?>/orders.php" method="GET" class="flex gap-3">
                <input type="text" name="lookup_order" class="form-control" placeholder="Enter Order Number (e.g. BH-2026-8801)" required style="max-width: 380px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-magnifying-glass"></i> Track Order
                </button>
            </form>
        </div>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
        <div style="text-align: center; padding: 70px 20px; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px dashed var(--border-light);">
            <div style="font-size: 3.5rem; margin-bottom: 12px;">📦</div>
            <h3 style="font-size: 1.4rem; font-weight: 700; color: var(--secondary); margin-bottom: 6px;">No Orders Found</h3>
            <p style="color: var(--text-muted); margin-bottom: 20px;">
                <?php if (is_logged_in()): ?>
                    You haven't placed any food orders yet. Ready for some delicious Mo:Mo?
                <?php else: ?>
                    Please login to see your full order history or search with an order number above.
                <?php endif; ?>
            </p>
            <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-primary">
                <i class="fa-solid fa-utensils"></i> Browse Kitchen Menu
            </a>
        </div>
    <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <?php foreach ($orders as $ord): ?>
                <?php
                // Fetch item summary
                $itStmt = $db->prepare("SELECT food_name, quantity FROM order_items WHERE order_id = ?");
                $itStmt->execute([$ord['id']]);
                $orderItems = $itStmt->fetchAll();

                $statusClass = 'badge-warning';
                if ($ord['order_status'] === 'Delivered') $statusClass = 'badge-success';
                elseif ($ord['order_status'] === 'Preparing' || $ord['order_status'] === 'Confirmed') $statusClass = 'badge-info';
                elseif ($ord['order_status'] === 'Out for Delivery') $statusClass = 'badge-purple';
                elseif ($ord['order_status'] === 'Cancelled') $statusClass = 'badge-danger';
                ?>
                <div style="background: var(--bg-surface); border: 1px solid var(--border-light); border-radius: var(--radius-lg); padding: 24px; box-shadow: var(--shadow-sm); transition: var(--transition);">
                    <div class="flex justify-between items-center flex-wrap gap-4 pb-4 mb-4" style="border-bottom: 1px solid var(--border-light);">
                        <div class="flex items-center gap-4 flex-wrap">
                            <div>
                                <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Order Number</span>
                                <div style="font-weight: 800; font-size: 1.15rem; color: var(--secondary);"><?php echo htmlspecialchars($ord['order_number']); ?></div>
                            </div>
                            <div style="border-left: 1px solid var(--border-light); padding-left: 16px;">
                                <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Placed On</span>
                                <div style="font-size: 0.9rem; color: var(--text-main); font-weight: 600;"><?php echo date('M d, Y - h:i A', strtotime($ord['created_at'])); ?></div>
                            </div>
                        </div>

                        <div class="flex items-center gap-3">
                            <span class="badge <?php echo $statusClass; ?>" style="font-size: 0.85rem; padding: 6px 14px;">
                                <i class="fa-solid fa-circle-dot"></i> <?php echo htmlspecialchars($ord['order_status']); ?>
                            </span>
                        </div>
                    </div>

                    <div class="flex justify-between items-center flex-wrap gap-4">
                        <div>
                            <div style="font-size: 0.9rem; color: var(--text-main); margin-bottom: 6px;">
                                <strong>Dishes:</strong> 
                                <?php 
                                $itemList = [];
                                foreach ($orderItems as $item) {
                                    $itemList[] = htmlspecialchars($item['food_name']) . " (×" . $item['quantity'] . ")";
                                }
                                echo implode(', ', $itemList);
                                ?>
                            </div>
                            <div style="font-size: 0.85rem; color: var(--text-muted);">
                                <i class="fa-solid fa-location-dot text-primary"></i> <?php echo htmlspecialchars($ord['delivery_address'] . ', ' . $ord['delivery_city']); ?>
                            </div>
                        </div>

                        <div class="flex items-center gap-6">
                            <div>
                                <div style="font-size: 0.75rem; color: var(--text-muted); text-align: right; text-transform: uppercase; font-weight: 600;">Grand Total</div>
                                <div style="font-size: 1.3rem; font-weight: 800; color: var(--primary); text-align: right;">
                                    <?php echo format_price($ord['grand_total']); ?>
                                </div>
                            </div>
                            <a href="<?php echo BASE_URL; ?>/order_details.php?order=<?php echo urlencode($ord['order_number']); ?>" class="btn btn-outline-primary btn-sm">
                                <i class="fa-solid fa-satellite-dish"></i> View / Track
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
