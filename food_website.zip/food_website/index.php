<?php
/**
 * BHOJ HUB - Modern Nepali Cloud Kitchen Homepage
 */
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'Authentic Nepali Cloud Kitchen & Food Delivery';
$db = getDB();

// Fetch categories from DB
$categories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();

// Fetch featured foods
$featuredFoods = $db->query("
    SELECT f.*, c.name AS category_name 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.is_featured = 1 AND f.is_available = 1 
    ORDER BY f.id ASC 
    LIMIT 8
")->fetchAll();

// Fetch popular dishes (combining featured + best reviewed)
$popularFoods = $db->query("
    SELECT f.*, c.name AS category_name 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.is_available = 1 
    ORDER BY f.stock DESC, f.id ASC 
    LIMIT 6
")->fetchAll();

// Fetch recent customer reviews
$reviews = $db->query("
    SELECT r.*, u.name AS user_name, f.name AS food_name 
    FROM reviews r 
    JOIN users u ON r.user_id = u.id 
    JOIN foods f ON r.food_id = f.id 
    ORDER BY r.created_at DESC 
    LIMIT 3
")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-glow"></div>
    <div class="container">
        <div class="hero-grid">
            <div>
                <div class="hero-badge">
                    <i class="fa-solid fa-pepper-hot text-primary"></i> Chitwan's #1 Cloud Kitchen
                </div>
                <h1 class="hero-title">
                    Taste Authentic Nepali <span>Bhoj & Mo:Mo</span> Delivered Hot.
                </h1>
                <p class="hero-lead">
                    Handmade Himalayan dumplings, slow-simmered Thakali thalis, charcoal sekuwa, and Kathmandu street snacks cooked fresh to order and delivered swiftly to your doorstep.
                </p>
                <div class="flex items-center gap-4 flex-wrap">
                    <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-primary btn-lg">
                        <i class="fa-solid fa-utensils"></i> Order Food Now
                    </a>
                    <a href="<?php echo BASE_URL; ?>/menu.php?filter=featured" class="btn btn-outline" style="color:white; border-color:rgba(255,255,255,0.25);">
                        <i class="fa-solid fa-star text-primary"></i> Chef's Specials
                    </a>
                </div>

                <div class="hero-stats">
                    <div class="hero-stat-item">
                        <h4>30-40 min</h4>
                        <p>Average Delivery</p>
                    </div>
                    <div class="hero-stat-item">
                        <h4>100% Fresh</h4>
                        <p>Local Ingredients</p>
                    </div>
                    <div class="hero-stat-item">
                        <h4>Free Delivery</h4>
                        <p>Orders Above Rs. 1000</p>
                    </div>
                </div>
            </div>

            <!-- Hero Visual Card -->
            <div class="hero-visual">
                <div class="hero-dish-card">
                    <div class="hero-image-wrap">
                        <img src="<?php echo food_image('https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80'); ?>" alt="Thakali Thali Special">
                        <div class="hero-floating-tag">
                            <span class="diet-indicator non-veg"></span>
                            <span>Thakali Special Bhoj • Rs. 420</span>
                        </div>
                    </div>
                    <div class="flex justify-between items-center mt-4">
                        <div>
                            <div style="font-weight: 700; font-size: 1.1rem; color: white;">Mustang Thakali Chicken Thali</div>
                            <div style="font-size: 0.85rem; color: #94a3b8;">Jhinuwa Rice • Kalo Dal • Gundruk Achar</div>
                        </div>
                        <button class="btn btn-primary btn-sm btn-add-to-cart" data-food-id="6">
                            <i class="fa-solid fa-plus"></i> Add
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Search & Quick Navigation Bar -->
<div class="container">
    <div class="search-filter-card">
        <form action="<?php echo BASE_URL; ?>/menu.php" method="GET" class="flex gap-4 items-center flex-wrap">
            <div class="search-input-group" style="flex: 1;">
                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                <input type="text" name="search" class="search-field" placeholder="Search Mo:Mo, Thakali Thali, Sekuwa, Chowmein, Lassi..." id="home-search-input">
            </div>
            <button type="submit" class="btn btn-primary btn-lg" style="height: 52px;">
                <i class="fa-solid fa-magnifying-glass"></i> Search Food
            </button>
        </form>

        <!-- Quick Tags -->
        <div class="flex items-center gap-2 mt-4 flex-wrap" style="font-size: 0.85rem;">
            <span style="color: var(--text-muted); font-weight: 600;">Popular Searches:</span>
            <a href="<?php echo BASE_URL; ?>/menu.php?search=momo" class="badge badge-primary">🥟 Steamed Mo:Mo</a>
            <a href="<?php echo BASE_URL; ?>/menu.php?search=thali" class="badge badge-primary">🍛 Thakali Thali</a>
            <a href="<?php echo BASE_URL; ?>/menu.php?search=sekuwa" class="badge badge-primary">🍢 Sekuwa</a>
            <a href="<?php echo BASE_URL; ?>/menu.php?search=chowmein" class="badge badge-primary">🍝 Chowmein</a>
            <a href="<?php echo BASE_URL; ?>/menu.php?search=lassi" class="badge badge-primary">🥛 Sweet Lassi</a>
        </div>
    </div>
</div>

<!-- Categories Section -->
<section class="py-12">
    <div class="container">
        <div class="section-header">
            <div>
                <span class="badge badge-primary mb-2">Delicious Categories</span>
                <h2 class="section-title">Explore Our Cloud Kitchen Menu</h2>
                <p class="section-subtitle">Authentic Himalayan recipes crafted with fresh spices</p>
            </div>
            <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-outline-primary btn-sm">
                View Full Menu <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="category-grid">
            <?php foreach ($categories as $cat): ?>
                <a href="<?php echo BASE_URL; ?>/menu.php?category=<?php echo urlencode($cat['slug']); ?>" class="category-card">
                    <div class="cat-icon-wrap">
                        <i class="fa-solid <?php echo htmlspecialchars($cat['icon'] ?: 'fa-utensils'); ?>"></i>
                    </div>
                    <div class="cat-card-title"><?php echo htmlspecialchars($cat['name']); ?></div>
                    <div class="cat-card-nepali"><?php echo htmlspecialchars($cat['nepali_name'] ?: ''); ?></div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Foods Section -->
<section class="py-12" style="background: var(--bg-subtle);">
    <div class="container">
        <div class="section-header">
            <div>
                <span class="badge badge-primary mb-2">Chef's Recommendations</span>
                <h2 class="section-title">Featured Culinary Delicacies</h2>
                <p class="section-subtitle">Our top signature dishes loved across Chitwan</p>
            </div>
            <a href="<?php echo BASE_URL; ?>/menu.php?filter=featured" class="btn btn-outline-primary btn-sm">
                See All Specials <i class="fa-solid fa-arrow-right"></i>
            </a>
        </div>

        <div class="food-grid">
            <?php foreach ($featuredFoods as $food): ?>
                <?php
                $isInStock = (int)$food['stock'] > 0;
                $hasDiscount = !empty($food['discount_price']) && $food['discount_price'] > 0;
                $activePrice = $hasDiscount ? $food['discount_price'] : $food['price'];
                ?>
                <div class="food-card <?php echo !$isInStock ? 'out-of-stock' : ''; ?>">
                    <div class="food-image-container">
                        <img src="<?php echo food_image($food['image']); ?>" alt="<?php echo htmlspecialchars($food['name']); ?>">
                        
                        <!-- Badges -->
                        <div class="food-badge-top-left">
                            <span class="diet-indicator <?php echo $food['is_veg'] ? 'veg' : 'non-veg'; ?>" title="<?php echo $food['is_veg'] ? 'Pure Vegetarian' : 'Non-Vegetarian'; ?>"></span>
                            <?php if ($hasDiscount): ?>
                                <span class="badge badge-danger">SAVE <?php echo format_price($food['price'] - $food['discount_price']); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="food-badge-top-right">
                            <?php if ($isInStock): ?>
                                <span class="badge badge-dark" style="font-size:0.7rem;"><i class="fa-solid fa-boxes-stacked"></i> <?php echo $food['stock']; ?> left</span>
                            <?php endif; ?>
                        </div>

                        <?php if (!$isInStock): ?>
                            <div class="out-of-stock-overlay">
                                <span><i class="fa-solid fa-ban"></i> Out of Stock</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="food-card-body">
                        <div class="food-category-meta">
                            <span><?php echo htmlspecialchars($food['category_name']); ?></span>
                            <span><i class="fa-regular fa-clock"></i> <?php echo htmlspecialchars($food['prep_time']); ?></span>
                        </div>

                        <h3 class="food-title">
                            <a href="<?php echo BASE_URL; ?>/food_details.php?id=<?php echo $food['id']; ?>">
                                <?php echo htmlspecialchars($food['name']); ?>
                            </a>
                        </h3>

                        <?php if (!empty($food['nepali_name'])): ?>
                            <div class="food-nepali-title"><?php echo htmlspecialchars($food['nepali_name']); ?></div>
                        <?php endif; ?>

                        <p class="food-description">
                            <?php echo htmlspecialchars($food['description']); ?>
                        </p>

                        <div class="food-spec-row">
                            <span title="Spiciness Level">
                                <i class="fa-solid fa-pepper-hot" style="color: <?php echo ($food['spicy_level'] > 1) ? 'var(--primary)' : '#94a3b8'; ?>;"></i>
                                <?php 
                                $spicyLabels = [0 => 'Mild', 1 => 'Medium', 2 => 'Spicy', 3 => 'Fiery Hot'];
                                echo $spicyLabels[$food['spicy_level']] ?? 'Medium';
                                ?>
                            </span>
                            <span>•</span>
                            <span class="text-success"><i class="fa-solid fa-check"></i> Fresh Made</span>
                        </div>

                        <div class="food-footer">
                            <div class="price-tag">
                                <span class="current-price"><?php echo format_price($activePrice); ?></span>
                                <?php if ($hasDiscount): ?>
                                    <span class="original-price"><?php echo format_price($food['price']); ?></span>
                                <?php endif; ?>
                            </div>

                            <?php if ($isInStock): ?>
                                <button class="btn btn-primary btn-sm btn-add-to-cart" data-food-id="<?php echo $food['id']; ?>">
                                    <i class="fa-solid fa-cart-plus"></i> Add
                                </button>
                            <?php else: ?>
                                <button class="btn btn-outline btn-sm disabled" disabled>
                                    Sold Out
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Promotional Banner -->
<section class="py-12">
    <div class="container">
        <div style="background: linear-gradient(135deg, #111827 0%, #1f2937 100%); border-radius: var(--radius-xl); padding: 40px; color: white; display: flex; align-items: center; justify-content: space-between; gap: 30px; flex-wrap: wrap; border: 1px solid #374151;">
            <div style="max-width: 600px;">
                <span class="badge badge-warning mb-2"><i class="fa-solid fa-gift"></i> Special Bhoj Offer</span>
                <h3 style="font-size: 2rem; font-weight: 800; margin-bottom: 10px;">Free Express Delivery Above <?php echo format_price(FREE_DELIVERY_THRESHOLD); ?>!</h3>
                <p style="color: #cbd5e1; font-size: 1rem;">
                    Order your favorite Thakali sets, Mo:Mo platters, and Sekuwa skewers. We deliver hot and fresh within 40 minutes anywhere in Chitwan, Birendranagar, and Bharatpur.
                </p>
            </div>
            <div>
                <a href="<?php echo BASE_URL; ?>/menu.php" class="btn btn-primary btn-lg">
                    <i class="fa-solid fa-bag-shopping"></i> Order Now & Save
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Reviews & Testimonials -->
<section class="py-12" style="background: var(--bg-surface); border-top: 1px solid var(--border-light);">
    <div class="container">
        <div class="section-header text-center" style="flex-direction: column; align-items: center;">
            <span class="badge badge-primary mb-2">Real Foodies</span>
            <h2 class="section-title">What Chitwan Says About BHOJ HUB</h2>
            <p class="section-subtitle">Real feedback from our regular customers</p>
        </div>

        <div class="grid grid-cols-3 gap-6" style="margin-top: 30px;">
            <?php foreach ($reviews as $rev): ?>
                <div style="background: var(--bg-main); border: 1px solid var(--border-light); border-radius: var(--radius-lg); padding: 24px;">
                    <div style="display: flex; gap: 4px; color: #f59e0b; margin-bottom: 12px;">
                        <?php for ($i = 0; $i < $rev['rating']; $i++): ?>
                            <i class="fa-solid fa-star"></i>
                        <?php endfor; ?>
                    </div>
                    <p style="font-style: italic; color: #334155; font-size: 0.95rem; margin-bottom: 16px; line-height: 1.6;">
                        "<?php echo htmlspecialchars($rev['comment']); ?>"
                    </p>
                    <div style="border-top: 1px solid var(--border-light); padding-top: 12px; display: flex; justify-content: space-between; align-items: center;">
                        <div style="font-weight: 700; color: var(--secondary); font-size: 0.9rem;">
                            <?php echo htmlspecialchars($rev['user_name']); ?>
                        </div>
                        <div style="font-size: 0.75rem; color: var(--primary); font-weight: 600;">
                            <?php echo htmlspecialchars($rev['food_name']); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>
