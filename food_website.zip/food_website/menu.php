<?php
/**
 * BHOJ HUB - Dedicated Interactive Food Menu Page
 */
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'Browse Full Menu';
$db = getDB();

// Query Parameters
$selectedCategory = clean($_GET['category'] ?? 'all');
$searchQuery = clean($_GET['search'] ?? '');
$filterType = clean($_GET['filter'] ?? ''); // 'featured', 'veg', etc.

// Fetch all active categories
$categories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();

// Fetch all active foods
$sql = "
    SELECT f.*, c.name AS category_name, c.slug AS category_slug 
    FROM foods f 
    JOIN categories c ON f.category_id = c.id 
    WHERE f.is_available = 1 
    ORDER BY f.is_featured DESC, f.category_id ASC, f.id ASC
";
$foods = $db->query($sql)->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="py-8" style="background: linear-gradient(135deg, #090d16 0%, #1e293b 100%); color: white; border-bottom: 1px solid #334155;">
    <div class="container">
        <div class="flex justify-between items-center flex-wrap gap-4">
            <div>
                <span class="badge badge-primary mb-2"><i class="fa-solid fa-fire"></i> Fresh From Kitchen</span>
                <h1 style="font-size: 2.4rem; font-weight: 800; line-height: 1.2;">BHOJ HUB Menu</h1>
                <p style="color: #cbd5e1; font-size: 1rem; margin-top: 4px;">
                    Handcrafted Himalayan recipes, sizzlers, dumplings & authentic Nepali delicacies.
                </p>
            </div>
            <div class="flex items-center gap-3">
                <div style="background: rgba(255,255,255,0.08); padding: 10px 18px; border-radius: var(--radius-md); border: 1px solid rgba(255,255,255,0.12); font-size: 0.9rem;">
                    <span class="text-success"><i class="fa-solid fa-circle-check"></i> Kitchen Status:</span> <strong>Accepting Orders</strong>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container py-8">
    <!-- Menu Search & Filter Controls -->
    <div class="search-filter-card mb-8" style="margin-top: 0;">
        <div class="grid grid-cols-1 gap-4">
            <!-- Search Bar Row -->
            <div class="search-input-group">
                <i class="fa-solid fa-magnifying-glass search-icon"></i>
                <input type="text" id="food-search-input" class="search-field" placeholder="Search by dish name, Nepali name, or ingredients..." value="<?php echo htmlspecialchars($searchQuery); ?>">
            </div>

            <!-- Category Pills Bar -->
            <div class="category-chips">
                <button type="button" class="category-chip <?php echo ($selectedCategory === 'all' && empty($filterType)) ? 'active' : ''; ?>" data-category="all">
                    <i class="fa-solid fa-border-all"></i> All Dishes (<?php echo count($foods); ?>)
                </button>
                <button type="button" class="category-chip <?php echo ($filterType === 'featured') ? 'active' : ''; ?>" data-category="featured">
                    <i class="fa-solid fa-star" style="color: #f59e0b;"></i> Chef's Specials
                </button>
                <?php foreach ($categories as $cat): ?>
                    <button type="button" class="category-chip <?php echo ($selectedCategory === $cat['slug'] && empty($filterType)) ? 'active' : ''; ?>" data-category="<?php echo htmlspecialchars($cat['slug']); ?>">
                        <i class="fa-solid <?php echo htmlspecialchars($cat['icon'] ?: 'fa-utensils'); ?>"></i>
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </button>
                <?php endforeach; ?>
            </div>

            <!-- Secondary Filters (Veg toggle & Price sort) -->
            <div class="flex justify-between items-center flex-wrap gap-4 pt-4" style="border-top: 1px solid var(--border-light);">
                <div class="flex items-center gap-4">
                    <label class="flex items-center gap-2" style="cursor: pointer; font-size: 0.9rem; font-weight: 600;">
                        <input type="checkbox" id="veg-only-filter" <?php echo ($filterType === 'veg') ? 'checked' : ''; ?> style="accent-color: var(--veg); width: 18px; height: 18px;">
                        <span class="diet-indicator veg"></span> Show Pure Veg Only
                    </label>
                </div>

                <div class="flex items-center gap-2">
                    <label for="sort-price-filter" style="font-size: 0.85rem; color: var(--text-muted); font-weight: 600;">Sort By:</label>
                    <select id="sort-price-filter" class="form-control" style="padding: 6px 14px; font-size: 0.85rem; width: auto;">
                        <option value="default">Featured / Recommended</option>
                        <option value="price_asc">Price: Low to High</option>
                        <option value="price_desc">Price: High to Low</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Empty Results Notice -->
    <div id="no-food-results" style="display: none; text-align: center; padding: 60px 20px; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px dashed var(--border-light);">
        <div style="font-size: 3rem; margin-bottom: 12px;">🔍</div>
        <h3 style="font-size: 1.4rem; font-weight: 700; color: var(--secondary);">No Matching Dishes Found</h3>
        <p style="color: var(--text-muted); margin-top: 6px;">Try adjusting your search terms or selecting a different category.</p>
        <button type="button" class="btn btn-outline-primary btn-sm mt-4" onclick="document.getElementById('food-search-input').value=''; document.querySelector('.category-chip[data-category=all]').click();">
            Reset Filters
        </button>
    </div>

    <!-- Foods Grid -->
    <div class="food-grid">
        <?php foreach ($foods as $food): ?>
            <?php
            $isInStock = (int)$food['stock'] > 0;
            $hasDiscount = !empty($food['discount_price']) && $food['discount_price'] > 0;
            $activePrice = $hasDiscount ? $food['discount_price'] : $food['price'];
            ?>
            <div class="food-card food-grid-item <?php echo !$isInStock ? 'out-of-stock' : ''; ?>"
                 data-name="<?php echo htmlspecialchars($food['name']); ?>"
                 data-nepali="<?php echo htmlspecialchars($food['nepali_name'] ?: ''); ?>"
                 data-desc="<?php echo htmlspecialchars($food['description'] ?: ''); ?>"
                 data-category="<?php echo htmlspecialchars($food['category_slug']); ?>"
                 data-price="<?php echo $activePrice; ?>"
                 data-is-veg="<?php echo $food['is_veg']; ?>"
                 data-is-featured="<?php echo $food['is_featured']; ?>"
                 data-food-id="<?php echo $food['id']; ?>">
                
                <div class="food-image-container">
                    <img src="<?php echo food_image($food['image']); ?>" alt="<?php echo htmlspecialchars($food['name']); ?>" loading="lazy">
                    
                    <!-- Badges -->
                    <div class="food-badge-top-left">
                        <span class="diet-indicator <?php echo $food['is_veg'] ? 'veg' : 'non-veg'; ?>" title="<?php echo $food['is_veg'] ? 'Pure Vegetarian' : 'Non-Vegetarian'; ?>"></span>
                        <?php if ($hasDiscount): ?>
                            <span class="badge badge-danger">SAVE <?php echo format_price($food['price'] - $food['discount_price']); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="food-badge-top-right">
                        <?php if ($isInStock): ?>
                            <span class="badge badge-dark" style="font-size:0.7rem;"><i class="fa-solid fa-boxes-stacked"></i> <?php echo $food['stock']; ?> left</span>
                        <?php endif; ?>
                    </div>

                    <?php if (!$isInStock): ?>
                        <div class="out-of-stock-overlay">
                            <span><i class="fa-solid fa-ban"></i> Out of Stock</span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="food-card-body">
                    <div class="food-category-meta">
                        <span><?php echo htmlspecialchars($food['category_name']); ?></span>
                        <span><i class="fa-regular fa-clock"></i> <?php echo htmlspecialchars($food['prep_time']); ?></span>
                    </div>

                    <h3 class="food-title">
                        <a href="<?php echo BASE_URL; ?>/food_details.php?id=<?php echo $food['id']; ?>">
                            <?php echo htmlspecialchars($food['name']); ?>
                        </a>
                    </h3>

                    <?php if (!empty($food['nepali_name'])): ?>
                        <div class="food-nepali-title"><?php echo htmlspecialchars($food['nepali_name']); ?></div>
                    <?php endif; ?>

                    <p class="food-description">
                        <?php echo htmlspecialchars($food['description']); ?>
                    </p>

                    <div class="food-spec-row">
                        <span title="Spiciness Level">
                            <i class="fa-solid fa-pepper-hot" style="color: <?php echo ($food['spicy_level'] > 1) ? 'var(--primary)' : '#94a3b8'; ?>;"></i>
                            <?php 
                            $spicyLabels = [0 => 'Mild', 1 => 'Medium', 2 => 'Spicy', 3 => 'Fiery Hot'];
                            echo $spicyLabels[$food['spicy_level']] ?? 'Medium';
                            ?>
                        </span>
                        <span>•</span>
                        <span class="text-success"><i class="fa-solid fa-kitchen-set"></i> Made to Order</span>
                    </div>

                    <div class="food-footer">
                        <div class="price-tag">
                            <span class="current-price"><?php echo format_price($activePrice); ?></span>
                            <?php if ($hasDiscount): ?>
                                <span class="original-price"><?php echo format_price($food['price']); ?></span>
                            <?php endif; ?>
                        </div>

                        <?php if ($isInStock): ?>
                            <button class="btn btn-primary btn-sm btn-add-to-cart" data-food-id="<?php echo $food['id']; ?>">
                                <i class="fa-solid fa-cart-plus"></i> Add
                            </button>
                        <?php else: ?>
                            <button class="btn btn-outline btn-sm disabled" disabled>
                                Sold Out
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
