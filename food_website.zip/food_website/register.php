<?php
/**
 * BHOJ HUB - Customer Registration Page
 */
require_once __DIR__ . '/config/helpers.php';

if (is_logged_in()) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$db = getDB();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $address = clean($_POST['address'] ?? '');
    $city = clean($_POST['city'] ?? 'Kathmandu');

    // Validation
    if (empty($name)) $errors[] = 'Full Name is required.';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid Email is required.';
    if (empty($phone) || strlen($phone) < 7) $errors[] = 'Valid phone number is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirmPassword) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        // Check if email already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with this email already exists. Please login.';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $insert = $db->prepare("
                INSERT INTO users (name, email, phone, password, address, city, role, status) 
                VALUES (?, ?, ?, ?, ?, ?, 'customer', 'active')
            ");
            $insert->execute([$name, $email, $phone, $hashedPassword, $address, $city]);
            $newUserId = $db->lastInsertId();

            // Auto-login newly registered user
            $_SESSION['user_id'] = $newUserId;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_phone'] = $phone;
            $_SESSION['user_address'] = $address;
            $_SESSION['user_city'] = $city;
            $_SESSION['user_role'] = 'customer';

            set_flash('success', "Welcome to BHOJ HUB, {$name}! Your account is ready.");
            header("Location: " . BASE_URL . "/index.php");
            exit;
        }
    }
}

$pageTitle = 'Register New Account';
include __DIR__ . '/includes/header.php';
?>

<div class="container py-12">
    <div style="max-width: 500px; margin: 0 auto; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px solid var(--border-light); padding: 36px; box-shadow: var(--shadow-lg);">
        <div class="text-center mb-6">
            <div class="logo-symbol" style="margin: 0 auto 12px; width: 50px; height: 50px; font-size: 1.6rem;">
                <span>🥟</span>
            </div>
            <h1 style="font-size: 1.7rem; font-weight: 800; color: var(--secondary);">Create Your Account</h1>
            <p style="color: var(--text-muted); font-size: 0.9rem; margin-top: 4px;">Join BHOJ HUB to order your favorite Nepali dishes fast</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div style="background: #fee2e2; border: 1px solid #f87171; color: #b91c1c; padding: 12px 16px; border-radius: var(--radius-md); font-size: 0.9rem; margin-bottom: 20px;">
                <?php foreach ($errors as $err): ?>
                    <div><i class="fa-solid fa-circle-exclamation"></i> <?php echo htmlspecialchars($err); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo BASE_URL; ?>/register.php" method="POST">
            <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" name="name" class="form-control" placeholder="e.g. Aayush Shrestha" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="form-group">
                    <label class="form-label">Email Address *</label>
                    <input type="email" name="email" class="form-control" placeholder="aayush@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Mobile Number *</label>
                    <input type="tel" name="phone" class="form-control" placeholder="98XXXXXXXX" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="form-group">
                    <label class="form-label">City *</label>
                    <select name="city" class="form-control">
                        <option value="Kathmandu">Kathmandu</option>
                        <option value="Lalitpur">Lalitpur</option>
                        <option value="Bhaktapur">Bhaktapur</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Default Address</label>
                    <input type="text" name="address" class="form-control" placeholder="House/Street" value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>">
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-control" placeholder="Min 6 chars" required minlength="6">
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm Password *</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter" required minlength="6">
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-lg btn-block mt-4">
                <i class="fa-solid fa-user-plus"></i> Create Account
            </button>
        </form>

        <div class="text-center mt-6" style="font-size: 0.9rem; color: var(--text-muted);">
            Already have an account? <a href="<?php echo BASE_URL; ?>/login.php" style="color: var(--primary); font-weight: 700;">Login here</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
