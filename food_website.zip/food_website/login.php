<?php
/**
 * BHOJ HUB - Common Unified Login Page
 * Supports separate User (Customer) and Admin authentication flows.
 */
require_once __DIR__ . '/config/helpers.php';

// If already logged in, redirect to respective separate interfaces
if (is_admin()) {
    header("Location: " . BASE_URL . "/admin/index.php");
    exit;
} elseif (is_logged_in()) {
    header("Location: " . BASE_URL . "/index.php");
    exit;
}

$db = getDB();
$errors = [];
$loginType = clean($_GET['type'] ?? ($_POST['login_type'] ?? 'user'));
if ($loginType !== 'admin') {
    $loginType = 'user';
}
$redirect = clean($_GET['redirect'] ?? ($_POST['redirect'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $loginType = clean($_POST['login_type'] ?? 'user');
    $redirect = clean($_POST['redirect'] ?? '');

    if (empty($email)) $errors[] = 'Email address is required.';
    if (empty($password)) $errors[] = 'Password is required.';

    if (empty($errors)) {
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Check the selected login type against the actual account role
            if ($loginType === 'admin') {
                if ($user['role'] !== 'admin') {
                    $errors[] = 'Access denied. This account does not have administrator privileges. Please select the "User" tab.';
                } else {
                    // Authenticate as Admin
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_phone'] = $user['phone'];
                    $_SESSION['user_address'] = $user['address'];
                    $_SESSION['user_city'] = $user['city'];
                    $_SESSION['user_role'] = 'admin';

                    set_flash('success', "Welcome to BHOJ HUB Kitchen Admin Dashboard, {$user['name']}!");
                    header("Location: " . BASE_URL . "/admin/index.php");
                    exit;
                }
            } else {
                // User / Customer Login
                if ($user['role'] === 'admin') {
                    $errors[] = 'This is an Administrator account. Please select the "Admin" tab to sign in.';
                } else {
                    // Authenticate as Customer
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_phone'] = $user['phone'];
                    $_SESSION['user_address'] = $user['address'];
                    $_SESSION['user_city'] = $user['city'];
                    $_SESSION['user_role'] = 'customer';

                    set_flash('success', "Welcome back, {$user['name']}! Ready for some delicious food?");

                    $targetUrl = BASE_URL . "/index.php";
                    if (!empty($redirect)) {
                        $cleanRedir = ltrim($redirect, '/');
                        if (!str_starts_with($cleanRedir, 'admin')) {
                            $targetUrl = str_starts_with($redirect, 'http') ? $redirect : BASE_URL . "/" . $cleanRedir;
                        }
                    }

                    header("Location: " . $targetUrl);
                    exit;
                }
            }
        } else {
            $errors[] = 'Invalid email address or password.';
        }
    }
}

$pageTitle = ($loginType === 'admin') ? 'Admin Login | BHOJ HUB' : 'User Login | BHOJ HUB';
include __DIR__ . '/includes/header.php';
?>

<div class="container py-16">
    <div style="max-width: 440px; margin: 0 auto; background: var(--bg-surface); border-radius: var(--radius-xl); border: 1px solid var(--border-light); padding: 36px; box-shadow: var(--shadow-lg);">
        <div class="text-center mb-6">
            <div class="logo-symbol" style="margin: 0 auto 12px; width: 50px; height: 50px; font-size: 1.6rem;">
                <span id="login-brand-icon"><?php echo ($loginType === 'admin') ? '🛡️' : '🥟'; ?></span>
            </div>
            <h1 id="login-title" style="font-size: 1.65rem; font-weight: 800; color: var(--secondary);">
                <?php echo ($loginType === 'admin') ? 'Admin Portal Login' : 'Welcome Back'; ?>
            </h1>
            <p id="login-subtitle" style="color: var(--text-muted); font-size: 0.9rem; margin-top: 4px;">
                <?php echo ($loginType === 'admin') ? 'Sign in to access Kitchen Dashboard' : 'Login to your BHOJ HUB customer account'; ?>
            </p>
        </div>

        <!-- Choice: [ User ] [ Admin ] Tabs -->
        <div style="display: flex; background: #0f172a; padding: 4px; border-radius: var(--radius-full); border: 1px solid var(--border-light); margin-bottom: 24px;">
            <button type="button" id="tab-btn-user" onclick="setLoginType('user')" 
                    style="flex: 1; padding: 10px; border-radius: var(--radius-full); border: none; font-weight: 700; font-size: 0.9rem; cursor: pointer; transition: var(--transition); <?php echo ($loginType === 'user') ? 'background: var(--primary); color: white;' : 'background: transparent; color: #94a3b8;'; ?>">
                <i class="fa-solid fa-user"></i> User
            </button>
            <button type="button" id="tab-btn-admin" onclick="setLoginType('admin')" 
                    style="flex: 1; padding: 10px; border-radius: var(--radius-full); border: none; font-weight: 700; font-size: 0.9rem; cursor: pointer; transition: var(--transition); <?php echo ($loginType === 'admin') ? 'background: #ea580c; color: white;' : 'background: transparent; color: #94a3b8;'; ?>">
                <i class="fa-solid fa-shield-halved"></i> Admin
            </button>
        </div>

        <?php if (!empty($errors)): ?>
            <div style="background: #fee2e2; border: 1px solid #f87171; color: #b91c1c; padding: 12px 16px; border-radius: var(--radius-md); font-size: 0.9rem; margin-bottom: 20px;">
                <?php foreach ($errors as $err): ?>
                    <div style="display:flex; align-items:center; gap:8px;">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <span><?php echo htmlspecialchars($err); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo BASE_URL; ?>/login.php" method="POST" id="login-form">
            <input type="hidden" name="login_type" id="login-type-input" value="<?php echo htmlspecialchars($loginType); ?>">
            <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($redirect); ?>">

            <div class="form-group">
                <label class="form-label" id="email-label"><?php echo ($loginType === 'admin') ? 'Admin Email' : 'Email Address'; ?></label>
                <input type="email" name="email" id="login-email-input" class="form-control" 
                       placeholder="<?php echo ($loginType === 'admin') ? 'admin@bhojhub.com' : 'demo@bhojhub.com'; ?>" 
                       value="<?php echo htmlspecialchars($_POST['email'] ?? (($loginType === 'admin') ? 'admin@bhojhub.com' : 'demo@bhojhub.com')); ?>" required autofocus>
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" id="login-password-input" class="form-control" placeholder="••••••••" 
                       value="<?php echo ($loginType === 'admin') ? 'admin123' : 'user123'; ?>" required>
            </div>

            <button type="submit" id="login-submit-btn" class="btn btn-primary btn-lg btn-block mt-4">
                <i class="fa-solid fa-right-to-bracket"></i> 
                <span><?php echo ($loginType === 'admin') ? 'Sign In to Admin Dashboard' : 'Sign In as Customer'; ?></span>
            </button>
        </form>

        <div id="demo-credentials-box" style="background: #0f172a; border: 1px dashed var(--border-light); padding: 12px; border-radius: var(--radius-md); margin-top: 20px; font-size: 0.8rem; color: var(--text-muted);">
            <div id="demo-hint-user" style="<?php echo ($loginType === 'user') ? 'display:block;' : 'display:none;'; ?>">
                <strong>Demo Customer:</strong> <code>demo@bhojhub.com</code> / <code>user123</code>
            </div>
            <div id="demo-hint-admin" style="<?php echo ($loginType === 'admin') ? 'display:block;' : 'display:none;'; ?>">
                <strong>Demo Admin:</strong> <code>admin@bhojhub.com</code> / <code>admin123</code>
            </div>
        </div>

        <div class="text-center mt-6" id="signup-link-wrap" style="<?php echo ($loginType === 'user') ? 'display:block;' : 'display:none;'; ?> font-size: 0.9rem; color: var(--text-muted);">
            Don't have an account? <a href="<?php echo BASE_URL; ?>/register.php" style="color: var(--primary); font-weight: 700;">Sign Up here</a>
        </div>
    </div>
</div>

<script>
function setLoginType(type) {
    const input = document.getElementById('login-type-input');
    const userBtn = document.getElementById('tab-btn-user');
    const adminBtn = document.getElementById('tab-btn-admin');
    const brandIcon = document.getElementById('login-brand-icon');
    const title = document.getElementById('login-title');
    const subtitle = document.getElementById('login-subtitle');
    const emailLabel = document.getElementById('email-label');
    const emailInput = document.getElementById('login-email-input');
    const passwordInput = document.getElementById('login-password-input');
    const submitBtn = document.getElementById('login-submit-btn');
    const demoUser = document.getElementById('demo-hint-user');
    const demoAdmin = document.getElementById('demo-hint-admin');
    const signupWrap = document.getElementById('signup-link-wrap');

    input.value = type;

    if (type === 'admin') {
        userBtn.style.background = 'transparent';
        userBtn.style.color = '#94a3b8';
        adminBtn.style.background = '#ea580c';
        adminBtn.style.color = 'white';
        
        brandIcon.textContent = '🛡️';
        title.textContent = 'Admin Portal Login';
        subtitle.textContent = 'Sign in to access Kitchen Dashboard';
        emailLabel.textContent = 'Admin Email';
        emailInput.placeholder = 'admin@bhojhub.com';
        if (emailInput.value === 'demo@bhojhub.com' || !emailInput.value) {
            emailInput.value = 'admin@bhojhub.com';
            passwordInput.value = 'admin123';
        }
        submitBtn.querySelector('span').textContent = 'Sign In to Admin Dashboard';
        demoUser.style.display = 'none';
        demoAdmin.style.display = 'block';
        signupWrap.style.display = 'none';
    } else {
        adminBtn.style.background = 'transparent';
        adminBtn.style.color = '#94a3b8';
        userBtn.style.background = 'var(--primary)';
        userBtn.style.color = 'white';
        
        brandIcon.textContent = '🥟';
        title.textContent = 'Welcome Back';
        subtitle.textContent = 'Login to your BHOJ HUB customer account';
        emailLabel.textContent = 'Email Address';
        emailInput.placeholder = 'demo@bhojhub.com';
        if (emailInput.value === 'admin@bhojhub.com' || !emailInput.value) {
            emailInput.value = 'demo@bhojhub.com';
            passwordInput.value = 'user123';
        }
        submitBtn.querySelector('span').textContent = 'Sign In as Customer';
        demoUser.style.display = 'block';
        demoAdmin.style.display = 'none';
        signupWrap.style.display = 'block';
    }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
