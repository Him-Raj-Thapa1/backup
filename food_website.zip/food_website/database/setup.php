<?php
/**
 * BHOJ HUB - Database Setup & Migration Script
 * Populates fooddb with tables and seed data.
 */

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'fooddb');
define('DB_USER', 'root');
define('DB_PASS', '');

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>BHOJ HUB - Database Setup</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; }
        .card { max-width: 700px; margin: 0 auto; background: #1e293b; border-radius: 12px; padding: 30px; border: 1px solid #334155; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        h1 { color: #f97316; margin-top: 0; display: flex; align-items: center; gap: 10px; }
        .success { background: #064e3b; color: #6ee7b7; padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; border: 1px solid #059669; }
        .error { background: #7f1d1d; color: #fca5a5; padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; border: 1px solid #dc2626; }
        .info { background: #1e3a8a; color: #93c5fd; padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; }
        .btn { display: inline-block; background: #ea580c; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; margin-top: 15px; }
        .btn:hover { background: #c2410c; }
        ul { line-height: 1.8; }
    </style>
</head>
<body>
<div class="card">
    <h1>🥟 BHOJ HUB Database Installer</h1>
    <p>Target Database: <strong><?php echo DB_NAME; ?></strong> (Host: <?php echo DB_HOST; ?>)</p>

    <?php
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);

        $schemaFile = __DIR__ . '/schema.sql';
        $seedFile = __DIR__ . '/seed.sql';

        if (!file_exists($schemaFile) || !file_exists($seedFile)) {
            throw new Exception("SQL schema or seed file missing in database directory.");
        }

        $schemaSql = file_get_contents($schemaFile);
        $pdo->exec($schemaSql);
        echo "<div class='success'>✓ Database tables created successfully in <strong>" . DB_NAME . "</strong>!</div>";

        $seedSql = file_get_contents($seedFile);
        $pdo->exec($seedSql);
        echo "<div class='success'>✓ Seed data inserted successfully (Categories, Foods, Users, Initial Orders, Reviews)!</div>";

        // Query counts to display verification
        $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $catCount = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
        $foodCount = $pdo->query("SELECT COUNT(*) FROM foods")->fetchColumn();
        $orderCount = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

        echo "<div class='info'>";
        echo "<strong>Verification Summary:</strong>";
        echo "<ul>";
        echo "<li>Registered Users: <strong>{$userCount}</strong> (Admin & Customer)</li>";
        echo "<li>Categories: <strong>{$catCount}</strong></li>";
        echo "<li>Food Items: <strong>{$foodCount}</strong></li>";
        echo "<li>Sample Orders: <strong>{$orderCount}</strong></li>";
        echo "</ul>";
        echo "</div>";

        echo "<p><strong>Demo Login Credentials:</strong><br>";
        echo "Admin Portal: <code>admin@bhojhub.com</code> / Password: <code>admin123</code><br>";
        echo "Customer Portal: <code>demo@bhojhub.com</code> / Password: <code>user123</code></p>";

        echo "<a href='../index.php' class='btn'>Launch BHOJ HUB Homepage &rarr;</a> ";
        echo "<a href='../admin/login.php' class='btn' style='background:#3b82f6;'>Go to Admin Login &rarr;</a>";

    } catch (Exception $e) {
        echo "<div class='error'><strong>Setup Failed:</strong> " . htmlspecialchars($e->getMessage()) . "</div>";
    }
    ?>
</div>
</body>
</html>
