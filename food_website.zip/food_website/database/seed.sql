-- =====================================================
-- BHOJ HUB - Seed Data
-- =====================================================

-- Clear existing data if any (in reverse dependency order)
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `reviews`;
TRUNCATE TABLE `order_items`;
TRUNCATE TABLE `orders`;
TRUNCATE TABLE `foods`;
TRUNCATE TABLE `categories`;
TRUNCATE TABLE `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Insert Users (Admin and Demo Customer)
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `address`, `city`, `role`, `status`) VALUES
(1, 'Bhoj Hub Kitchen Admin', 'admin@bhojhub.com', '9801234567', '$2y$10$IKCTRLNhuKg8.jlvqU4KW.Q/5t7DKuLpN0Ni0Nk9NKpLk61Sqh49e', 'New Baneshwor Kitchen Hub', 'Kathmandu', 'admin', 'active'),
(2, 'Aayush Shrestha', 'demo@bhojhub.com', '9841987654', '$2y$10$.LwtqFGBVypBDUinaZVDAeRRmkqJjFyBiaHZtVPjVyjqNZ4zl6nKS', 'Jhamsikhel Road, Ward 3', 'Lalitpur', 'customer', 'active'),
(3, 'Prerana Adhikari', 'prerana@gmail.com', '9860112233', '$2y$10$.LwtqFGBVypBDUinaZVDAeRRmkqJjFyBiaHZtVPjVyjqNZ4zl6nKS', 'Lazimpat, Near Embassy', 'Kathmandu', 'customer', 'active');

-- 2. Insert Categories
INSERT INTO `categories` (`id`, `name`, `nepali_name`, `slug`, `description`, `icon`, `image`, `is_active`, `sort_order`) VALUES
(1, 'Mo:Mo & Dumplings', 'म:म र डम्प्लिङ', 'momo-dumplings', 'Handmade Himalayan dumplings served with rich sesame-tomato achar & spicy jhol.', 'fa-bowl-food', 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80', 1, 1),
(2, 'Nepali Bhoj & Thali', 'नेपाली भोज र थाली', 'nepali-bhoj-thali', 'Authentic traditional Nepali thali sets packed with ghee, lentils, local greens & meats.', 'fa-plate-wheat', 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80', 1, 2),
(3, 'Sekuwa & Tandoori Grills', 'सेकुवा र ग्रिल', 'sekuwa-grills', 'Charcoal flame-grilled skewers infused with traditional spices, mustard oil & herbs.', 'fa-fire-burner', 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80', 1, 3),
(4, 'Khaja & Fast Food', 'खाजा र स्न्याक्स', 'khaja-fast-food', 'Crispy traditional Newari & Nepali afternoon snacks, chatpate, rolls and dry food.', 'fa-burger', 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=600&q=80', 1, 4),
(5, 'Kathmandu Chowmein & Noodles', 'चाउमिन र चाउचाउ', 'chowmein-noodles', 'Wok-tossed street style chowmein, thukpa, and spicy Keema noodles.', 'fa-kitchen-set', 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80', 1, 5),
(6, 'Desserts & Mithai', 'मिठाई र डेजर्ट', 'desserts-mithai', 'Sweet endings with traditional Gulab Jamun, Sikarni, Rasbari and warm Jalebi.', 'fa-cookie-bite', 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=600&q=80', 1, 6),
(7, 'Beverages & Nepali Lassi', 'पेय पदार्थ र लस्सी', 'beverages-lassi', 'Thick creamy King curd lassi, fragrant Himalayan masala chiya and iced coolers.', 'fa-wine-glass', 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=600&q=80', 1, 7);

-- 3. Insert Foods
INSERT INTO `foods` (`id`, `category_id`, `name`, `nepali_name`, `slug`, `description`, `price`, `discount_price`, `image`, `stock`, `is_available`, `is_veg`, `spicy_level`, `prep_time`, `is_featured`) VALUES
-- Mo:Mo Category
(1, 1, 'Classic Steamed Chicken Mo:Mo', 'चिकेन स्टिम म:म', 'classic-steamed-chicken-momo', 'Juicy minced chicken blended with Himalayan herbs and onion, wrapped in thin dough. Served with signature tomato-sesame achar.', 220.00, NULL, 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=800&q=80', 45, 1, 0, 1, '15-20 mins', 1),
(2, 1, 'Kathmandu Special Jhol Mo:Mo', 'झोल म:म (चिकेन)', 'kathmandu-jhol-momo', 'Steamed chicken momos immersed in cold, tangy, spicy sesame, peanut and hog-plum (lapsi) broth.', 260.00, 240.00, 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80', 30, 1, 0, 2, '20 mins', 1),
(3, 1, 'Crispy Fried Buff Mo:Mo', 'बफ फ्राइड म:म', 'crispy-fried-buff-momo', 'Golden pan-fried buff momos with a crunchy exterior and succulent juicy filling. Served with fiery chili dip.', 210.00, NULL, 'https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?auto=format&fit=crop&w=800&q=80', 25, 1, 0, 2, '20 mins', 0),
(4, 1, 'Chilli Chicken C-Mo:Mo', 'चिल्ली चिकेन सी-म:म', 'chilli-chicken-c-momo', 'Fried chicken dumplings tossed with capsicum, onion, green chili and spicy tangy hot garlic glaze.', 280.00, 260.00, 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=800&q=80', 35, 1, 0, 3, '20-25 mins', 1),
(5, 1, 'Paneer & Cheese Steam Mo:Mo', 'पनीर र चिज म:म', 'paneer-cheese-steam-momo', 'Rich cottage cheese and shredded mozzarella seasoned with coriander and spring onions.', 230.00, NULL, 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?auto=format&fit=crop&w=800&q=80', 20, 1, 1, 0, '15-20 mins', 0),

-- Bhoj & Thali Category
(6, 2, 'Thakali Special Chicken Thali Set', 'थकाली चिकेन थाली सेट', 'thakali-chicken-thali-set', 'Authentic Mustang style dinner with local Jhinuwa rice, black lentil dal (Kalo Dal), ghee, chicken gravy, gundruk achar, saag, radhish pickle & crispy papad.', 450.00, 420.00, 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=800&q=80', 25, 1, 0, 1, '25-30 mins', 1),
(7, 2, 'Royal Thakali Mutton Thali Set', 'शाही थकाली खसीको थाली', 'royal-thakali-mutton-thali', 'Slow-cooked Himalayan goat meat curry served with fragrant rice, tempered Jimbu dal, spicy aloo tareko, fermented gundruk and fresh timur tomato relish.', 550.00, NULL, 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=800&q=80', 15, 1, 0, 2, '30 mins', 1),
(8, 2, 'Organic Veg Thakali Bhoj', 'अर्गानिक भेज थकाली भोज', 'organic-veg-thakali-bhoj', 'A hearty vegetarian delight: seasonal curries, fresh spinach (saag), creamy black dal, paneer tareko, curd and house-made fermented achars.', 340.00, NULL, 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=800&q=80', 20, 1, 1, 1, '20-25 mins', 0),

-- Sekuwa & Tandoor Grills
(9, 3, 'Dharane Pork / Chicken Sekuwa', 'धरान स्पेशल चिकेन सेकुवा', 'dharane-chicken-sekuwa', 'Skewered chicken thigh marinated in roasted cumin, timur, garlic paste and cooked over natural sal-wood charcoal. Served with beaten rice (baji) & spicy radish pickle.', 360.00, 330.00, 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=800&q=80', 30, 1, 0, 2, '20-25 mins', 1),
(10, 3, 'Himalayan Mutton Sekuwa Plate', 'हिमालयन खसीको सेकुवा', 'himalayan-mutton-sekuwa', 'Tender goat cubes seasoned with mountain herbs, mustard oil and slow-charred to perfection.', 480.00, NULL, 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80', 18, 1, 0, 2, '25 mins', 0),
(11, 3, 'Paneer Tikka Sekuwa Special', 'पनीर टिक्का सेकुवा', 'paneer-tikka-sekuwa', 'Cottage cheese cubes tossed in spicy tandoori marinade with roasted bell peppers and onions.', 320.00, NULL, 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=800&q=80', 15, 1, 1, 1, '20 mins', 0),

-- Khaja & Fast Food
(12, 4, 'Bhoj Hub Special Newari Khaja Set', 'नेवारी समय् बजी खाजा सेट', 'newari-samay-baji-set', 'Traditional feast with Samay Baji (chiura), Choila (spiced BBQ meat), Kachila, spicy potato bodi tama, black soybeans (Bhatmas), boiled egg, and ginger pickle.', 420.00, 390.00, 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=800&q=80', 22, 1, 0, 2, '20 mins', 1),
(13, 4, 'Kathmandu Spicy Chatpate Box', 'काठमाडौँ स्पाइसी चटपटे', 'kathmandu-spicy-chatpate', 'Crisp puffed rice, crushed noodles, boiled chickpeas, diced potatoes, tomatoes, fresh green chillies and sharp mustard-lime dressing.', 120.00, NULL, 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80', 50, 1, 1, 3, '10 mins', 0),
(14, 4, 'Pani Puri Platter (10 pcs)', 'पानी पुरी कम्बो (१० पिस)', 'pani-puri-platter', 'Crisp semolina hollow puris stuffed with spicy potato-chickpea mash, served with chilled mint-tamarind water and sweet date chutney.', 140.00, NULL, 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=800&q=80', 40, 1, 1, 2, '10 mins', 0),
(15, 4, 'Spicy Chicken Choila with Chiura', 'चिकेन छोइला र चिउरा', 'chicken-choila-chiura', 'Flame-grilled chicken shredded and marinated with roasted mustard oil, fenugreek seeds, garlic and green chili. Served with crispy beaten rice.', 290.00, 270.00, 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=800&q=80', 25, 1, 0, 3, '15 mins', 1),

-- Chowmein & Noodles
(16, 5, 'Kathmandu Street Chicken Chowmein', 'काठमाडौँ चिकेन चाउमिन', 'kathmandu-chicken-chowmein', 'High-heat wok-fried noodles with julienned chicken, shredded cabbage, carrots, bell peppers, soy, dark sauce and mountain spices.', 210.00, NULL, 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=800&q=80', 35, 1, 0, 1, '15 mins', 1),
(17, 5, 'Spicy Keema Noodles (Kathmandu Style)', 'काठमाडौँ किमा चाउचाउ', 'spicy-keema-noodles', 'Flat wheat noodles smothered in a hot, fragrant spicy minced chicken gravy with spring onion and Sichuan pepper (timur).', 250.00, 230.00, 'https://images.unsplash.com/photo-1612927601601-6638404737ce?auto=format&fit=crop&w=800&q=80', 20, 1, 0, 3, '15-20 mins', 1),
(18, 5, 'Veg Hakka Chowmein Bowl', 'भेज हक्का चाउमिन', 'veg-hakka-chowmein', 'Classic wok noodles loaded with crunchy garden veggies, garlic and ginger aromatics.', 170.00, NULL, 'https://images.unsplash.com/photo-1626804475297-41608ea09aeb?auto=format&fit=crop&w=800&q=80', 25, 1, 1, 1, '15 mins', 0),

-- Desserts & Sweets
(19, 6, 'Royal Gulab Jamun (2 Pcs)', 'शाही गुलाब जामुन (२ पिस)', 'royal-gulab-jamun', 'Soft milk dumplings soaked in warm rosewater and green cardamom flavored sugar syrup.', 110.00, NULL, 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=800&q=80', 40, 1, 1, 0, '5 mins', 0),
(20, 6, 'Bhaktapur Juju Dhau & Sikarni Cup', 'जुजु धौ र सिकर्नी', 'bhaktapur-juju-dhau-sikarni', 'Creamy sweet king curd blended with crushed green cardamom, saffron, pistachios and almonds.', 160.00, 150.00, 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=800&q=80', 25, 1, 1, 0, '5 mins', 1),

-- Beverages
(21, 7, 'Sweet Dry-Fruit Creamy Lassi', 'ड्राइ फ्रुट स्वीट लस्सी', 'sweet-dryfruit-lassi', 'Thick churned sweet yogurt topped with malai, roasted almonds, cashew nuts and saffron drizzle.', 140.00, NULL, 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=800&q=80', 35, 1, 1, 0, '5 mins', 1),
(22, 7, 'Himalayan Spiced Masala Chiya', 'हिमालयन मसला चिया', 'himalayan-masala-chiya', 'Rich milk tea brewed with whole cardamom, ginger, cinnamon, clove and fresh organic tea leaves.', 60.00, NULL, 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80', 60, 1, 1, 0, '5 mins', 0),
(23, 7, 'Mint Lemon Lime Cooler', 'पुदिना कागती कुलर', 'mint-lemon-lime-cooler', 'Crushed fresh mint, freshly squeezed Nepali lime, Himalayan rock salt (bire noon) and chilled soda.', 110.00, NULL, 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80', 30, 1, 1, 0, '5 mins', 0);

-- 4. Insert Initial Demonstration Orders
INSERT INTO `orders` (`id`, `order_number`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `delivery_address`, `delivery_city`, `delivery_notes`, `subtotal`, `delivery_fee`, `discount`, `grand_total`, `payment_method`, `payment_status`, `order_status`, `created_at`) VALUES
(1, 'BH-2026-8801', 2, 'Aayush Shrestha', 'demo@bhojhub.com', '9841987654', 'Jhamsikhel Road, Ward 3', 'Lalitpur', 'Please ring the bell and leave at door.', 660.00, 0.00, 20.00, 640.00, 'esewa', 'paid', 'Out for Delivery', NOW() - INTERVAL 45 MINUTE),
(2, 'BH-2026-8802', 3, 'Prerana Adhikari', 'prerana@gmail.com', '9860112233', 'Lazimpat, Near Embassy', 'Kathmandu', 'Extra spicy achar please.', 450.00, 60.00, 0.00, 510.00, 'cod', 'pending', 'Preparing', NOW() - INTERVAL 20 MINUTE),
(3, 'BH-2026-8803', 2, 'Aayush Shrestha', 'demo@bhojhub.com', '9841987654', 'Jhamsikhel Road, Ward 3', 'Lalitpur', 'Delivered yesterday', 880.00, 0.00, 0.00, 880.00, 'khalti', 'paid', 'Delivered', NOW() - INTERVAL 1 DAY);

-- 5. Insert Order Items for demo orders
INSERT INTO `order_items` (`order_id`, `food_id`, `food_name`, `price`, `quantity`, `subtotal`) VALUES
(1, 1, 'Classic Steamed Chicken Mo:Mo', 220.00, 2, 440.00),
(1, 2, 'Kathmandu Special Jhol Mo:Mo', 240.00, 1, 240.00),
(2, 6, 'Thakali Special Chicken Thali Set', 450.00, 1, 450.00),
(3, 9, 'Dharane Chicken Sekuwa', 330.00, 2, 660.00),
(3, 16, 'Kathmandu Street Chicken Chowmein', 210.00, 1, 210.00);

-- 6. Insert Reviews
INSERT INTO `reviews` (`user_id`, `food_id`, `rating`, `comment`, `created_at`) VALUES
(2, 1, 5, 'Hands down the best steamed chicken momo in Kathmandu! Juicy filling and the sesame achar is divine.', NOW() - INTERVAL 2 DAY),
(3, 6, 5, 'Authentic Thakali taste just like in Marpha! The Kalo dal and chicken curry are top notch.', NOW() - INTERVAL 1 DAY),
(2, 9, 5, 'Super flavorful smoky sekuwa with great beaten rice crunch.', NOW() - INTERVAL 12 HOUR);
