<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'positions';
$root_path = '../../';

// Fetch departments for dropdown
$deptStmt = $pdo->query('SELECT id, name FROM departments ORDER BY name ASC');
$departments = $deptStmt ? $deptStmt->fetchAll() : [];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['position_name'] ?? '');
    $deptId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

    if (empty($name)) {
        $error = 'Position title is required.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM positions WHERE LOWER(name) = LOWER(?) AND (department_id = ? OR (department_id IS NULL AND ? IS NULL))');
        $stmt->execute([$name, $deptId, $deptId]);
        if ($stmt->fetch()) {
            $error = 'This position already exists in the selected department.';
        } else {
            $ins = $pdo->prepare('INSERT INTO positions (name, department_id) VALUES (?, ?)');
            $ins->execute([$name, $deptId]);
            header('Location: index.php?success=' . urlencode('Job position "' . $name . '" created successfully.'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Add Position</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 500px;">
        <div class="subpage-head">
          <div>
            <h2>Add job position</h2>
            <p>Define a new designation and associate with a department.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="add.php">
          <label>Position title
            <input type="text" name="position_name" placeholder="e.g. Software Developer" value="<?php echo htmlspecialchars($_POST['position_name'] ?? ''); ?>" required autofocus>
          </label>
          <label>Department
            <select name="department_id">
              <option value="">-- Select Department (Optional) --</option>
              <?php foreach ($departments as $d): ?>
                <option value="<?php echo $d['id']; ?>" <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $d['id']) ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($d['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>
          <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Save position</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
