<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'positions';
$root_path = '../../';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id, name, department_id FROM positions WHERE id = ?');
$stmt->execute([$id]);
$position = $stmt->fetch();

if (!$position) {
    header('Location: index.php?error=' . urlencode('Position not found.'));
    exit;
}

$deptStmt = $pdo->query('SELECT id, name FROM departments ORDER BY name ASC');
$departments = $deptStmt ? $deptStmt->fetchAll() : [];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['position_name'] ?? '');
    $deptId = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;

    if (empty($name)) {
        $error = 'Position title is required.';
    } else {
        $check = $pdo->prepare('SELECT id FROM positions WHERE LOWER(name) = LOWER(?) AND (department_id = ? OR (department_id IS NULL AND ? IS NULL)) AND id != ?');
        $check->execute([$name, $deptId, $deptId, $id]);
        if ($check->fetch()) {
            $error = 'Another position with this title already exists in the selected department.';
        } else {
            $update = $pdo->prepare('UPDATE positions SET name = ?, department_id = ? WHERE id = ?');
            $update->execute([$name, $deptId, $id]);
            header('Location: index.php?success=' . urlencode('Position updated successfully.'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Edit Position</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 500px;">
        <div class="subpage-head">
          <div>
            <h2>Edit job position</h2>
            <p>Update position title and department assignment.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="edit.php?id=<?php echo $id; ?>">
          <label>Position title
            <input type="text" name="position_name" value="<?php echo htmlspecialchars($_POST['position_name'] ?? $position['name']); ?>" required autofocus>
          </label>
          <label>Department
            <select name="department_id">
              <option value="">-- Select Department (Optional) --</option>
              <?php foreach ($departments as $d): ?>
                <option value="<?php echo $d['id']; ?>" <?php echo ((isset($_POST['department_id']) ? $_POST['department_id'] : $position['department_id']) == $d['id']) ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($d['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </label>
          <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Save changes</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
