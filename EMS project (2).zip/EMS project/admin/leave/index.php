<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'leave';
$root_path = '../../';

$statusFilter = $_GET['status'] ?? 'All';
$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle Actions (Approve / Reject / Create)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_status') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $newStatus = $_POST['new_status'] ?? '';

        if ($requestId > 0 && in_array($newStatus, ['Approved', 'Rejected', 'Pending'])) {
            try {
                $stmt = $pdo->prepare('UPDATE leave_requests SET status = ? WHERE id = ?');
                $stmt->execute([$newStatus, $requestId]);
                header('Location: index.php?status=' . urlencode($statusFilter) . '&success=' . urlencode("Leave request marked as $newStatus."));
                exit;
            } catch (PDOException $e) {
                header('Location: index.php?status=' . urlencode($statusFilter) . '&error=' . urlencode("Database error updating leave request."));
                exit;
            }
        }
    }

    if ($action === 'create_leave') {
        $empId     = (int)($_POST['employee_id'] ?? 0);
        $leaveType = trim($_POST['leave_type'] ?? 'Casual Leave');
        $startDate = $_POST['start_date'] ?? '';
        $endDate   = $_POST['end_date'] ?? '';
        $reason    = trim($_POST['reason'] ?? '');
        $status    = $_POST['status'] ?? 'Approved';

        if ($empId > 0 && $startDate && $endDate && $reason) {
            try {
                $stmt = $pdo->prepare('
                    INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ');
                $stmt->execute([$empId, $leaveType, $startDate, $endDate, $reason, $status]);
                header('Location: index.php?success=' . urlencode('Leave record created successfully.'));
                exit;
            } catch (PDOException $e) {
                header('Location: index.php?error=' . urlencode('Failed to create leave record.'));
                exit;
            }
        } else {
            $errorMsg = 'All fields are required to create a leave record.';
        }
    }
}

// Fetch KPIs
$kpiPending  = (int)$pdo->query("SELECT COUNT(*) FROM leave_requests WHERE status = 'Pending'")->fetchColumn();
$kpiApproved = (int)$pdo->query("SELECT COUNT(*) FROM leave_requests WHERE status = 'Approved'")->fetchColumn();
$kpiRejected = (int)$pdo->query("SELECT COUNT(*) FROM leave_requests WHERE status = 'Rejected'")->fetchColumn();

// Fetch leave requests
$sql = "
    SELECT 
        lr.id, 
        lr.employee_id, 
        u.full_name, 
        u.email, 
        d.name AS dept_name, 
        lr.leave_type, 
        lr.start_date, 
        lr.end_date, 
        DATEDIFF(lr.end_date, lr.start_date) + 1 AS num_days, 
        lr.reason, 
        lr.status, 
        lr.created_at 
    FROM leave_requests lr 
    JOIN employees e ON lr.employee_id = e.id 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    WHERE 1=1
";
$params = [];
if ($statusFilter !== 'All') {
    $sql .= " AND lr.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY lr.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll();

// Fetch active employees for New Leave modal
$activeEmpsStmt = $pdo->query("
    SELECT e.id, u.full_name 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    WHERE e.status = 'Active' 
    ORDER BY u.full_name ASC
");
$activeEmployees = $activeEmpsStmt ? $activeEmpsStmt->fetchAll() : [];

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Leave Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Leave management</h2>
            <p>Review, approve, and track employee leave requests.</p>
          </div>
          <button type="button" class="primary" onclick="openNewLeaveModal()">
            <span class="icoPlus"></span>Record leave
          </button>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="kpi-row" style="margin-bottom:20px;">
          <a href="index.php?status=Pending" class="mini-kpi" style="text-decoration:none;">
            <b style="color:var(--warning);"><?php echo $kpiPending; ?></b><span>Pending requests</span>
          </a>
          <a href="index.php?status=Approved" class="mini-kpi" style="text-decoration:none;">
            <b style="color:var(--primary);"><?php echo $kpiApproved; ?></b><span>Approved requests</span>
          </a>
          <a href="index.php?status=Rejected" class="mini-kpi" style="text-decoration:none;">
            <b style="color:var(--danger);"><?php echo $kpiRejected; ?></b><span>Rejected requests</span>
          </a>
        </div>

        <div class="toolbar" style="margin-bottom:18px;">
          <div style="display:flex;gap:8px;">
            <a href="index.php?status=All" class="secondary <?php echo $statusFilter === 'All' ? 'primary' : ''; ?>" style="<?php echo $statusFilter === 'All' ? 'background:var(--primary);color:#fff;' : ''; ?>">All (<?php echo $kpiPending + $kpiApproved + $kpiRejected; ?>)</a>
            <a href="index.php?status=Pending" class="secondary <?php echo $statusFilter === 'Pending' ? 'primary' : ''; ?>" style="<?php echo $statusFilter === 'Pending' ? 'background:var(--warning);color:#fff;' : ''; ?>">Pending (<?php echo $kpiPending; ?>)</a>
            <a href="index.php?status=Approved" class="secondary <?php echo $statusFilter === 'Approved' ? 'primary' : ''; ?>" style="<?php echo $statusFilter === 'Approved' ? 'background:var(--primary);color:#fff;' : ''; ?>">Approved (<?php echo $kpiApproved; ?>)</a>
            <a href="index.php?status=Rejected" class="secondary <?php echo $statusFilter === 'Rejected' ? 'primary' : ''; ?>" style="<?php echo $statusFilter === 'Rejected' ? 'background:var(--danger);color:#fff;' : ''; ?>">Rejected (<?php echo $kpiRejected; ?>)</a>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Leave type</th>
                <th>Duration</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="leaveTable">
              <?php if (!empty($requests)): ?>
                <?php foreach ($requests as $req): 
                  $empName = htmlspecialchars($req['full_name']);
                  $empColor = getAvatarColor($empName);
                  $status = $req['status'];
                  $badgeClass = ($status === 'Approved') ? 'present' : (($status === 'Pending') ? 'warn' : 'leave');
                ?>
                  <tr>
                    <td>
                      <div class="employee">
                        <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                          <?php echo getInitials($empName); ?>
                        </span>
                        <div>
                          <div style="font-weight:600;"><?php echo $empName; ?></div>
                          <div class="emeta"><?php echo htmlspecialchars($req['dept_name'] ?? 'General'); ?></div>
                        </div>
                      </div>
                    </td>
                    <td><b><?php echo htmlspecialchars($req['leave_type']); ?></b></td>
                    <td>
                      <div><?php echo (int)max(1, $req['num_days']); ?> days</div>
                      <div class="emeta"><?php echo date('M d', strtotime($req['start_date'])); ?> – <?php echo date('M d, Y', strtotime($req['end_date'])); ?></div>
                    </td>
                    <td style="max-width:250px;font-size:12.5px;"><?php echo htmlspecialchars($req['reason']); ?></td>
                    <td>
                      <span class="badge <?php echo $badgeClass; ?>">
                        <?php echo htmlspecialchars($status); ?>
                      </span>
                    </td>
                    <td>
                      <div class="row-actions">
                        <?php if ($status === 'Pending'): ?>
                          <form method="POST" action="index.php?status=<?php echo urlencode($statusFilter); ?>" style="display:inline;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                            <input type="hidden" name="new_status" value="Approved">
                            <button type="submit" class="action-btn tint" style="color:var(--primary);background:var(--primary-soft);">Approve</button>
                          </form>
                          <form method="POST" action="index.php?status=<?php echo urlencode($statusFilter); ?>" style="display:inline;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                            <input type="hidden" name="new_status" value="Rejected">
                            <button type="submit" class="action-btn action-danger">Reject</button>
                          </form>
                        <?php else: ?>
                          <span style="font-size:12px;color:var(--muted);"><?php echo date('M d, Y', strtotime($req['created_at'])); ?></span>
                        <?php endif; ?>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6">
                    <div class="empty-state">
                      <div>No leave requests found matching this filter.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Modal for Recording Leave -->
<div class="modal" id="newLeaveModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:480px;background:#fff;padding:24px;border-radius:16px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="font-size:16px;font-weight:700;">Record Employee Leave</h3>
      <button type="button" onclick="closeNewLeaveModal()" style="font-size:20px;cursor:pointer;">×</button>
    </div>
    <form method="POST" action="index.php" class="form">
      <input type="hidden" name="action" value="create_leave">

      <label>Employee *
        <select name="employee_id" required>
          <option value="">-- Select Employee --</option>
          <?php foreach ($activeEmployees as $ae): ?>
            <option value="<?php echo $ae['id']; ?>"><?php echo htmlspecialchars($ae['full_name']); ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>Leave Type *
        <select name="leave_type" required>
          <option value="Casual Leave">Casual Leave</option>
          <option value="Sick Leave">Sick Leave</option>
          <option value="Annual Leave">Annual Leave</option>
          <option value="Unpaid Leave">Unpaid Leave</option>
        </select>
      </label>

      <div class="form-row">
        <label>Start Date *
          <input type="date" name="start_date" value="<?php echo date('Y-m-d'); ?>" required>
        </label>
        <label>End Date *
          <input type="date" name="end_date" value="<?php echo date('Y-m-d'); ?>" required>
        </label>
      </div>

      <label>Reason *
        <textarea name="reason" rows="3" placeholder="Reason for leave" required style="border:1px solid var(--line);background:var(--surface);border-radius:10px;padding:10px;width:100%;font-size:13px;"></textarea>
      </label>

      <label>Approval Status
        <select name="status">
          <option value="Approved">Approved</option>
          <option value="Pending">Pending</option>
        </select>
      </label>

      <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
        <button type="button" class="secondary" onclick="closeNewLeaveModal()">Cancel</button>
        <button type="submit" class="primary">Record Leave</button>
      </div>
    </form>
  </div>
</div>

<script>
function openNewLeaveModal() {
  document.getElementById('newLeaveModal').style.display = 'flex';
}
function closeNewLeaveModal() {
  document.getElementById('newLeaveModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
