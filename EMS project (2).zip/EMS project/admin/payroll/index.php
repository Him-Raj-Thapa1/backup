<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'payroll';
$root_path = '../../';

$selectedMonth = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonth)) {
    $selectedMonth = date('Y-m');
}

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Generate payroll for single employee
    if ($action === 'generate_single') {
        $empId      = (int)($_POST['employee_id'] ?? 0);
        $month      = $_POST['pay_month'] ?? $selectedMonth;
        $basic      = (float)($_POST['basic_salary'] ?? 0);
        $allowances = (float)($_POST['allowances'] ?? 0);
        $deductions = (float)($_POST['deductions'] ?? 0);

        if ($empId > 0 && !empty($month)) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO payroll (employee_id, pay_month, basic_salary, allowances, deductions)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        basic_salary = VALUES(basic_salary),
                        allowances = VALUES(allowances),
                        deductions = VALUES(deductions),
                        generated_at = CURRENT_TIMESTAMP
                ");
                $stmt->execute([$empId, $month, $basic, $allowances, $deductions]);
                header("Location: index.php?month=$month&success=" . urlencode('Payroll generated successfully.'));
                exit;
            } catch (PDOException $e) {
                header("Location: index.php?month=$month&error=" . urlencode('Database error generating payroll.'));
                exit;
            }
        }
    }

    // Batch generate for all active employees
    if ($action === 'generate_all') {
        $month = $_POST['pay_month'] ?? $selectedMonth;
        try {
            $activeEmps = $pdo->query("SELECT id, basic_salary FROM employees WHERE status = 'Active'")->fetchAll();
            $count = 0;
            $stmt = $pdo->prepare("
                INSERT INTO payroll (employee_id, pay_month, basic_salary, allowances, deductions)
                VALUES (?, ?, ?, 0.00, 0.00)
                ON DUPLICATE KEY UPDATE 
                    basic_salary = VALUES(basic_salary),
                    generated_at = CURRENT_TIMESTAMP
            ");
            foreach ($activeEmps as $emp) {
                $stmt->execute([$emp['id'], $month, $emp['basic_salary']]);
                $count++;
            }
            header("Location: index.php?month=$month&success=" . urlencode("Batch generated payroll for $count employee(s)."));
            exit;
        } catch (PDOException $e) {
            header("Location: index.php?month=$month&error=" . urlencode('Failed to batch generate payroll.'));
            exit;
        }
    }
}

// ---------------- KPI QUERIES ----------------
$payrollKpiStmt = $pdo->prepare("SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE pay_month = ?");
$payrollKpiStmt->execute([$selectedMonth]);
$currentPayrollTotal = (float)$payrollKpiStmt->fetchColumn();

$paidCountStmt = $pdo->prepare("SELECT COUNT(DISTINCT employee_id) FROM payroll WHERE pay_month = ?");
$paidCountStmt->execute([$selectedMonth]);
$employeesPaid = (int)$paidCountStmt->fetchColumn();

$totalActiveEmployees = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'")->fetchColumn();
$preparedRate = $totalActiveEmployees > 0 ? round(($employeesPaid / $totalActiveEmployees) * 100) : 0;

// Fetch payroll records
$stmt = $pdo->prepare("
    SELECT 
        pr.id AS payroll_id, 
        pr.pay_month, 
        pr.basic_salary, 
        pr.allowances, 
        pr.deductions, 
        pr.net_salary, 
        pr.generated_at, 
        e.id AS employee_id, 
        u.full_name, 
        u.email, 
        d.name AS dept_name, 
        p.name AS pos_name 
    FROM payroll pr 
    JOIN employees e ON pr.employee_id = e.id 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE pr.pay_month = ? 
    ORDER BY u.full_name ASC
");
$stmt->execute([$selectedMonth]);
$payrollRecords = $stmt->fetchAll();

// Fetch active employees with their salary for modal
$activeEmpsStmt = $pdo->query("
    SELECT e.id, u.full_name, e.basic_salary 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    WHERE e.status = 'Active' 
    ORDER BY u.full_name ASC
");
$activeEmployees = $activeEmpsStmt ? $activeEmpsStmt->fetchAll() : [];

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Payroll Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Payroll management</h2>
            <p>Calculate, disburse, and generate employee payslips.</p>
          </div>
          <div style="display:flex;gap:10px;align-items:center;">
            <form method="GET" action="index.php" style="display:flex;align-items:center;gap:6px;">
              <input type="month" name="month" value="<?php echo htmlspecialchars($selectedMonth); ?>" onchange="this.form.submit()" style="border:1px solid var(--line);background:var(--surface);border-radius:10px;padding:8px 12px;font-size:13px;font-weight:600;">
            </form>
            <button type="button" class="primary" onclick="openGenerateModal()">
              <span class="icoWallet"></span>Generate payroll
            </button>
          </div>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--violet);">Rs. <?php echo number_format($currentPayrollTotal, 2); ?></b>
            <span>Total payroll (<?php echo date('M Y', strtotime($selectedMonth . '-01')); ?>)</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo $employeesPaid; ?> / <?php echo $totalActiveEmployees; ?></b>
            <span>Employees processed</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--info);"><?php echo $preparedRate; ?>%</b>
            <span>Payroll complete</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Basic Salary</th>
                <th>Allowances</th>
                <th>Deductions</th>
                <th>Net Salary</th>
                <th>Payslip</th>
              </tr>
            </thead>
            <tbody id="payrollTable">
              <?php if (!empty($payrollRecords)): ?>
                <?php foreach ($payrollRecords as $pr): 
                  $empName = htmlspecialchars($pr['full_name']);
                  $empColor = getAvatarColor($empName);
                ?>
                  <tr>
                    <td>
                      <div class="employee">
                        <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                          <?php echo getInitials($empName); ?>
                        </span>
                        <div>
                          <div style="font-weight:600;"><?php echo $empName; ?></div>
                          <div class="emeta"><?php echo htmlspecialchars($pr['pos_name'] ?? 'Employee'); ?></div>
                        </div>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars($pr['dept_name'] ?? 'General'); ?></td>
                    <td>Rs. <?php echo number_format($pr['basic_salary'], 2); ?></td>
                    <td style="color:var(--primary);">+Rs. <?php echo number_format($pr['allowances'], 2); ?></td>
                    <td style="color:var(--danger);">-Rs. <?php echo number_format($pr['deductions'], 2); ?></td>
                    <td><b style="color:var(--ink);">Rs. <?php echo number_format($pr['net_salary'], 2); ?></b></td>
                    <td>
                      <button type="button" class="action-btn tint" onclick="viewPayslip(<?php echo htmlspecialchars(json_encode($pr)); ?>)">
                        View payslip
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7">
                    <div class="empty-state">
                      <div>No payroll generated yet for <?php echo date('F Y', strtotime($selectedMonth . '-01')); ?>. Click "Generate payroll" to issue monthly payslips.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Modal for Generating Payroll -->
<div class="modal" id="generatePayrollModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:480px;background:#fff;padding:24px;border-radius:16px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="font-size:16px;font-weight:700;">Generate Payroll</h3>
      <button type="button" onclick="closeGenerateModal()" style="font-size:20px;cursor:pointer;">×</button>
    </div>

    <!-- Batch generation button -->
    <form method="POST" action="index.php" style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--line);">
      <input type="hidden" name="action" value="generate_all">
      <input type="hidden" name="pay_month" value="<?php echo htmlspecialchars($selectedMonth); ?>">
      <button type="submit" class="secondary" style="width:100%;justify-content:center;" onclick="return confirm('Generate payroll for ALL active employees using their default basic salary?');">
        ⚡ Batch Generate for All (<?php echo count($activeEmployees); ?> Active Employees)
      </button>
    </form>

    <div style="font-size:12px;color:var(--muted);margin-bottom:12px;text-align:center;">— OR CUSTOMIZE FOR AN EMPLOYEE —</div>

    <form method="POST" action="index.php" class="form">
      <input type="hidden" name="action" value="generate_single">
      <input type="hidden" name="pay_month" value="<?php echo htmlspecialchars($selectedMonth); ?>">

      <label>Employee *
        <select name="employee_id" id="payrollEmpSelect" onchange="updateDefaultSalary()" required>
          <option value="">-- Select Employee --</option>
          <?php foreach ($activeEmployees as $ae): ?>
            <option value="<?php echo $ae['id']; ?>" data-salary="<?php echo $ae['basic_salary']; ?>">
              <?php echo htmlspecialchars($ae['full_name']); ?> (Default Rs. <?php echo number_format($ae['basic_salary'], 0); ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>Basic Salary (Rs.) *
        <input type="number" step="0.01" name="basic_salary" id="payrollBasicSalary" value="50000" required>
      </label>

      <div class="form-row">
        <label>Allowances (Rs.)
          <input type="number" step="0.01" name="allowances" value="0.00">
        </label>
        <label>Deductions (Rs.)
          <input type="number" step="0.01" name="deductions" value="0.00">
        </label>
      </div>

      <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
        <button type="button" class="secondary" onclick="closeGenerateModal()">Cancel</button>
        <button type="submit" class="primary">Save & Calculate</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal for Viewing Payslip -->
<div class="modal" id="payslipModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:520px;background:#fff;padding:28px;border-radius:18px;">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;border-bottom:2px solid var(--line);padding-bottom:14px;">
      <div>
        <h2 style="font-size:18px;font-weight:800;color:var(--primary-dark);">PeopleFlow EMS</h2>
        <div style="font-size:12px;color:var(--muted);">Official Monthly Payslip</div>
      </div>
      <button type="button" onclick="closePayslipModal()" style="font-size:22px;cursor:pointer;">×</button>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px;font-size:13px;">
      <div><span style="color:var(--muted);">Employee:</span> <b id="psName"></b></div>
      <div><span style="color:var(--muted);">Pay Period:</span> <b id="psPeriod"></b></div>
      <div><span style="color:var(--muted);">Department:</span> <b id="psDept"></b></div>
      <div><span style="color:var(--muted);">Position:</span> <b id="psPos"></b></div>
    </div>

    <div style="background:var(--bg-soft);border-radius:12px;padding:16px;margin-bottom:18px;font-size:13px;">
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);">
        <span>Basic Salary</span>
        <b id="psBasic"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);color:var(--primary);">
        <span>Allowances & Bonuses</span>
        <b id="psAllow"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);color:var(--danger);">
        <span>Deductions & Taxes</span>
        <b id="psDeduct"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:10px 0 4px;font-size:15px;font-weight:800;color:var(--ink);">
        <span>Net Salary Payable</span>
        <b id="psNet" style="color:var(--primary);"></b>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center;">
      <span style="font-size:11px;color:var(--muted);" id="psGenDate"></span>
      <button type="button" class="primary" onclick="window.print()">Print Payslip</button>
    </div>
  </div>
</div>

<script>
function openGenerateModal() {
  document.getElementById('generatePayrollModal').style.display = 'flex';
}
function closeGenerateModal() {
  document.getElementById('generatePayrollModal').style.display = 'none';
}
function updateDefaultSalary() {
  const sel = document.getElementById('payrollEmpSelect');
  const opt = sel.options[sel.selectedIndex];
  if (opt && opt.dataset.salary) {
    document.getElementById('payrollBasicSalary').value = parseFloat(opt.dataset.salary).toFixed(2);
  }
}
function viewPayslip(pr) {
  document.getElementById('psName').textContent = pr.full_name;
  document.getElementById('psPeriod').textContent = pr.pay_month;
  document.getElementById('psDept').textContent = pr.dept_name || 'General';
  document.getElementById('psPos').textContent = pr.pos_name || 'Employee';
  document.getElementById('psBasic').textContent = 'Rs. ' + parseFloat(pr.basic_salary).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psAllow').textContent = '+Rs. ' + parseFloat(pr.allowances).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psDeduct').textContent = '-Rs. ' + parseFloat(pr.deductions).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psNet').textContent = 'Rs. ' + parseFloat(pr.net_salary).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psGenDate').textContent = 'Generated: ' + pr.generated_at;
  document.getElementById('payslipModal').style.display = 'flex';
}
function closePayslipModal() {
  document.getElementById('payslipModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
