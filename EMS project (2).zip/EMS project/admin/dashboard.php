<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'dashboard';
$root_path = '../';

// ---------------- DYNAMIC STAT QUERIES FROM MYSQL ----------------
// 1. Total Active Employees
$totalEmployees = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'")->fetchColumn();

// 2. Present Today
$presentToday = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date = CURDATE() AND status = 'Present'")->fetchColumn();

// 3. On Leave Today
$onLeaveStmt = $pdo->query("
    SELECT COUNT(DISTINCT e.id) 
    FROM employees e 
    WHERE e.status = 'Active' 
      AND (
        EXISTS(SELECT 1 FROM attendance a WHERE a.employee_id = e.id AND a.attendance_date = CURDATE() AND a.status = 'Leave')
        OR EXISTS(SELECT 1 FROM leave_requests l WHERE l.employee_id = e.id AND l.status = 'Approved' AND CURDATE() BETWEEN l.start_date AND l.end_date)
      )
");
$onLeave = (int)$onLeaveStmt->fetchColumn();

// 4. Absent Today
$absentToday = max(0, $totalEmployees - $presentToday - $onLeave);

// 5. Attendance Rate
$attendanceRate = $totalEmployees > 0 ? round(($presentToday / $totalEmployees) * 100) : 0;

// 6. Monthly Payroll for current month
$currentMonth = date('Y-m');
$payrollStmt = $pdo->prepare("SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE pay_month = ?");
$payrollStmt->execute([$currentMonth]);
$monthlyPayrollNum = (float)$payrollStmt->fetchColumn();
$monthlyPayroll = 'Rs. ' . number_format($monthlyPayrollNum, 2);

// 7. Recent Employees from database
$empStmt = $pdo->query("
    SELECT 
        e.id, 
        u.full_name, 
        u.email, 
        d.name AS dept_name, 
        p.name AS pos_name, 
        e.status, 
        e.created_at 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    ORDER BY e.id DESC 
    LIMIT 6
");
$recentEmployees = $empStmt ? $empStmt->fetchAll() : [];

// 8. 7-Day Attendance Trend for Chart
$past7Days = [];
$past7Labels = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $past7Labels[] = $i === 0 ? 'Today' : date('D', strtotime($date));
    $dayPresent = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date = '$date' AND status = 'Present'")->fetchColumn();
    $dayRate = $totalEmployees > 0 ? round(($dayPresent / $totalEmployees) * 100) : 0;
    $past7Days[] = $dayRate;
}

// 9. Recent Activity Feed (Latest leaves, attendance, evaluations)
$recentLeavesStmt = $pdo->query("
    SELECT u.full_name, lr.leave_type, lr.status, lr.created_at 
    FROM leave_requests lr 
    JOIN employees e ON lr.employee_id = e.id 
    JOIN users u ON e.user_id = u.id 
    ORDER BY lr.id DESC 
    LIMIT 5
");
$recentActivities = $recentLeavesStmt ? $recentLeavesStmt->fetchAll() : [];

// Determine time-of-day greeting
$hour = (int)date('G');
if ($hour < 12) {
    $timeGreeting = 'Good morning';
} elseif ($hour < 17) {
    $timeGreeting = 'Good afternoon';
} else {
    $timeGreeting = 'Good evening';
}

$adminName = $_SESSION['full_name'] ?? 'Administrator';

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/admin_header.php'; ?>

    <section class="content" id="dashboardView">
      <div class="hero">
        <div>
          <h1 id="greeting"><?php echo $timeGreeting . ', ' . htmlspecialchars($adminName); ?> 👋</h1>
          <p id="heroSub">
            <?php if ($totalEmployees > 0): ?>
              <?php echo $presentToday; ?> of <?php echo $totalEmployees; ?> employees are present today — <?php echo $onLeave; ?> on leave.
            <?php else: ?>
              Welcome to the Employee Management System. Add your first employee to get started.
            <?php endif; ?>
          </p>
        </div>
        <a href="employees/add.php" class="primary"><span class="icoPlus"></span>Add employee</a>
      </div>

      <!-- Stat Grid -->
      <div class="grid" id="statGrid">
        <a href="employees/index.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Total active employees</span>
            <span class="stat-icon" style="background:var(--primary-soft);color:var(--primary-dark)">
              <svg class="ic" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.5-3.2 2.8-5 5.5-5s5 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.2 14.3c2.3.3 4 1.9 4.4 4.7"/></svg>
            </span>
          </div>
          <h2><?php echo $totalEmployees; ?></h2>
          <span class="trend up">View employee roster</span>
        </a>

        <a href="attendance/index.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Present today</span>
            <span class="stat-icon" style="background:var(--info-soft);color:#2360c4">
              <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
            </span>
          </div>
          <h2><?php echo $presentToday; ?></h2>
          <span class="trend up"><?php echo $attendanceRate; ?>% workforce present</span>
        </a>

        <a href="leave/index.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">On leave today</span>
            <span class="stat-icon" style="background:var(--warning-soft);color:#966212">
              <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
            </span>
          </div>
          <h2><?php echo $onLeave; ?></h2>
          <span class="trend warn">Review leave requests</span>
        </a>

        <a href="payroll/index.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Monthly payroll (<?php echo date('M Y'); ?>)</span>
            <span class="stat-icon" style="background:var(--violet-soft);color:#5c3fd6">
              <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
            </span>
          </div>
          <h2 style="font-size:22px;"><?php echo $monthlyPayroll; ?></h2>
          <span class="trend up">Payroll breakdown</span>
        </a>
      </div>

      <!-- Dashboard Rows: Charts -->
      <div class="dashboard">
        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>Attendance overview</h3>
              <p>Workforce presence over the last 7 days</p>
            </div>
          </div>
          <div class="chart">
            <svg id="areaChart" viewBox="0 0 700 220" preserveAspectRatio="none"></svg>
          </div>
          <div class="legend">
            <span><i class="ld" style="background:var(--primary)"></i>Present %</span>
          </div>
        </div>

        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>Today's attendance</h3>
              <p>Workforce presence breakdown</p>
            </div>
            <a href="attendance/index.php" class="link-btn">Manage →</a>
          </div>
          <div class="ring-wrap">
            <svg width="150" height="150" viewBox="0 0 150 150" id="ringChart"></svg>
            <div class="ring-text" id="ringText">
              <b><?php echo $attendanceRate; ?>%</b>
              <span>Present</span>
            </div>
          </div>
          <div id="attBreakdown">
            <div class="att-row">
              <div>
                <div class="att-name">Present</div>
                <div class="bar"><i style="width:<?php echo $totalEmployees ? ($presentToday / $totalEmployees * 100) : 0; ?>%;background:var(--primary)"></i></div>
              </div>
              <b><?php echo $presentToday; ?></b>
            </div>
            <div class="att-row">
              <div>
                <div class="att-name">On leave</div>
                <div class="bar"><i style="width:<?php echo $totalEmployees ? ($onLeave / $totalEmployees * 100) : 0; ?>%;background:var(--warning)"></i></div>
              </div>
              <b><?php echo $onLeave; ?></b>
            </div>
            <div class="att-row">
              <div>
                <div class="att-name">Absent / Unmarked</div>
                <div class="bar"><i style="width:<?php echo $totalEmployees ? ($absentToday / $totalEmployees * 100) : 0; ?>%;background:var(--danger)"></i></div>
              </div>
              <b><?php echo $absentToday; ?></b>
            </div>
          </div>
        </div>
      </div>

      <!-- Bottom Row: Recent Employees & Quick Actions -->
      <div class="bottom">
        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>Recent employees</h3>
              <p>Latest registered members</p>
            </div>
            <a href="employees/index.php" class="link-btn">View all →</a>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Department</th>
                  <th>Position</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody id="employeeTable">
                <?php if (!empty($recentEmployees)): ?>
                  <?php foreach ($recentEmployees as $emp): 
                    $empName = htmlspecialchars($emp['full_name']);
                    $empColor = getAvatarColor($empName);
                    $isActive = ($emp['status'] === 'Active');
                  ?>
                    <tr>
                      <td>
                        <div class="employee">
                          <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                            <?php echo getInitials($empName); ?>
                          </span>
                          <?php echo $empName; ?>
                        </div>
                      </td>
                      <td><?php echo htmlspecialchars($emp['dept_name'] ?? 'Unassigned'); ?></td>
                      <td><b><?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?></b></td>
                      <td>
                        <span class="badge <?php echo $isActive ? 'present' : 'leave'; ?>">
                          <?php echo $isActive ? 'Active' : 'Inactive'; ?>
                        </span>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="4" class="empty-state">No employees registered yet.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>Quick actions</h3>
              <p>Administrative shortcuts</p>
            </div>
          </div>
          <div class="quick">
            <a href="employees/add.php">
              <span class="qicon" style="background:var(--primary-soft);color:var(--primary-dark)">
                <svg class="ic" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
              </span>
              <strong>Add employee</strong>
              <span>Register new employee</span>
            </a>
            <a href="attendance/index.php">
              <span class="qicon" style="background:var(--info-soft);color:#2360c4">
                <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
              </span>
              <strong>Mark attendance</strong>
              <span>Record daily attendance</span>
            </a>
            <a href="leave/index.php">
              <span class="qicon" style="background:var(--warning-soft);color:#966212">
                <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
              </span>
              <strong>Leave requests</strong>
              <span>Review pending requests</span>
            </a>
            <a href="payroll/index.php">
              <span class="qicon" style="background:var(--violet-soft);color:#5c3fd6">
                <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
              </span>
              <strong>Generate payroll</strong>
              <span>Process monthly salaries</span>
            </a>
          </div>

          <div class="activity">
            <div class="panel-head" style="margin-bottom:8px">
              <div><h3>Recent activity</h3></div>
            </div>
            <div id="activityFeed">
              <?php if (!empty($recentActivities)): ?>
                <?php foreach ($recentActivities as $act): ?>
                  <div style="padding:8px 0;border-bottom:1px solid var(--line);font-size:12px;">
                    <b><?php echo htmlspecialchars($act['full_name']); ?></b> requested 
                    <span class="badge" style="background:var(--bg-soft);color:var(--ink);"><?php echo htmlspecialchars($act['leave_type']); ?></span> leave
                    — <span class="badge <?php echo $act['status'] === 'Approved' ? 'present' : ($act['status'] === 'Pending' ? 'warn' : 'leave'); ?>"><?php echo htmlspecialchars($act['status']); ?></span>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="empty-note">No recent leave requests or logs.</div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

<script>
window.DASHBOARD_COUNTS = {
  total: <?php echo $totalEmployees; ?>,
  present: <?php echo $presentToday; ?>,
  leave: <?php echo $onLeave; ?>,
  absent: <?php echo $absentToday; ?>,
  rate: <?php echo $attendanceRate; ?>
};
window.WEEKLY_DATA = <?php echo json_encode($past7Days); ?>;
window.WEEKLY_LABELS = <?php echo json_encode($past7Labels); ?>;
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
