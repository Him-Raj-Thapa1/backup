<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'attendance';
$root_path = '../../';

$selectedDate = $_GET['date'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) {
    $selectedDate = date('Y-m-d');
}

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'mark_all_present') {
        $postDate = $_POST['date'] ?? $selectedDate;
        try {
            $stmt = $pdo->prepare("
                INSERT INTO attendance (employee_id, attendance_date, check_in, status)
                SELECT e.id, ?, '09:00:00', 'Present' 
                FROM employees e 
                WHERE e.status = 'Active' 
                  AND e.id NOT IN (SELECT a.employee_id FROM attendance a WHERE a.attendance_date = ?)
            ");
            $stmt->execute([$postDate, $postDate]);
            $count = $stmt->rowCount();
            header("Location: index.php?date=$postDate&success=" . urlencode("Marked $count employee(s) present for $postDate."));
            exit;
        } catch (PDOException $e) {
            header("Location: index.php?date=$postDate&error=" . urlencode("Database error marking attendance."));
            exit;
        }
    }

    if ($action === 'save_single') {
        $empId    = (int)($_POST['employee_id'] ?? 0);
        $postDate = $_POST['date'] ?? $selectedDate;
        $status   = $_POST['status'] ?? 'Present';
        $checkIn  = !empty($_POST['check_in']) ? $_POST['check_in'] : null;
        $checkOut = !empty($_POST['check_out']) ? $_POST['check_out'] : null;

        if ($empId > 0) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO attendance (employee_id, attendance_date, check_in, check_out, status)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE 
                        check_in = VALUES(check_in), 
                        check_out = VALUES(check_out), 
                        status = VALUES(status)
                ");
                $stmt->execute([$empId, $postDate, $checkIn, $checkOut, $status]);
                header("Location: index.php?date=$postDate&success=" . urlencode("Attendance record updated."));
                exit;
            } catch (PDOException $e) {
                header("Location: index.php?date=$postDate&error=" . urlencode("Failed to update attendance."));
                exit;
            }
        }
    }
}

// ---------------- FETCH ATTENDANCE DATA FOR SELECTED DATE ----------------
$query = "
    SELECT 
        e.id AS employee_id, 
        u.full_name, 
        u.email, 
        d.name AS dept_name, 
        p.name AS pos_name, 
        a.id AS attendance_id, 
        a.check_in, 
        a.check_out, 
        a.status AS attendance_status,
        (SELECT lr.leave_type FROM leave_requests lr WHERE lr.employee_id = e.id AND lr.status = 'Approved' AND ? BETWEEN lr.start_date AND lr.end_date LIMIT 1) AS approved_leave_type
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    LEFT JOIN attendance a ON a.employee_id = e.id AND a.attendance_date = ?
    WHERE e.status = 'Active' 
    ORDER BY u.full_name ASC
";
$stmt = $pdo->prepare($query);
$stmt->execute([$selectedDate, $selectedDate]);
$rows = $stmt->fetchAll();

// Calculate KPIs
$countPresent = 0;
$countLeave   = 0;
$countAbsent  = 0;

foreach ($rows as $r) {
    $effStatus = $r['attendance_status'];
    if (!$effStatus && !empty($r['approved_leave_type'])) {
        $effStatus = 'Leave';
    }
    if ($effStatus === 'Present') {
        $countPresent++;
    } elseif ($effStatus === 'Leave') {
        $countLeave++;
    } else {
        $countAbsent++;
    }
}

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Attendance Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Attendance management</h2>
            <p>Record, review and manage daily employee attendance.</p>
          </div>
          <div style="display:flex;gap:10px;align-items:center;">
            <form method="GET" action="index.php" style="display:flex;align-items:center;gap:6px;">
              <input type="date" name="date" value="<?php echo htmlspecialchars($selectedDate); ?>" onchange="this.form.submit()" style="border:1px solid var(--line);background:var(--surface);border-radius:10px;padding:8px 12px;font-size:13px;font-weight:600;">
            </form>
            <form method="POST" action="index.php" style="display:inline;">
              <input type="hidden" name="action" value="mark_all_present">
              <input type="hidden" name="date" value="<?php echo htmlspecialchars($selectedDate); ?>">
              <button type="submit" class="primary" onclick="return confirm('Mark all unmarked employees as Present for <?php echo $selectedDate; ?>?');">
                <span class="icoCheck"></span>Mark all present
              </button>
            </form>
          </div>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi"><b id="attPresent" style="color:var(--primary);"><?php echo $countPresent; ?></b><span>Present</span></div>
          <div class="mini-kpi"><b id="attLeave" style="color:var(--warning);"><?php echo $countLeave; ?></b><span>On leave</span></div>
          <div class="mini-kpi"><b id="attAbsent" style="color:var(--danger);"><?php echo $countAbsent; ?></b><span>Absent / Unmarked</span></div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Check in</th>
                <th>Check out</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="attendanceTable">
              <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $row): 
                  $empName = htmlspecialchars($row['full_name']);
                  $empColor = getAvatarColor($empName);
                  $status = $row['attendance_status'];
                  if (!$status && !empty($row['approved_leave_type'])) {
                      $status = 'Leave';
                  }
                  if (!$status) {
                      $status = 'Absent';
                  }
                  $badgeClass = ($status === 'Present') ? 'present' : (($status === 'Leave') ? 'warn' : 'leave');
                  $checkInVal = !empty($row['check_in']) ? date('h:i A', strtotime($row['check_in'])) : '—';
                  $checkOutVal = !empty($row['check_out']) ? date('h:i A', strtotime($row['check_out'])) : '—';
                ?>
                  <tr>
                    <td>
                      <div class="employee">
                        <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                          <?php echo getInitials($empName); ?>
                        </span>
                        <div>
                          <div style="font-weight:600;"><?php echo $empName; ?></div>
                          <div class="emeta"><?php echo htmlspecialchars($row['pos_name'] ?? 'Employee'); ?></div>
                        </div>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars($row['dept_name'] ?? 'General'); ?></td>
                    <td><?php echo $checkInVal; ?></td>
                    <td><?php echo $checkOutVal; ?></td>
                    <td>
                      <span class="badge <?php echo $badgeClass; ?>">
                        <?php echo htmlspecialchars($status); ?>
                      </span>
                    </td>
                    <td>
                      <button type="button" class="action-btn tint" onclick="openAttendanceModal(<?php echo $row['employee_id']; ?>, '<?php echo addslashes($empName); ?>', '<?php echo $row['check_in'] ?? ''; ?>', '<?php echo $row['check_out'] ?? ''; ?>', '<?php echo $status; ?>')">
                        Adjust
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6" class="empty-state">No active employees found in the system.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Modal for adjusting single attendance -->
<div class="modal" id="attModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:440px;background:#fff;padding:24px;border-radius:16px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 id="modalEmpName" style="font-size:16px;font-weight:700;">Update Attendance</h3>
      <button type="button" onclick="closeAttendanceModal()" style="font-size:20px;cursor:pointer;">×</button>
    </div>
    <form method="POST" action="index.php" class="form">
      <input type="hidden" name="action" value="save_single">
      <input type="hidden" name="date" value="<?php echo htmlspecialchars($selectedDate); ?>">
      <input type="hidden" name="employee_id" id="modalEmpId" value="">

      <label>Status
        <select name="status" id="modalStatus" required>
          <option value="Present">Present</option>
          <option value="Absent">Absent</option>
          <option value="Leave">Leave</option>
        </select>
      </label>

      <div class="form-row">
        <label>Check In Time
          <input type="time" name="check_in" id="modalCheckIn">
        </label>
        <label>Check Out Time
          <input type="time" name="check_out" id="modalCheckOut">
        </label>
      </div>

      <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
        <button type="button" class="secondary" onclick="closeAttendanceModal()">Cancel</button>
        <button type="submit" class="primary">Save Record</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAttendanceModal(id, name, checkIn, checkOut, status) {
  document.getElementById('modalEmpId').value = id;
  document.getElementById('modalEmpName').textContent = 'Update Attendance — ' + name;
  document.getElementById('modalStatus').value = (status === 'Present' || status === 'Leave' || status === 'Absent') ? status : 'Present';
  document.getElementById('modalCheckIn').value = checkIn ? checkIn.substring(0, 5) : '09:00';
  document.getElementById('modalCheckOut').value = checkOut ? checkOut.substring(0, 5) : '';
  const m = document.getElementById('attModal');
  m.style.display = 'flex';
}
function closeAttendanceModal() {
  document.getElementById('attModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
