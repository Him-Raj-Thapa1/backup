<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'departments';
$root_path = '../../';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id, name FROM departments WHERE id = ?');
$stmt->execute([$id]);
$department = $stmt->fetch();

if (!$department) {
    header('Location: index.php?error=' . urlencode('Department not found.'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['department_name'] ?? '');

    if (empty($name)) {
        $error = 'Department name is required.';
    } else {
        // Check uniqueness excluding current id
        $check = $pdo->prepare('SELECT id FROM departments WHERE LOWER(name) = LOWER(?) AND id != ?');
        $check->execute([$name, $id]);
        if ($check->fetch()) {
            $error = 'Another department with this name already exists.';
        } else {
            $update = $pdo->prepare('UPDATE departments SET name = ? WHERE id = ?');
            $update->execute([$name, $id]);
            header('Location: index.php?success=' . urlencode('Department updated successfully.'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Edit Department</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 500px;">
        <div class="subpage-head">
          <div>
            <h2>Edit department</h2>
            <p>Update department name in database.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="edit.php?id=<?php echo $id; ?>">
          <label>Department name
            <input type="text" name="department_name" value="<?php echo htmlspecialchars($_POST['department_name'] ?? $department['name']); ?>" required autofocus>
          </label>
          <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Update department</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
