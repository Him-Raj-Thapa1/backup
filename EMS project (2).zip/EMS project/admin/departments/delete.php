<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

try {
    // Check if any employees belong to this department
    $checkEmp = $pdo->prepare('SELECT COUNT(*) FROM employees WHERE department_id = ?');
    $checkEmp->execute([$id]);
    $empCount = (int)$checkEmp->fetchColumn();

    if ($empCount > 0) {
        header('Location: index.php?error=' . urlencode('Cannot delete department because ' . $empCount . ' employee(s) are currently assigned to it.'));
        exit;
    }

    $stmt = $pdo->prepare('DELETE FROM departments WHERE id = ?');
    $stmt->execute([$id]);

    header('Location: index.php?success=' . urlencode('Department deleted successfully.'));
    exit;
} catch (PDOException $e) {
    header('Location: index.php?error=' . urlencode('Database error while deleting department.'));
    exit;
}
