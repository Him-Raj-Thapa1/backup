<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'departments';
$root_path = '../../';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['department_name'] ?? '');

    if (empty($name)) {
        $error = 'Department name is required.';
    } else {
        // Check uniqueness
        $stmt = $pdo->prepare('SELECT id FROM departments WHERE LOWER(name) = LOWER(?)');
        $stmt->execute([$name]);
        if ($stmt->fetch()) {
            $error = 'A department with this name already exists.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO departments (name) VALUES (?)');
            $stmt->execute([$name]);
            header('Location: index.php?success=' . urlencode('Department "' . $name . '" created successfully.'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Add Department</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 500px;">
        <div class="subpage-head">
          <div>
            <h2>Add department</h2>
            <p>Create a new department in the database.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="add.php">
          <label>Department name
            <input type="text" name="department_name" placeholder="e.g. Research & Development" value="<?php echo htmlspecialchars($_POST['department_name'] ?? ''); ?>" required autofocus>
          </label>
          <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Save department</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
