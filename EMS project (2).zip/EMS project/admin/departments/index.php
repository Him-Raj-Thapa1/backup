<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'departments';
$root_path = '../../';

$stmt = $pdo->query("
    SELECT d.id, d.name, d.created_at, COUNT(e.id) AS employee_count 
    FROM departments d 
    LEFT JOIN employees e ON e.department_id = d.id 
    GROUP BY d.id 
    ORDER BY d.name ASC
");
$departments = $stmt ? $stmt->fetchAll() : [];

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Departments</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Departments</h2>
            <p>Manage your company departments and team divisions.</p>
          </div>
          <a href="add.php" class="primary"><span class="icoPlus"></span>Add department</a>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Department Name</th>
                <th>Employees</th>
                <th>Created At</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="departmentTable">
              <?php if (!empty($departments)): ?>
                <?php foreach ($departments as $dept): ?>
                  <tr>
                    <td><b><?php echo htmlspecialchars($dept['name']); ?></b></td>
                    <td>
                      <span class="badge <?php echo $dept['employee_count'] > 0 ? 'present' : 'leave'; ?>">
                        <?php echo (int)$dept['employee_count']; ?> employees
                      </span>
                    </td>
                    <td style="color:var(--muted);font-size:12px;">
                      <?php echo date('M d, Y', strtotime($dept['created_at'])); ?>
                    </td>
                    <td>
                      <div class="row-actions">
                        <a href="edit.php?id=<?php echo $dept['id']; ?>" class="action-btn tint">Edit</a>
                        <a href="delete.php?id=<?php echo $dept['id']; ?>" class="action-btn action-danger" onclick="return confirm('Are you sure you want to delete this department?');">Delete</a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="4" class="empty-state">No departments created yet. Click "Add department" to create one.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
