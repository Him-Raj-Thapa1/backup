<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'reports';
$root_path = '../../';

// Real metrics
$totalEmployees = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE status = 'Active'")->fetchColumn();
$presentToday = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE attendance_date = CURDATE() AND status = 'Present'")->fetchColumn();
$attendanceRate = $totalEmployees > 0 ? round(($presentToday / $totalEmployees) * 100) : 0;

$currentMonth = date('Y-m');
$payrollStmt = $pdo->prepare("SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE pay_month = ?");
$payrollStmt->execute([$currentMonth]);
$monthlyPayroll = (float)$payrollStmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Reports</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Reports & Exports</h2>
            <p>Generate and download official organizational CSV data.</p>
          </div>
        </div>

        <div class="kpi-row" style="margin-bottom:24px;">
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo $totalEmployees; ?></b>
            <span>Total active employees</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--info);"><?php echo $attendanceRate; ?>%</b>
            <span>Today's attendance rate</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--violet);">Rs. <?php echo number_format($monthlyPayroll, 2); ?></b>
            <span>Payroll (<?php echo date('M Y'); ?>)</span>
          </div>
        </div>

        <div class="report-grid">
          <!-- 1. Employee Directory -->
          <div class="report-card">
            <div class="aicon" style="background:var(--primary-soft);color:var(--primary-dark);margin-bottom:12px;">
              <svg class="ic" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.5-3.2 2.8-5 5.5-5s5 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.2 14.3c2.3.3 4 1.9 4.4 4.7"/></svg>
            </div>
            <b>Employee directory</b>
            <p>Full staff roster, departments, positions, salaries, and contact details.</p>
            <a href="export.php?type=employees" class="secondary" style="width:100%;justify-content:center;display:flex;gap:6px;text-decoration:none;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/></svg>
              Export CSV
            </a>
          </div>

          <!-- 2. Attendance Log -->
          <div class="report-card">
            <div class="aicon" style="background:var(--info-soft);color:#2360c4;margin-bottom:12px;">
              <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
            </div>
            <b>Attendance log</b>
            <p>Historical daily check-in, check-out times, and attendance status.</p>
            <a href="export.php?type=attendance" class="secondary" style="width:100%;justify-content:center;display:flex;gap:6px;text-decoration:none;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/></svg>
              Export CSV
            </a>
          </div>

          <!-- 3. Leave Requests -->
          <div class="report-card">
            <div class="aicon" style="background:var(--warning-soft);color:#966212;margin-bottom:12px;">
              <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
            </div>
            <b>Leave requests</b>
            <p>Complete history of employee leave types, durations, reasons, and status.</p>
            <a href="export.php?type=leave" class="secondary" style="width:100%;justify-content:center;display:flex;gap:6px;text-decoration:none;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/></svg>
              Export CSV
            </a>
          </div>

          <!-- 4. Payroll Summary -->
          <div class="report-card">
            <div class="aicon" style="background:var(--violet-soft);color:#5c3fd6;margin-bottom:12px;">
              <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
            </div>
            <b>Payroll summary</b>
            <p>Disbursed salary records, allowances, deductions, and net payouts.</p>
            <a href="export.php?type=payroll" class="secondary" style="width:100%;justify-content:center;display:flex;gap:6px;text-decoration:none;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/></svg>
              Export CSV
            </a>
          </div>

          <!-- 5. Performance Report -->
          <div class="report-card">
            <div class="aicon" style="background:var(--accent-soft);color:var(--accent);margin-bottom:12px;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
            </div>
            <b>Performance evaluations</b>
            <p>Review ratings, strengths, milestones, and appraiser remarks.</p>
            <a href="export.php?type=performance" class="secondary" style="width:100%;justify-content:center;display:flex;gap:6px;text-decoration:none;">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/></svg>
              Export CSV
            </a>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
