<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$type = $_GET['type'] ?? 'employees';
$filename = 'ems_' . $type . '_report_' . date('Y-m-d') . '.csv';

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

$out = fopen('php://output', 'w');

// 1. Employee Directory Export
if ($type === 'employees') {
    fputcsv($out, ['Employee ID', 'Full Name', 'Email', 'Phone', 'Address', 'Department', 'Position', 'Basic Salary (Rs.)', 'Status', 'Date Joined']);

    $stmt = $pdo->query("
        SELECT 
            e.id, 
            u.full_name, 
            u.email, 
            e.phone, 
            e.address, 
            COALESCE(d.name, 'Unassigned') AS dept_name, 
            COALESCE(p.name, 'Unassigned') AS pos_name, 
            e.basic_salary, 
            e.status, 
            e.hire_date 
        FROM employees e 
        JOIN users u ON e.user_id = u.id 
        LEFT JOIN departments d ON e.department_id = d.id 
        LEFT JOIN positions p ON e.position_id = p.id 
        ORDER BY e.id ASC
    ");
    while ($row = $stmt->fetch()) {
        fputcsv($out, [
            $row['id'],
            $row['full_name'],
            $row['email'],
            $row['phone'] ?? '',
            $row['address'] ?? '',
            $row['dept_name'],
            $row['pos_name'],
            number_format($row['basic_salary'], 2, '.', ''),
            $row['status'],
            $row['hire_date'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}

// 2. Attendance Log Export
if ($type === 'attendance') {
    fputcsv($out, ['Attendance ID', 'Employee Name', 'Department', 'Date', 'Check In', 'Check Out', 'Status']);

    $stmt = $pdo->query("
        SELECT 
            a.id, 
            u.full_name, 
            COALESCE(d.name, 'General') AS dept_name, 
            a.attendance_date, 
            a.check_in, 
            a.check_out, 
            a.status 
        FROM attendance a 
        JOIN employees e ON a.employee_id = e.id 
        JOIN users u ON e.user_id = u.id 
        LEFT JOIN departments d ON e.department_id = d.id 
        ORDER BY a.attendance_date DESC, u.full_name ASC
    ");
    while ($row = $stmt->fetch()) {
        fputcsv($out, [
            $row['id'],
            $row['full_name'],
            $row['dept_name'],
            $row['attendance_date'],
            $row['check_in'] ?? '',
            $row['check_out'] ?? '',
            $row['status']
        ]);
    }
    fclose($out);
    exit;
}

// 3. Leave Requests Export
if ($type === 'leave') {
    fputcsv($out, ['Request ID', 'Employee Name', 'Department', 'Leave Type', 'Start Date', 'End Date', 'Days', 'Reason', 'Status', 'Date Applied']);

    $stmt = $pdo->query("
        SELECT 
            lr.id, 
            u.full_name, 
            COALESCE(d.name, 'General') AS dept_name, 
            lr.leave_type, 
            lr.start_date, 
            lr.end_date, 
            DATEDIFF(lr.end_date, lr.start_date) + 1 AS num_days, 
            lr.reason, 
            lr.status, 
            lr.created_at 
        FROM leave_requests lr 
        JOIN employees e ON lr.employee_id = e.id 
        JOIN users u ON e.user_id = u.id 
        LEFT JOIN departments d ON e.department_id = d.id 
        ORDER BY lr.id DESC
    ");
    while ($row = $stmt->fetch()) {
        fputcsv($out, [
            $row['id'],
            $row['full_name'],
            $row['dept_name'],
            $row['leave_type'],
            $row['start_date'],
            $row['end_date'],
            max(1, $row['num_days']),
            $row['reason'],
            $row['status'],
            $row['created_at']
        ]);
    }
    fclose($out);
    exit;
}

// 4. Payroll Export
if ($type === 'payroll') {
    fputcsv($out, ['Payroll ID', 'Employee Name', 'Department', 'Pay Month', 'Basic Salary (Rs.)', 'Allowances (Rs.)', 'Deductions (Rs.)', 'Net Salary (Rs.)', 'Generated Date']);

    $stmt = $pdo->query("
        SELECT 
            pr.id, 
            u.full_name, 
            COALESCE(d.name, 'General') AS dept_name, 
            pr.pay_month, 
            pr.basic_salary, 
            pr.allowances, 
            pr.deductions, 
            pr.net_salary, 
            pr.generated_at 
        FROM payroll pr 
        JOIN employees e ON pr.employee_id = e.id 
        JOIN users u ON e.user_id = u.id 
        LEFT JOIN departments d ON e.department_id = d.id 
        ORDER BY pr.pay_month DESC, u.full_name ASC
    ");
    while ($row = $stmt->fetch()) {
        fputcsv($out, [
            $row['id'],
            $row['full_name'],
            $row['dept_name'],
            $row['pay_month'],
            number_format($row['basic_salary'], 2, '.', ''),
            number_format($row['allowances'], 2, '.', ''),
            number_format($row['deductions'], 2, '.', ''),
            number_format($row['net_salary'], 2, '.', ''),
            $row['generated_at']
        ]);
    }
    fclose($out);
    exit;
}

// 5. Performance Report Export
if ($type === 'performance') {
    fputcsv($out, ['Evaluation ID', 'Employee Name', 'Department', 'Position', 'Review Period', 'Rating (1-5)', 'Strengths', 'Goals', 'Comments', 'Evaluator', 'Date Created']);

    $stmt = $pdo->query("
        SELECT 
            pe.id, 
            u.full_name AS employee_name, 
            COALESCE(d.name, 'General') AS dept_name, 
            COALESCE(p.name, 'Employee') AS pos_name, 
            pe.review_period, 
            pe.rating, 
            pe.strengths, 
            pe.goals, 
            pe.comments, 
            COALESCE(creator.full_name, 'Administrator') AS evaluator_name, 
            pe.created_at 
        FROM performance_evaluations pe 
        JOIN employees e ON pe.employee_id = e.id 
        JOIN users u ON e.user_id = u.id 
        LEFT JOIN departments d ON e.department_id = d.id 
        LEFT JOIN positions p ON e.position_id = p.id 
        LEFT JOIN users creator ON pe.created_by = creator.id 
        ORDER BY pe.id DESC
    ");
    while ($row = $stmt->fetch()) {
        fputcsv($out, [
            $row['id'],
            $row['employee_name'],
            $row['dept_name'],
            $row['pos_name'],
            $row['review_period'],
            $row['rating'],
            $row['strengths'] ?? '',
            $row['goals'] ?? '',
            $row['comments'] ?? '',
            $row['evaluator_name'],
            $row['created_at']
        ]);
    }
    fclose($out);
    exit;
}

// Default fallback
fclose($out);
header('Location: index.php');
exit;
