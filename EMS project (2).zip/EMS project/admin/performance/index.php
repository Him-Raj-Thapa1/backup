<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'performance';
$root_path = '../../';

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

$stmt = $pdo->query("
    SELECT 
        pe.id, 
        pe.review_period, 
        pe.rating, 
        pe.strengths, 
        pe.goals, 
        pe.comments, 
        pe.created_at, 
        e.id AS employee_id, 
        u.full_name AS employee_name, 
        d.name AS dept_name, 
        p.name AS pos_name, 
        creator.full_name AS evaluator_name 
    FROM performance_evaluations pe 
    JOIN employees e ON pe.employee_id = e.id 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    LEFT JOIN users creator ON pe.created_by = creator.id 
    ORDER BY pe.id DESC
");
$evaluations = $stmt ? $stmt->fetchAll() : [];

// Summary KPIs
$totalReviews = count($evaluations);
$avgRating = 0;
if ($totalReviews > 0) {
    $sum = array_sum(array_column($evaluations, 'rating'));
    $avgRating = round($sum / $totalReviews, 1);
}

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Performance Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Performance evaluations</h2>
            <p>Appraise employee performance, document strengths and goals.</p>
          </div>
          <a href="add.php" class="primary"><span class="icoPlus"></span>New evaluation</a>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo $totalReviews; ?></b>
            <span>Total evaluations</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--warning);"><?php echo $avgRating; ?> / 5.0</b>
            <span>Average rating</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Period</th>
                <th>Rating</th>
                <th>Strengths & Goals</th>
                <th>Evaluator</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody id="performanceTable">
              <?php if (!empty($evaluations)): ?>
                <?php foreach ($evaluations as $ev): 
                  $empName = htmlspecialchars($ev['employee_name']);
                  $empColor = getAvatarColor($empName);
                  $stars = str_repeat('★', (int)$ev['rating']) . str_repeat('☆', 5 - (int)$ev['rating']);
                ?>
                  <tr>
                    <td>
                      <div class="employee">
                        <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                          <?php echo getInitials($empName); ?>
                        </span>
                        <div>
                          <div style="font-weight:600;"><?php echo $empName; ?></div>
                          <div class="emeta"><?php echo htmlspecialchars($ev['dept_name'] ?? 'General'); ?> • <?php echo htmlspecialchars($ev['pos_name'] ?? 'Employee'); ?></div>
                        </div>
                      </div>
                    </td>
                    <td><b><?php echo htmlspecialchars($ev['review_period']); ?></b></td>
                    <td>
                      <span style="color:#F0A421;font-size:14px;letter-spacing:1px;"><?php echo $stars; ?></span>
                      <b style="font-size:12px;margin-left:4px;">(<?php echo $ev['rating']; ?>/5)</b>
                    </td>
                    <td style="max-width:280px;font-size:12px;">
                      <?php if (!empty($ev['strengths'])): ?>
                        <div><b>Strengths:</b> <?php echo htmlspecialchars($ev['strengths']); ?></div>
                      <?php endif; ?>
                      <?php if (!empty($ev['goals'])): ?>
                        <div style="color:var(--muted);margin-top:3px;"><b>Goals:</b> <?php echo htmlspecialchars($ev['goals']); ?></div>
                      <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($ev['evaluator_name'] ?? 'Administrator'); ?></td>
                    <td style="color:var(--muted);font-size:12px;">
                      <?php echo date('M d, Y', strtotime($ev['created_at'])); ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6">
                    <div class="empty-state">
                      <div>No performance evaluations recorded yet. Click "New evaluation" to conduct a review.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
