<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'performance';
$root_path = '../../';

// Fetch active employees
$empStmt = $pdo->query("
    SELECT e.id, u.full_name, d.name AS dept_name, p.name AS pos_name 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE e.status = 'Active' 
    ORDER BY u.full_name ASC
");
$employees = $empStmt ? $empStmt->fetchAll() : [];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empId     = (int)($_POST['employee_id'] ?? 0);
    $period    = trim($_POST['review_period'] ?? '');
    $rating    = (int)($_POST['rating'] ?? 5);
    $strengths = trim($_POST['strengths'] ?? '');
    $goals     = trim($_POST['goals'] ?? '');
    $comments  = trim($_POST['comments'] ?? '');
    $adminId   = $_SESSION['user_id'] ?? null;

    if ($empId <= 0 || empty($period) || $rating < 1 || $rating > 5) {
        $error = 'Employee, review period, and a valid rating (1-5) are required.';
    } else {
        try {
            $stmt = $pdo->prepare('
                INSERT INTO performance_evaluations 
                (employee_id, review_period, rating, strengths, goals, comments, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ');
            $stmt->execute([$empId, $period, $rating, $strengths, $goals, $comments, $adminId]);
            header('Location: index.php?success=' . urlencode('Performance evaluation created successfully.'));
            exit;
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — New Performance Review</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 650px;">
        <div class="subpage-head">
          <div>
            <h2>New performance evaluation</h2>
            <p>Conduct an official performance appraisal for an employee.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="add.php">
          <label>Employee *
            <select name="employee_id" required autofocus>
              <option value="">-- Select Employee --</option>
              <?php foreach ($employees as $emp): ?>
                <option value="<?php echo $emp['id']; ?>" <?php echo (isset($_POST['employee_id']) && $_POST['employee_id'] == $emp['id']) ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($emp['full_name']); ?> (<?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?>, <?php echo htmlspecialchars($emp['dept_name'] ?? 'General'); ?>)
                </option>
              <?php endforeach; ?>
            </select>
          </label>

          <div class="form-row">
            <label>Review Period *
              <input type="text" name="review_period" placeholder="e.g. Q3 2026 or Annual Review" value="<?php echo htmlspecialchars($_POST['review_period'] ?? 'Q3 2026'); ?>" required>
            </label>
            <label>Rating (1 to 5 Stars) *
              <select name="rating" required>
                <option value="5" selected>5 ★★★★★ — Exceptional</option>
                <option value="4">4 ★★★★☆ — Exceeds Expectations</option>
                <option value="3">3 ★★★☆☆ — Meets Expectations</option>
                <option value="2">2 ★★☆☆☆ — Needs Improvement</option>
                <option value="1">1 ★☆☆☆☆ — Unsatisfactory</option>
              </select>
            </label>
          </div>

          <label>Key Strengths & Achievements
            <textarea name="strengths" rows="3" placeholder="Areas where the employee excelled..."><?php echo htmlspecialchars($_POST['strengths'] ?? ''); ?></textarea>
          </label>

          <label>Goals & Areas for Growth
            <textarea name="goals" rows="3" placeholder="Targets and developmental milestones for next period..."><?php echo htmlspecialchars($_POST['goals'] ?? ''); ?></textarea>
          </label>

          <label>General Evaluator Comments
            <textarea name="comments" rows="3" placeholder="Overall review notes and feedback..."><?php echo htmlspecialchars($_POST['comments'] ?? ''); ?></textarea>
          </label>

          <div class="form-actions" style="margin-top:20px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Submit Evaluation</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
