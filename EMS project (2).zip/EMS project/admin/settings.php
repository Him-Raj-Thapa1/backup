<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'settings';
$root_path = '../';

$stmt = $pdo->prepare('SELECT full_name, email, password FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

$successMsg = '';
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName        = trim($_POST['full_name'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword     = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($fullName) || empty($email)) {
        $errorMsg = 'Name and email are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMsg = 'Please enter a valid email address.';
    } else {
        // Check uniqueness of email
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
        $check->execute([$email, $_SESSION['user_id']]);
        if ($check->fetch()) {
            $errorMsg = 'This email is already in use by another account.';
        } else {
            try {
                // If changing password
                if (!empty($newPassword)) {
                    if (empty($currentPassword)) {
                        $errorMsg = 'Current password is required to change password.';
                    } elseif (!password_verify($currentPassword, $user['password'])) {
                        $errorMsg = 'Current password is incorrect.';
                    } elseif ($newPassword !== $confirmPassword) {
                        $errorMsg = 'New passwords do not match.';
                    } elseif (strlen($newPassword) < 6) {
                        $errorMsg = 'New password must be at least 6 characters.';
                    } else {
                        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                        $upd = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?');
                        $upd->execute([$fullName, $email, $newHash, $_SESSION['user_id']]);
                        $_SESSION['full_name'] = $fullName;
                        $_SESSION['email'] = $email;
                        $successMsg = 'Profile and password updated successfully.';
                    }
                } else {
                    $upd = $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?');
                    $upd->execute([$fullName, $email, $_SESSION['user_id']]);
                    $_SESSION['full_name'] = $fullName;
                    $_SESSION['email'] = $email;
                    $successMsg = 'Profile updated successfully.';
                }
            } catch (PDOException $e) {
                $errorMsg = 'Database error updating settings.';
            }
        }
    }

    // Refresh user data
    $stmt = $pdo->prepare('SELECT full_name, email, password FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Account Settings</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 540px;">
        <div class="subpage-head">
          <div>
            <h2>Account settings</h2>
            <p>Update administrator information and security credentials.</p>
          </div>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="settings.php" class="form">
          <label>Administrator name *
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required>
          </label>

          <label>Admin email address *
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
          </label>

          <div style="margin: 20px 0 10px; font-weight:700; font-size:14px; border-top: 1px solid var(--line); padding-top:16px;">
            Change Password (Optional)
          </div>

          <label>Current password
            <input type="password" name="current_password" placeholder="Required only if changing password">
          </label>

          <div class="form-row">
            <label>New password
              <input type="password" name="new_password" placeholder="Min 6 characters">
            </label>
            <label>Confirm new password
              <input type="password" name="confirm_password" placeholder="Re-type new password">
            </label>
          </div>

          <div class="form-actions" style="margin-top:20px;">
            <button type="submit" class="primary">Save changes</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
