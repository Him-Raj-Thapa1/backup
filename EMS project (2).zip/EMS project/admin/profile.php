<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'settings';
$root_path = '../';

$stmt = $pdo->prepare('
    SELECT u.id, u.full_name, u.email, u.role, u.created_at, o.name AS organization_name 
    FROM users u 
    LEFT JOIN admins a ON a.user_id = u.id 
    LEFT JOIN organizations o ON o.id = a.organization_id 
    WHERE u.id = ?
    LIMIT 1
');
$stmt->execute([$_SESSION['user_id']]);
$adminData = $stmt->fetch();

$adminName = $adminData ? $adminData['full_name'] : 'Administrator';
$adminEmail = $adminData ? $adminData['email'] : '';
$orgName = $adminData['organization_name'] ?? 'PeopleFlow';
$memberSince = isset($adminData['created_at']) ? date('F Y', strtotime($adminData['created_at'])) : '—';

$initials = 'AD';
if (!empty($adminName)) {
    $words = explode(' ', trim($adminName));
    $initials = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Admin Profile</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 650px;">
        <div class="subpage-head">
          <div>
            <h2>Admin profile</h2>
            <p>Your administrator credentials and system access.</p>
          </div>
          <a href="settings.php" class="secondary">Edit profile</a>
        </div>

        <div class="profile-head" style="margin-bottom: 24px;display:flex;align-items:center;gap:16px;">
          <div class="avatar" style="width: 60px; height: 60px; font-size: 18px; border-radius: 16px;">
            <?php echo htmlspecialchars($initials); ?>
          </div>
          <div>
            <b style="font-size: 18px;display:block;"><?php echo htmlspecialchars($adminName); ?></b>
            <div style="font-size: 13px; color: var(--muted);"><?php echo htmlspecialchars($adminEmail); ?></div>
          </div>
        </div>

        <div class="detail-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
          <div class="card panel" style="padding:16px;">
            <span style="font-size:11px;color:var(--muted);text-transform:uppercase;font-weight:700;">System Role</span>
            <div style="font-size:15px;font-weight:700;margin-top:6px;color:var(--primary);">System Administrator</div>
          </div>
          <div class="card panel" style="padding:16px;">
            <span style="font-size:11px;color:var(--muted);text-transform:uppercase;font-weight:700;">Account Email</span>
            <div style="font-size:14px;font-weight:700;margin-top:6px;"><?php echo htmlspecialchars($adminEmail); ?></div>
          </div>
          <div class="card panel" style="padding:16px;">
            <span style="font-size:11px;color:var(--muted);text-transform:uppercase;font-weight:700;">Organization</span>
            <div style="font-size:14px;font-weight:700;margin-top:6px;"><?php echo htmlspecialchars($orgName); ?></div>
          </div>
          <div class="card panel" style="padding:16px;">
            <span style="font-size:11px;color:var(--muted);text-transform:uppercase;font-weight:700;">Member Since</span>
            <div style="font-size:14px;font-weight:700;margin-top:6px;"><?php echo htmlspecialchars($memberSince); ?></div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
