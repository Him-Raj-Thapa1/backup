<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'employees';
$root_path = '../../';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('
    SELECT e.*, u.full_name, u.email 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    WHERE e.id = ?
');
$stmt->execute([$id]);
$employee = $stmt->fetch();

if (!$employee) {
    header('Location: index.php?error=' . urlencode('Employee not found.'));
    exit;
}

// Fetch departments & positions
$deptStmt = $pdo->query('SELECT id, name FROM departments ORDER BY name ASC');
$departments = $deptStmt ? $deptStmt->fetchAll() : [];

$posStmt = $pdo->query('SELECT id, name, department_id FROM positions ORDER BY name ASC');
$positions = $posStmt ? $posStmt->fetchAll() : [];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName    = trim($_POST['full_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $password    = $_POST['password'] ?? '';
    $phone       = trim($_POST['phone'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $deptId      = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $posId       = !empty($_POST['position_id']) ? (int)$_POST['position_id'] : null;
    $hireDate    = !empty($_POST['hire_date']) ? $_POST['hire_date'] : null;
    $basicSalary = isset($_POST['basic_salary']) ? (float)$_POST['basic_salary'] : 0.00;
    $status      = ($_POST['status'] ?? 'Active') === 'Inactive' ? 'Inactive' : 'Active';

    if (empty($fullName) || empty($email)) {
        $error = 'Full name and email are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Check uniqueness of email for other users
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
        $check->execute([$email, $employee['user_id']]);
        if ($check->fetch()) {
            $error = 'Another account already uses this email address.';
        } else {
            try {
                $pdo->beginTransaction();

                if (!empty($password)) {
                    if (strlen($password) < 6) {
                        throw new Exception('New password must be at least 6 characters.');
                    }
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $updUser = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, password = ? WHERE id = ?');
                    $updUser->execute([$fullName, $email, $hashed, $employee['user_id']]);
                } else {
                    $updUser = $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?');
                    $updUser->execute([$fullName, $email, $employee['user_id']]);
                }

                $updEmp = $pdo->prepare('
                    UPDATE employees 
                    SET department_id = ?, position_id = ?, phone = ?, address = ?, hire_date = ?, basic_salary = ?, status = ? 
                    WHERE id = ?
                ');
                $updEmp->execute([$deptId, $posId, $phone, $address, $hireDate, $basicSalary, $status, $id]);

                $pdo->commit();

                header('Location: index.php?success=' . urlencode('Employee details updated successfully.'));
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Update failed: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Edit Employee</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 700px;">
        <div class="subpage-head">
          <div>
            <h2>Edit employee</h2>
            <p>Update employee information, salary, and status.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="edit.php?id=<?php echo $id; ?>">
          <div class="form-row">
            <label>Full name *
              <input type="text" name="full_name" value="<?php echo htmlspecialchars($_POST['full_name'] ?? $employee['full_name']); ?>" required>
            </label>
            <label>Email address *
              <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? $employee['email']); ?>" required>
            </label>
          </div>

          <div class="form-row">
            <label>Reset Password (optional)
              <input type="password" name="password" placeholder="Leave blank to keep unchanged">
            </label>
            <label>Phone number
              <input type="text" name="phone" value="<?php echo htmlspecialchars($_POST['phone'] ?? $employee['phone']); ?>">
            </label>
          </div>

          <label>Address
            <input type="text" name="address" value="<?php echo htmlspecialchars($_POST['address'] ?? $employee['address']); ?>">
          </label>

          <div class="form-row">
            <label>Department
              <select name="department_id">
                <option value="">-- Select Department --</option>
                <?php foreach ($departments as $d): ?>
                  <option value="<?php echo $d['id']; ?>" <?php echo ((isset($_POST['department_id']) ? $_POST['department_id'] : $employee['department_id']) == $d['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($d['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>

            <label>Job Position
              <select name="position_id">
                <option value="">-- Select Position --</option>
                <?php foreach ($positions as $p): ?>
                  <option value="<?php echo $p['id']; ?>" <?php echo ((isset($_POST['position_id']) ? $_POST['position_id'] : $employee['position_id']) == $p['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($p['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
          </div>

          <div class="form-row">
            <label>Date joined / Hire date
              <input type="date" name="hire_date" value="<?php echo htmlspecialchars($_POST['hire_date'] ?? $employee['hire_date']); ?>">
            </label>
            <label>Basic Salary (Rs.)
              <input type="number" step="0.01" name="basic_salary" value="<?php echo htmlspecialchars($_POST['basic_salary'] ?? $employee['basic_salary']); ?>" required>
            </label>
          </div>

          <label>Status
            <select name="status">
              <option value="Active" <?php echo ((isset($_POST['status']) ? $_POST['status'] : $employee['status']) === 'Active') ? 'selected' : ''; ?>>Active</option>
              <option value="Inactive" <?php echo ((isset($_POST['status']) ? $_POST['status'] : $employee['status']) === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
            </select>
          </label>

          <div class="form-actions" style="margin-top:20px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Save changes</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
