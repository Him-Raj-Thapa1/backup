<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'employees';
$root_path = '../../';

// Fetch departments & positions for dropdowns
$deptStmt = $pdo->query('SELECT id, name FROM departments ORDER BY name ASC');
$departments = $deptStmt ? $deptStmt->fetchAll() : [];

$posStmt = $pdo->query('SELECT id, name, department_id FROM positions ORDER BY name ASC');
$positions = $posStmt ? $posStmt->fetchAll() : [];

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName    = trim($_POST['full_name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $password    = $_POST['password'] ?? '';
    $phone       = trim($_POST['phone'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $deptId      = !empty($_POST['department_id']) ? (int)$_POST['department_id'] : null;
    $posId       = !empty($_POST['position_id']) ? (int)$_POST['position_id'] : null;
    $hireDate    = !empty($_POST['hire_date']) ? $_POST['hire_date'] : date('Y-m-d');
    $basicSalary = isset($_POST['basic_salary']) ? (float)$_POST['basic_salary'] : 0.00;

    if (empty($fullName) || empty($email) || empty($password)) {
        $error = 'Full name, email, and password are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        // Check uniqueness of email
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            try {
                $pdo->beginTransaction();

                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmtUser = $pdo->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, \'employee\')');
                $stmtUser->execute([$fullName, $email, $hashed]);
                $userId = (int)$pdo->lastInsertId();

                $stmtEmp = $pdo->prepare('
                    INSERT INTO employees (user_id, organization_id, department_id, position_id, phone, address, hire_date, basic_salary, status) 
                    VALUES (?, 1, ?, ?, ?, ?, ?, ?, \'Active\')
                ');
                $stmtEmp->execute([$userId, $deptId, $posId, $phone, $address, $hireDate, $basicSalary]);

                $pdo->commit();

                header('Location: index.php?success=' . urlencode('Employee "' . $fullName . '" created successfully.'));
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Failed to create employee due to a database error: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Add Employee</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 700px;">
        <div class="subpage-head">
          <div>
            <h2>Add new employee</h2>
            <p>Create an employee profile and user account in the system.</p>
          </div>
        </div>

        <?php if ($error): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($error); ?>
          </div>
        <?php endif; ?>

        <form class="form" method="POST" action="add.php">
          <div class="form-row">
            <label>Full name *
              <input type="text" name="full_name" placeholder="e.g. Sita Sharma" value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" required autofocus>
            </label>
            <label>Email address *
              <input type="email" name="email" placeholder="e.g. sita@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
            </label>
          </div>

          <div class="form-row">
            <label>Password *
              <input type="password" name="password" placeholder="Account password (min 6 chars)" required>
            </label>
            <label>Phone number
              <input type="text" name="phone" placeholder="e.g. 9841234567" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
            </label>
          </div>

          <label>Address
            <input type="text" name="address" placeholder="e.g. Kathmandu, Nepal" value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>">
          </label>

          <div class="form-row">
            <label>Department
              <select name="department_id" id="deptSelect">
                <option value="">-- Select Department --</option>
                <?php foreach ($departments as $d): ?>
                  <option value="<?php echo $d['id']; ?>" <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $d['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($d['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>

            <label>Job Position
              <select name="position_id" id="posSelect">
                <option value="">-- Select Position --</option>
                <?php foreach ($positions as $p): ?>
                  <option value="<?php echo $p['id']; ?>" data-dept="<?php echo $p['department_id']; ?>" <?php echo (isset($_POST['position_id']) && $_POST['position_id'] == $p['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($p['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
          </div>

          <div class="form-row">
            <label>Date joined / Hire date
              <input type="date" name="hire_date" value="<?php echo htmlspecialchars($_POST['hire_date'] ?? date('Y-m-d')); ?>">
            </label>
            <label>Basic Salary (Rs.)
              <input type="number" step="0.01" name="basic_salary" placeholder="e.g. 50000" value="<?php echo htmlspecialchars($_POST['basic_salary'] ?? '50000'); ?>" required>
            </label>
          </div>

          <div class="form-actions" style="margin-top:20px;display:flex;gap:10px;">
            <a href="index.php" class="secondary">Cancel</a>
            <button type="submit" class="primary">Save employee</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
