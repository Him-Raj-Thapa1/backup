<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$id = (int)($_GET['id'] ?? 0);
$action = $_GET['action'] ?? 'toggle';

if ($id <= 0) {
    header('Location: index.php');
    exit;
}

try {
    if ($action === 'toggle') {
        $stmt = $pdo->prepare("UPDATE employees SET status = IF(status = 'Active', 'Inactive', 'Active') WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: index.php?success=' . urlencode('Employee status toggled successfully.'));
        exit;
    }

    if ($action === 'delete') {
        // Check for historical dependencies
        $check = $pdo->prepare("
            SELECT 
                (SELECT COUNT(*) FROM attendance WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM leave_requests WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM payroll WHERE employee_id = ?) +
                (SELECT COUNT(*) FROM performance_evaluations WHERE employee_id = ?) AS hist_count
        ");
        $check->execute([$id, $id, $id, $id]);
        $histCount = (int)$check->fetchColumn();

        if ($histCount > 0) {
            // Safe deactivation to preserve historical records
            $deact = $pdo->prepare("UPDATE employees SET status = 'Inactive' WHERE id = ?");
            $deact->execute([$id]);
            header('Location: index.php?success=' . urlencode('Employee has historical records (attendance/leave/payroll). Employee has been safely deactivated instead of deleted.'));
            exit;
        }

        // Fetch user_id to delete user account
        $userStmt = $pdo->prepare('SELECT user_id FROM employees WHERE id = ?');
        $userStmt->execute([$id]);
        $userId = (int)$userStmt->fetchColumn();

        if ($userId > 0) {
            $delUser = $pdo->prepare('DELETE FROM users WHERE id = ?');
            $delUser->execute([$userId]);
        } else {
            $delEmp = $pdo->prepare('DELETE FROM employees WHERE id = ?');
            $delEmp->execute([$id]);
        }

        header('Location: index.php?success=' . urlencode('Employee removed successfully.'));
        exit;
    }

    header('Location: index.php');
    exit;
} catch (PDOException $e) {
    header('Location: index.php?error=' . urlencode('Operation failed due to a database error.'));
    exit;
}
