<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../config/database.php';

$active_page = 'employees';
$root_path = '../../';

$search = trim($_GET['search'] ?? '');
$deptFilter = !empty($_GET['department_id']) ? (int)$_GET['department_id'] : 0;

$query = "
    SELECT 
        e.id, 
        e.user_id, 
        u.full_name, 
        u.email, 
        e.phone, 
        e.address, 
        e.hire_date, 
        e.basic_salary, 
        e.status, 
        d.name AS department_name, 
        p.name AS position_name, 
        e.created_at 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $query .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR p.name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($deptFilter > 0) {
    $query .= " AND e.department_id = ?";
    $params[] = $deptFilter;
}

$query .= " ORDER BY e.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$employees = $stmt->fetchAll();

// Fetch departments for filter
$deptStmt = $pdo->query('SELECT id, name FROM departments ORDER BY name ASC');
$departments = $deptStmt ? $deptStmt->fetchAll() : [];

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

if (!function_exists('getInitials')) {
    function getInitials($name) {
        $words = explode(' ', trim($name));
        $in = '';
        foreach (array_slice($words, 0, 2) as $w) {
            $in .= strtoupper(substr($w, 0, 1));
        }
        return $in ?: 'EM';
    }
}

if (!function_exists('getAvatarColor')) {
    function getAvatarColor($name) {
        $tints = [
            ['var(--primary-soft)','var(--primary-dark)'],
            ['var(--info-soft)','#2360c4'],
            ['var(--warning-soft)','#966212'],
            ['var(--accent-soft)','#c8461f'],
            ['var(--violet-soft)','#5c3fd6']
        ];
        $h = 0;
        for ($i = 0; $i < strlen($name); $i++) {
            $h = ($h * 31 + ord($name[$i])) % count($tints);
        }
        return $tints[$h];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PeopleFlow — Employee Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../../includes/admin_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../../includes/admin_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>Employee management</h2>
            <p>Add, update, and manage company employee records.</p>
          </div>
          <a href="add.php" class="primary"><span class="icoPlus"></span>Add employee</a>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <form method="GET" action="index.php" class="toolbar" style="margin-bottom:18px;">
          <input name="search" placeholder="Search by name, email, or position…" value="<?php echo htmlspecialchars($search); ?>">
          <select name="department_id" onchange="this.form.submit()">
            <option value="">All departments</option>
            <?php foreach ($departments as $d): ?>
              <option value="<?php echo $d['id']; ?>" <?php echo $deptFilter == $d['id'] ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($d['name']); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <button type="submit" class="secondary">Filter</button>
          <?php if (!empty($search) || $deptFilter > 0): ?>
            <a href="index.php" class="secondary" style="color:var(--danger);">Clear</a>
          <?php endif; ?>
        </form>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Position</th>
                <th>Salary</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="employeePageTable">
              <?php if (!empty($employees)): ?>
                <?php foreach ($employees as $emp): 
                  $empName = htmlspecialchars($emp['full_name']);
                  $empEmail = htmlspecialchars($emp['email']);
                  $empColor = getAvatarColor($empName);
                  $isActive = ($emp['status'] === 'Active');
                ?>
                  <tr>
                    <td>
                      <div class="employee">
                        <span class="eavatar" style="background:<?php echo $empColor[0]; ?>;color:<?php echo $empColor[1]; ?>">
                          <?php echo getInitials($empName); ?>
                        </span>
                        <div>
                          <div style="font-weight:600;"><?php echo $empName; ?></div>
                          <div class="emeta"><?php echo $empEmail; ?><?php if (!empty($emp['phone'])) echo ' • ' . htmlspecialchars($emp['phone']); ?></div>
                        </div>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars($emp['department_name'] ?? 'Unassigned'); ?></td>
                    <td><b><?php echo htmlspecialchars($emp['position_name'] ?? 'General Employee'); ?></b></td>
                    <td>Rs. <?php echo number_format($emp['basic_salary'], 2); ?></td>
                    <td>
                      <span class="badge <?php echo $isActive ? 'present' : 'leave'; ?>">
                        <?php echo $isActive ? 'Active' : 'Inactive'; ?>
                      </span>
                    </td>
                    <td>
                      <div class="row-actions">
                        <a href="edit.php?id=<?php echo $emp['id']; ?>" class="action-btn tint">Edit</a>
                        <a href="delete.php?action=toggle&id=<?php echo $emp['id']; ?>" class="action-btn <?php echo $isActive ? 'action-danger' : 'tint'; ?>" onclick="return confirm('<?php echo $isActive ? 'Deactivate this employee?' : 'Reactivate this employee?'; ?>');">
                          <?php echo $isActive ? 'Deactivate' : 'Activate'; ?>
                        </a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6">
                    <div class="empty-state">
                      <div>No employees found. Click "Add employee" to create an employee account.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
