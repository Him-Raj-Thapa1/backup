-- =======================================================
-- Migration: Add Positions table and Employee profile fields
-- =======================================================
USE `ems_db`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Ensure positions table exists
CREATE TABLE IF NOT EXISTS `positions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `department_id` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_positions_dept` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. Add missing columns to employees table if not present
SET @dbname = DATABASE();
SET @tablename = 'employees';

-- Add phone
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND COLUMN_NAME = 'phone') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD COLUMN `phone` VARCHAR(25) DEFAULT NULL AFTER `position_id`'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add address
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND COLUMN_NAME = 'address') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD COLUMN `address` VARCHAR(255) DEFAULT NULL AFTER `phone`'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add hire_date
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND COLUMN_NAME = 'hire_date') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD COLUMN `hire_date` DATE DEFAULT NULL AFTER `address`'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add basic_salary
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND COLUMN_NAME = 'basic_salary') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD COLUMN `basic_salary` DECIMAL(12, 2) NOT NULL DEFAULT 0.00 AFTER `hire_date`'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Add status
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND COLUMN_NAME = 'status') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD COLUMN `status` ENUM(\'Active\', \'Inactive\') NOT NULL DEFAULT \'Active\' AFTER `basic_salary`'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 3. Ensure foreign key constraint from employees.position_id to positions.id
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = @dbname AND TABLE_NAME = @tablename AND CONSTRAINT_NAME = 'fk_employees_pos') > 0,
  'SELECT 1',
  'ALTER TABLE employees ADD CONSTRAINT `fk_employees_pos` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 4. Default organization
INSERT IGNORE INTO `organizations` (`id`, `name`) VALUES (1, 'PeopleFlow');

-- 5. Standard seed departments
INSERT IGNORE INTO `departments` (`id`, `name`) VALUES
(1, 'Administration'),
(2, 'Human Resources'),
(3, 'Finance'),
(4, 'IT'),
(5, 'Marketing');

-- 6. Standard seed positions
INSERT IGNORE INTO `positions` (`id`, `name`, `department_id`) VALUES
(1, 'Software Developer', 4),
(2, 'System Administrator', 4),
(3, 'QA Engineer', 4),
(4, 'HR Manager', 2),
(5, 'HR Officer', 2),
(6, 'Accountant', 3),
(7, 'Financial Analyst', 3),
(8, 'Marketing Specialist', 5),
(9, 'Office Administrator', 1);

-- 7. Ensure existing employees have default valid fields
UPDATE `employees`
SET `department_id` = 4, `position_id` = 1, `basic_salary` = 50000.00, `hire_date` = CURDATE(), `status` = 'Active'
WHERE `position_id` IS NULL OR `basic_salary` = 0.00;

SET FOREIGN_KEY_CHECKS = 1;
