<?php
$root_path = $root_path ?? (file_exists('index.php') ? './' : (file_exists('../index.php') ? '../' : '../../'));
?>
<div class="modal" id="modal"><div class="modal-box" id="modalBox"></div></div>
<div class="confirm-backdrop" id="confirmBackdrop"><div class="confirm-box" id="confirmBox"></div></div>
<div class="drawer-backdrop" id="notifBackdrop" data-action="close-notifications">
  <div class="drawer" onclick="event.stopPropagation()">
    <div class="drawer-head">
      <h3>Notifications</h3>
      <div style="display:flex;gap:10px;align-items:center">
        <button type="button" class="link-btn" data-action="clear-notifications">Clear all</button>
        <button type="button" class="close" data-action="close-notifications">×</button>
      </div>
    </div>
    <div id="notifList"></div>
  </div>
</div>
<div class="toast-wrap" id="toastWrap"></div>

<script src="<?php echo $root_path; ?>assets/js/admin.js" defer></script>
</body>
</html>
