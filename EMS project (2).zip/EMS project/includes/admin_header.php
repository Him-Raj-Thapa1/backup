<?php
require_once __DIR__ . '/../config/database.php';

$adminName = $_SESSION['full_name'] ?? 'Administrator';
$adminEmail = $_SESSION['email'] ?? '';
$adminInitials = 'AD';
if (!empty($adminName)) {
    $parts = explode(' ', trim($adminName));
    $adminInitials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}
$root_path = $root_path ?? (file_exists('index.php') ? './' : (file_exists('../index.php') ? '../' : '../../'));
?>
<header class="topbar">
  <button class="menu" data-action="toggle-sidebar" aria-label="Toggle menu"></button>
  <div class="search"><span></span><input id="searchInput" placeholder="Search employees, departments, records…"></div>
  <div class="top-actions">
    <a href="<?php echo $root_path; ?>admin/profile.php" class="user">
      <div class="avatar"><?php echo htmlspecialchars($adminInitials); ?></div>
      <div><b><?php echo htmlspecialchars($adminName); ?></b><small>Administrator</small></div>
    </a>
  </div>
</header>
