<?php
require_once __DIR__ . '/../config/database.php';

$empName = $_SESSION['full_name'] ?? 'Employee';
$empEmail = $_SESSION['email'] ?? '';
$initials = 'EM';
if (!empty($empName)) {
    $parts = explode(' ', trim($empName));
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}
$root_path = $root_path ?? (file_exists('index.php') ? './' : (file_exists('../index.php') ? '../' : '../../'));
?>
<header class="topbar">
  <button class="menu" data-action="toggle-sidebar" aria-label="Toggle menu"></button>
  <div style="font-weight: 700; font-size: 15px; color: var(--ink);">Employee Self-Service Portal</div>
  <div class="top-actions">
    <a href="<?php echo $root_path; ?>employee/profile.php" class="user">
      <div class="avatar" style="background: linear-gradient(135deg, #149A57, #0E7A44);"><?php echo htmlspecialchars($initials); ?></div>
      <div><b><?php echo htmlspecialchars($empName); ?></b><small>Employee</small></div>
    </a>
  </div>
</header>
