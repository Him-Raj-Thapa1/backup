<?php
$root_path = $root_path ?? (file_exists('index.php') ? './' : (file_exists('../index.php') ? '../' : '../../'));
$active_page = $active_page ?? 'dashboard';
?>
<aside class="sidebar" id="sidebar">
  <div class="brand">
    <div class="logo"></div>
    <div>
      <strong>PeopleFlow</strong>
      <span>Employee Management</span>
    </div>
  </div>

  <div class="nav-title">Main Menu</div>
  <nav class="nav">
    <a href="<?php echo $root_path; ?>admin/dashboard.php" class="<?php echo $active_page === 'dashboard' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><path d="M4 10.5 12 4l8 6.5"/><path d="M6 9.5V19a1 1 0 0 0 1 1h3v-5h4v5h3a1 1 0 0 0 1-1V9.5"/></svg>
      </span>
      Dashboard
    </a>
    <a href="<?php echo $root_path; ?>admin/employees/index.php" class="<?php echo $active_page === 'employees' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.5-3.2 2.8-5 5.5-5s5 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.2 14.3c2.3.3 4 1.9 4.4 4.7"/></svg>
      </span>
      Employees
    </a>
    <a href="<?php echo $root_path; ?>admin/attendance/index.php" class="<?php echo $active_page === 'attendance' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
      </span>
      Attendance
    </a>
    <a href="<?php echo $root_path; ?>admin/leave/index.php" class="<?php echo $active_page === 'leave' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
      </span>
      Leave management
    </a>
    <a href="<?php echo $root_path; ?>admin/payroll/index.php" class="<?php echo $active_page === 'payroll' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
      </span>
      Payroll
    </a>
    <a href="<?php echo $root_path; ?>admin/performance/index.php" class="<?php echo $active_page === 'performance' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
      </span>
      Performance
    </a>
    <a href="<?php echo $root_path; ?>admin/reports/index.php" class="<?php echo $active_page === 'reports' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><path d="M5 19V11M12 19V5M19 19v-7"/><path d="M3.5 19.5h17"/></svg>
      </span>
      Reports
    </a>
  </nav>

  <div class="nav-title">Management</div>
  <nav class="nav">
    <a href="<?php echo $root_path; ?>admin/departments/index.php" class="<?php echo $active_page === 'departments' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="5" y="3.5" width="10" height="17" rx="1.5"/><path d="M9 8h2M9 12h2M9 16h2M15 10h4v10.5H15"/></svg>
      </span>
      Departments
    </a>
    <a href="<?php echo $root_path; ?>admin/positions/index.php" class="<?php echo $active_page === 'positions' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="8" width="17" height="11" rx="2"/><path d="M8.5 8V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v2M3.5 13h17"/></svg>
      </span>
      Job positions
    </a>
    <a href="<?php echo $root_path; ?>admin/settings.php" class="<?php echo $active_page === 'settings' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 3.5v2M12 18.5v2M20.5 12h-2M5.5 12h-2M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4M17.7 17.7l-1.4-1.4M7.7 7.7 6.3 6.3"/></svg>
      </span>
      Settings
    </a>
    <a href="<?php echo $root_path; ?>auth/logout.php" style="color: rgba(255, 110, 75, 0.85); margin-top: 4px;">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24" style="stroke: #FF6E4B;"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
      </span>
      Logout
    </a>
  </nav>

  <div class="sidebar-bottom">
    <div class="help">
      <b>PeopleFlow EMS</b>
      <p>Academic Employee Management System.</p>
    </div>
  </div>
</aside>
