<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function get_base_url() {
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    // Detect distance to root
    if (strpos($scriptName, '/admin/employees/') !== false ||
        strpos($scriptName, '/admin/departments/') !== false ||
        strpos($scriptName, '/admin/positions/') !== false ||
        strpos($scriptName, '/admin/attendance/') !== false ||
        strpos($scriptName, '/admin/leave/') !== false ||
        strpos($scriptName, '/admin/payroll/') !== false ||
        strpos($scriptName, '/admin/reports/') !== false ||
        strpos($scriptName, '/admin/performance/') !== false) {
        return '../../';
    } elseif (strpos($scriptName, '/admin/') !== false || strpos($scriptName, '/employee/') !== false || strpos($scriptName, '/auth/') !== false) {
        return '../';
    }
    return './';
}

function require_login() {
    if (!isset($_SESSION['user_id']) || empty($_SESSION['role'])) {
        $base = get_base_url();
        header('Location: ' . $base . 'index.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        $base = get_base_url();
        header('Location: ' . $base . 'employee/dashboard.php');
        exit;
    }
}

function require_employee() {
    require_login();
    if ($_SESSION['role'] !== 'employee') {
        $base = get_base_url();
        header('Location: ' . $base . 'admin/dashboard.php');
        exit;
    }
}

// Auto-enforce role based on URI path
$currentScript = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
if (strpos($currentScript, '/admin/') !== false) {
    require_admin();
} elseif (strpos($currentScript, '/employee/') !== false) {
    require_employee();
}
