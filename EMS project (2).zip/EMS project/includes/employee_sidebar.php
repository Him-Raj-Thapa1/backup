<?php
$root_path = $root_path ?? (file_exists('index.php') ? './' : (file_exists('../index.php') ? '../' : '../../'));
$active_page = $active_page ?? 'dashboard';
?>
<aside class="sidebar" id="sidebar">
  <div class="brand">
    <div class="logo"></div>
    <div>
      <strong>PeopleFlow</strong>
      <span>Employee Portal</span>
    </div>
  </div>

  <div class="nav-title">Self-Service Menu</div>
  <nav class="nav">
    <a href="<?php echo $root_path; ?>employee/dashboard.php" class="<?php echo $active_page === 'dashboard' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><path d="M4 10.5 12 4l8 6.5"/><path d="M6 9.5V19a1 1 0 0 0 1 1h3v-5h4v5h3a1 1 0 0 0 1-1V9.5"/></svg>
      </span>
      Dashboard
    </a>
    <a href="<?php echo $root_path; ?>employee/attendance.php" class="<?php echo $active_page === 'attendance' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
      </span>
      My Attendance
    </a>
    <a href="<?php echo $root_path; ?>employee/leave.php" class="<?php echo $active_page === 'leave' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
      </span>
      My Leave Requests
    </a>
    <a href="<?php echo $root_path; ?>employee/payroll.php" class="<?php echo $active_page === 'payroll' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
      </span>
      My Payslips
    </a>
    <a href="<?php echo $root_path; ?>employee/performance.php" class="<?php echo $active_page === 'performance' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
      </span>
      My Performance
    </a>
    <a href="<?php echo $root_path; ?>employee/profile.php" class="<?php echo $active_page === 'profile' ? 'active' : ''; ?>">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 3.5v2M12 18.5v2M20.5 12h-2M5.5 12h-2M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4M17.7 17.7l-1.4-1.4M7.7 7.7 6.3 6.3"/></svg>
      </span>
      My Profile
    </a>
    <a href="<?php echo $root_path; ?>auth/logout.php" style="color: rgba(255, 110, 75, 0.85); margin-top: 8px;">
      <span class="nav-icon">
        <svg class="ic" viewBox="0 0 24 24" style="stroke: #FF6E4B;"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
      </span>
      Logout
    </a>
  </nav>

  <div class="sidebar-bottom">
    <div class="help">
      <b>EMS Employee</b>
      <p>Self-service portal for attendance, leave, and payroll.</p>
    </div>
  </div>
</aside>
