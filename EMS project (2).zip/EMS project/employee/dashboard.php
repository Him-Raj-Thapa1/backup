<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'dashboard';
$root_path = '../';

// Fetch authenticated employee record
$stmt = $pdo->prepare("
    SELECT 
        e.id AS employee_id, 
        u.full_name, 
        u.email, 
        e.phone, 
        e.address, 
        e.hire_date, 
        e.basic_salary, 
        e.status, 
        d.name AS dept_name, 
        p.name AS pos_name 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE e.user_id = ?
    LIMIT 1
");
$stmt->execute([$_SESSION['user_id']]);
$emp = $stmt->fetch();

if (!$emp) {
    die('Employee profile not found. Please contact administration.');
}

$employeeId = (int)$emp['employee_id'];
$_SESSION['employee_id'] = $employeeId;

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle Clock In / Clock Out
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clockAction = $_POST['clock_action'] ?? '';

    if ($clockAction === 'clock_in') {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO attendance (employee_id, attendance_date, check_in, status)
                VALUES (?, CURDATE(), CURTIME(), 'Present')
                ON DUPLICATE KEY UPDATE 
                    check_in = IF(check_in IS NULL, CURTIME(), check_in), 
                    status = 'Present'
            ");
            $stmt->execute([$employeeId]);
            header('Location: dashboard.php?success=' . urlencode('Clocked in successfully at ' . date('h:i A') . '.'));
            exit;
        } catch (PDOException $e) {
            $errorMsg = 'Failed to record clock in.';
        }
    } elseif ($clockAction === 'clock_out') {
        try {
            $stmt = $pdo->prepare("
                UPDATE attendance 
                SET check_out = CURTIME() 
                WHERE employee_id = ? AND attendance_date = CURDATE()
            ");
            $stmt->execute([$employeeId]);
            header('Location: dashboard.php?success=' . urlencode('Clocked out successfully at ' . date('h:i A') . '.'));
            exit;
        } catch (PDOException $e) {
            $errorMsg = 'Failed to record clock out.';
        }
    }
}

// Today's attendance
$todayAttStmt = $pdo->prepare("SELECT check_in, check_out, status FROM attendance WHERE employee_id = ? AND attendance_date = CURDATE()");
$todayAttStmt->execute([$employeeId]);
$todayAtt = $todayAttStmt->fetch();

// Pending leaves count
$pendStmt = $pdo->prepare("SELECT COUNT(*) FROM leave_requests WHERE employee_id = ? AND status = 'Pending'");
$pendStmt->execute([$employeeId]);
$pendingLeaves = (int)$pendStmt->fetchColumn();

// Latest Payroll
$latestPayStmt = $pdo->prepare("SELECT pay_month, net_salary FROM payroll WHERE employee_id = ? ORDER BY pay_month DESC LIMIT 1");
$latestPayStmt->execute([$employeeId]);
$latestPay = $latestPayStmt->fetch();

// Latest Performance
$latestPerfStmt = $pdo->prepare("SELECT review_period, rating FROM performance_evaluations WHERE employee_id = ? ORDER BY id DESC LIMIT 1");
$latestPerfStmt->execute([$employeeId]);
$latestPerf = $latestPerfStmt->fetch();

// Recent Leaves
$recentLeavesStmt = $pdo->prepare("
    SELECT leave_type, start_date, end_date, reason, status, created_at 
    FROM leave_requests 
    WHERE employee_id = ? 
    ORDER BY id DESC 
    LIMIT 4
");
$recentLeavesStmt->execute([$employeeId]);
$recentLeaves = $recentLeavesStmt->fetchAll();

// Determine greeting
$hour = (int)date('G');
$greeting = ($hour < 12) ? 'Good morning' : (($hour < 17) ? 'Good afternoon' : 'Good evening');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — Employee Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="hero" style="background: linear-gradient(120deg, #0C3B29, #149A57 85%);">
        <div>
          <h1><?php echo $greeting . ', ' . htmlspecialchars($emp['full_name']); ?> 👋</h1>
          <p>
            <b><?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?></b> in 
            <b><?php echo htmlspecialchars($emp['dept_name'] ?? 'General Department'); ?></b>.
            Here is your daily overview.
          </p>
        </div>
        <div style="text-align:right;">
          <a href="leave.php" class="primary" style="background:#fff;color:var(--primary-dark);"><span class="icoPlus"></span>Apply for leave</a>
        </div>
      </div>

      <?php if ($successMsg): ?>
        <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
          <?php echo htmlspecialchars($successMsg); ?>
        </div>
      <?php endif; ?>

      <?php if ($errorMsg): ?>
        <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
          <?php echo htmlspecialchars($errorMsg); ?>
        </div>
      <?php endif; ?>

      <!-- Employee Stat Grid -->
      <div class="grid" style="margin-bottom:20px;">
        <!-- Today's Clock In Card -->
        <div class="card stat" style="cursor:default;">
          <div class="stat-top">
            <span class="stat-label">Today's Attendance</span>
            <span class="stat-icon" style="background:var(--primary-soft);color:var(--primary-dark)">
              <svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/></svg>
            </span>
          </div>
          <h2 style="font-size:20px;">
            <?php 
              if (!empty($todayAtt['check_in'])) {
                  echo htmlspecialchars($todayAtt['status']) . ' (' . date('h:i A', strtotime($todayAtt['check_in'])) . ')';
              } else {
                  echo 'Not Clocked In';
              }
            ?>
          </h2>
          <div style="margin-top:10px;">
            <?php if (empty($todayAtt['check_in'])): ?>
              <form method="POST" action="dashboard.php" style="display:inline;">
                <input type="hidden" name="clock_action" value="clock_in">
                <button type="submit" class="primary" style="padding:6px 14px;font-size:11.5px;">Clock In Now</button>
              </form>
            <?php elseif (empty($todayAtt['check_out'])): ?>
              <form method="POST" action="dashboard.php" style="display:inline;">
                <input type="hidden" name="clock_action" value="clock_out">
                <button type="submit" class="danger-btn" style="padding:6px 14px;font-size:11.5px;">Clock Out</button>
              </form>
            <?php else: ?>
              <span class="trend up">Done for today (Out: <?php echo date('h:i A', strtotime($todayAtt['check_out'])); ?>)</span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Pending Leaves -->
        <a href="leave.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Pending Leaves</span>
            <span class="stat-icon" style="background:var(--warning-soft);color:#966212">
              <svg class="ic" viewBox="0 0 24 24"><rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/></svg>
            </span>
          </div>
          <h2><?php echo $pendingLeaves; ?></h2>
          <span class="trend warn">View requests status</span>
        </a>

        <!-- Latest Payslip -->
        <a href="payroll.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Latest Net Salary</span>
            <span class="stat-icon" style="background:var(--violet-soft);color:#5c3fd6">
              <svg class="ic" viewBox="0 0 24 24"><rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/></svg>
            </span>
          </div>
          <h2 style="font-size:20px;">
            <?php echo $latestPay ? 'Rs. ' . number_format($latestPay['net_salary'], 2) : 'Rs. ' . number_format($emp['basic_salary'], 2); ?>
          </h2>
          <span class="trend up"><?php echo $latestPay ? htmlspecialchars($latestPay['pay_month']) : 'Base Salary'; ?></span>
        </a>

        <!-- Performance -->
        <a href="performance.php" class="card stat">
          <div class="stat-top">
            <span class="stat-label">Performance Rating</span>
            <span class="stat-icon" style="background:var(--accent-soft);color:var(--accent)">
              <svg class="ic" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
            </span>
          </div>
          <h2>
            <?php echo $latestPerf ? $latestPerf['rating'] . ' ★' : '—'; ?>
          </h2>
          <span class="trend up"><?php echo $latestPerf ? htmlspecialchars($latestPerf['review_period']) : 'No reviews yet'; ?></span>
        </a>
      </div>

      <!-- Bottom Panels -->
      <div class="dashboard">
        <!-- Recent Leave Requests -->
        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>My recent leave requests</h3>
              <p>Tracking approval status from administration</p>
            </div>
            <a href="leave.php" class="link-btn">View all →</a>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Leave Type</th>
                  <th>Dates</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!empty($recentLeaves)): ?>
                  <?php foreach ($recentLeaves as $rl): 
                    $bClass = ($rl['status'] === 'Approved') ? 'present' : (($rl['status'] === 'Pending') ? 'warn' : 'leave');
                  ?>
                    <tr>
                      <td><b><?php echo htmlspecialchars($rl['leave_type']); ?></b></td>
                      <td style="font-size:12px;"><?php echo date('M d', strtotime($rl['start_date'])); ?> – <?php echo date('M d, Y', strtotime($rl['end_date'])); ?></td>
                      <td><span class="badge <?php echo $bClass; ?>"><?php echo htmlspecialchars($rl['status']); ?></span></td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="3" class="empty-state">No leave requests submitted yet.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Quick Profile & Employment Details -->
        <div class="card panel">
          <div class="panel-head">
            <div>
              <h3>Employment profile</h3>
              <p>Your official records in the system</p>
            </div>
            <a href="profile.php" class="link-btn">Edit →</a>
          </div>
          <div style="font-size:13px;display:flex;flex-direction:column;gap:12px;">
            <div style="display:flex;justify-content:space-between;padding-bottom:8px;border-bottom:1px solid var(--line);">
              <span style="color:var(--muted);">Department:</span>
              <b><?php echo htmlspecialchars($emp['dept_name'] ?? 'General'); ?></b>
            </div>
            <div style="display:flex;justify-content:space-between;padding-bottom:8px;border-bottom:1px solid var(--line);">
              <span style="color:var(--muted);">Position / Title:</span>
              <b><?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?></b>
            </div>
            <div style="display:flex;justify-content:space-between;padding-bottom:8px;border-bottom:1px solid var(--line);">
              <span style="color:var(--muted);">Email:</span>
              <b><?php echo htmlspecialchars($emp['email']); ?></b>
            </div>
            <div style="display:flex;justify-content:space-between;padding-bottom:8px;border-bottom:1px solid var(--line);">
              <span style="color:var(--muted);">Date Joined:</span>
              <b><?php echo !empty($emp['hire_date']) ? date('M d, Y', strtotime($emp['hire_date'])) : '—'; ?></b>
            </div>
            <div style="display:flex;justify-content:space-between;padding-bottom:4px;">
              <span style="color:var(--muted);">Basic Salary:</span>
              <b style="color:var(--primary);">Rs. <?php echo number_format($emp['basic_salary'], 2); ?></b>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>