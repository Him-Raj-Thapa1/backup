<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'attendance';
$root_path = '../';

$employeeId = $_SESSION['employee_id'] ?? 0;
if ($employeeId <= 0) {
    // Resolve employee_id from session user_id
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employeeId = (int)$stmt->fetchColumn();
    $_SESSION['employee_id'] = $employeeId;
}

$selectedMonth = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $selectedMonth)) {
    $selectedMonth = date('Y-m');
}

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle Clock In / Clock Out
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clockAction = $_POST['clock_action'] ?? '';

    if ($clockAction === 'clock_in') {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO attendance (employee_id, attendance_date, check_in, status)
                VALUES (?, CURDATE(), CURTIME(), 'Present')
                ON DUPLICATE KEY UPDATE 
                    check_in = IF(check_in IS NULL, CURTIME(), check_in), 
                    status = 'Present'
            ");
            $stmt->execute([$employeeId]);
            header('Location: attendance.php?success=' . urlencode('Clocked in successfully at ' . date('h:i A') . '.'));
            exit;
        } catch (PDOException $e) {
            $errorMsg = 'Failed to record clock in.';
        }
    } elseif ($clockAction === 'clock_out') {
        try {
            $stmt = $pdo->prepare("
                UPDATE attendance 
                SET check_out = CURTIME() 
                WHERE employee_id = ? AND attendance_date = CURDATE()
            ");
            $stmt->execute([$employeeId]);
            header('Location: attendance.php?success=' . urlencode('Clocked out successfully at ' . date('h:i A') . '.'));
            exit;
        } catch (PDOException $e) {
            $errorMsg = 'Failed to record clock out.';
        }
    }
}

// Today's attendance
$todayStmt = $pdo->prepare("SELECT check_in, check_out, status FROM attendance WHERE employee_id = ? AND attendance_date = CURDATE()");
$todayStmt->execute([$employeeId]);
$todayAtt = $todayStmt->fetch();

// Attendance history for selected month
$stmt = $pdo->prepare("
    SELECT id, attendance_date, check_in, check_out, status 
    FROM attendance 
    WHERE employee_id = ? AND DATE_FORMAT(attendance_date, '%Y-%m') = ? 
    ORDER BY attendance_date DESC
");
$stmt->execute([$employeeId, $selectedMonth]);
$history = $stmt->fetchAll();

// Month KPIs
$monthPresent = 0;
$monthLeave = 0;
foreach ($history as $h) {
    if ($h['status'] === 'Present') $monthPresent++;
    if ($h['status'] === 'Leave') $monthLeave++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — My Attendance</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>My attendance history</h2>
            <p>Track your daily working hours and presence logs.</p>
          </div>
          <div style="display:flex;gap:10px;align-items:center;">
            <form method="GET" action="attendance.php" style="display:flex;align-items:center;gap:6px;">
              <input type="month" name="month" value="<?php echo htmlspecialchars($selectedMonth); ?>" onchange="this.form.submit()" style="border:1px solid var(--line);background:var(--surface);border-radius:10px;padding:8px 12px;font-size:13px;font-weight:600;">
            </form>
          </div>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <!-- Today's Clock In / Out Box -->
        <div class="card panel" style="margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;background:linear-gradient(135deg,#ECF4EE,#F4F8F5);">
          <div>
            <div style="font-size:12px;color:var(--muted);text-transform:uppercase;font-weight:700;">Today — <?php echo date('l, F j, Y'); ?></div>
            <div style="font-size:17px;font-weight:700;margin-top:4px;">
              <?php if (!empty($todayAtt['check_in'])): ?>
                Clocked In at <b style="color:var(--primary);"><?php echo date('h:i A', strtotime($todayAtt['check_in'])); ?></b>
                <?php if (!empty($todayAtt['check_out'])): ?>
                  • Clocked Out at <b style="color:var(--danger);"><?php echo date('h:i A', strtotime($todayAtt['check_out'])); ?></b>
                <?php endif; ?>
              <?php else: ?>
                You have not clocked in for today yet.
              <?php endif; ?>
            </div>
          </div>
          <div>
            <?php if (empty($todayAtt['check_in'])): ?>
              <form method="POST" action="attendance.php">
                <input type="hidden" name="clock_action" value="clock_in">
                <button type="submit" class="primary"><span class="icoCheck"></span>Clock In Now</button>
              </form>
            <?php elseif (empty($todayAtt['check_out'])): ?>
              <form method="POST" action="attendance.php">
                <input type="hidden" name="clock_action" value="clock_out">
                <button type="submit" class="danger-btn">Clock Out</button>
              </form>
            <?php else: ?>
              <span class="badge present" style="padding:8px 14px;font-size:13px;">Attendance Complete</span>
            <?php endif; ?>
          </div>
        </div>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo $monthPresent; ?> days</b>
            <span>Present in <?php echo date('F Y', strtotime($selectedMonth . '-01')); ?></span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--warning);"><?php echo $monthLeave; ?> days</b>
            <span>On approved leave</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Working Hours</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($history)): ?>
                <?php foreach ($history as $h): 
                  $bClass = ($h['status'] === 'Present') ? 'present' : (($h['status'] === 'Leave') ? 'warn' : 'leave');
                  $duration = '—';
                  if (!empty($h['check_in']) && !empty($h['check_out'])) {
                      $t1 = strtotime($h['check_in']);
                      $t2 = strtotime($h['check_out']);
                      $diff = round(abs($t2 - $t1) / 3600, 1);
                      $duration = $diff . ' hrs';
                  }
                ?>
                  <tr>
                    <td><b><?php echo date('M d, Y (D)', strtotime($h['attendance_date'])); ?></b></td>
                    <td><?php echo !empty($h['check_in']) ? date('h:i A', strtotime($h['check_in'])) : '—'; ?></td>
                    <td><?php echo !empty($h['check_out']) ? date('h:i A', strtotime($h['check_out'])) : '—'; ?></td>
                    <td><?php echo $duration; ?></td>
                    <td><span class="badge <?php echo $bClass; ?>"><?php echo htmlspecialchars($h['status']); ?></span></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" class="empty-state">No attendance records logged for <?php echo date('F Y', strtotime($selectedMonth . '-01')); ?>.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
