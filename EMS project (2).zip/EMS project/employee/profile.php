<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'profile';
$root_path = '../';

$userId = $_SESSION['user_id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT 
        e.id AS employee_id, 
        u.id AS user_id, 
        u.full_name, 
        u.email, 
        u.password, 
        e.phone, 
        e.address, 
        e.hire_date, 
        e.basic_salary, 
        e.status, 
        d.name AS dept_name, 
        p.name AS pos_name 
    FROM employees e 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE u.id = ? 
    LIMIT 1
");
$stmt->execute([$userId]);
$emp = $stmt->fetch();

if (!$emp) {
    die('Employee profile not found.');
}

$successMsg = '';
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone           = trim($_POST['phone'] ?? '');
    $address         = trim($_POST['address'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword     = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    try {
        // If password update requested
        if (!empty($newPassword)) {
            if (empty($currentPassword)) {
                $errorMsg = 'Current password is required to change password.';
            } elseif (!password_verify($currentPassword, $emp['password'])) {
                $errorMsg = 'Current password is incorrect.';
            } elseif ($newPassword !== $confirmPassword) {
                $errorMsg = 'New passwords do not match.';
            } elseif (strlen($newPassword) < 6) {
                $errorMsg = 'New password must be at least 6 characters.';
            } else {
                $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                $updUser = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                $updUser->execute([$newHash, $userId]);

                $updEmp = $pdo->prepare('UPDATE employees SET phone = ?, address = ? WHERE id = ?');
                $updEmp->execute([$phone, $address, $emp['employee_id']]);

                $successMsg = 'Profile and password updated successfully.';
            }
        } else {
            $updEmp = $pdo->prepare('UPDATE employees SET phone = ?, address = ? WHERE id = ?');
            $updEmp->execute([$phone, $address, $emp['employee_id']]);
            $successMsg = 'Contact information updated successfully.';
        }
    } catch (PDOException $e) {
        $errorMsg = 'Failed to update profile: ' . $e->getMessage();
    }

    // Refresh
    $stmt->execute([$userId]);
    $emp = $stmt->fetch();
}

$initials = 'EM';
if (!empty($emp['full_name'])) {
    $parts = explode(' ', trim($emp['full_name']));
    $initials = strtoupper(substr($parts[0], 0, 1) . (isset($parts[1]) ? substr($parts[1], 0, 1) : ''));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — My Profile</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="subpage" style="max-width: 650px;">
        <div class="subpage-head">
          <div>
            <h2>My profile</h2>
            <p>Your personal information, job profile, and security settings.</p>
          </div>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="profile-head" style="margin-bottom: 24px;display:flex;align-items:center;gap:16px;">
          <div class="avatar" style="width: 60px; height: 60px; font-size: 18px; border-radius: 16px; background: linear-gradient(135deg, #149A57, #0E7A44);">
            <?php echo htmlspecialchars($initials); ?>
          </div>
          <div>
            <b style="font-size: 18px;display:block;"><?php echo htmlspecialchars($emp['full_name']); ?></b>
            <div style="font-size: 13px; color: var(--muted);"><?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?> • <?php echo htmlspecialchars($emp['dept_name'] ?? 'General'); ?></div>
          </div>
        </div>

        <!-- Official Details Read-Only -->
        <div class="card panel" style="margin-bottom: 24px; padding: 18px;">
          <h3 style="font-size:14px;font-weight:700;margin-bottom:12px;">Official Job Details</h3>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
            <div>
              <span style="color:var(--muted);font-size:11px;text-transform:uppercase;font-weight:700;display:block;">Department</span>
              <b><?php echo htmlspecialchars($emp['dept_name'] ?? 'Unassigned'); ?></b>
            </div>
            <div>
              <span style="color:var(--muted);font-size:11px;text-transform:uppercase;font-weight:700;display:block;">Designation</span>
              <b><?php echo htmlspecialchars($emp['pos_name'] ?? 'Employee'); ?></b>
            </div>
            <div>
              <span style="color:var(--muted);font-size:11px;text-transform:uppercase;font-weight:700;display:block;">Email Address</span>
              <b><?php echo htmlspecialchars($emp['email']); ?></b>
            </div>
            <div>
              <span style="color:var(--muted);font-size:11px;text-transform:uppercase;font-weight:700;display:block;">Date Joined</span>
              <b><?php echo !empty($emp['hire_date']) ? date('M d, Y', strtotime($emp['hire_date'])) : '—'; ?></b>
            </div>
          </div>
        </div>

        <!-- Update Contact and Password Form -->
        <form method="POST" action="profile.php" class="form">
          <h3 style="font-size:14px;font-weight:700;margin-bottom:12px;">Contact Information</h3>
          
          <div class="form-row">
            <label>Phone Number
              <input type="text" name="phone" value="<?php echo htmlspecialchars($emp['phone'] ?? ''); ?>" placeholder="e.g. 9841234567">
            </label>
            <label>Address
              <input type="text" name="address" value="<?php echo htmlspecialchars($emp['address'] ?? ''); ?>" placeholder="e.g. Kathmandu, Nepal">
            </label>
          </div>

          <div style="margin: 20px 0 10px; font-weight:700; font-size:14px; border-top: 1px solid var(--line); padding-top:16px;">
            Change Password (Optional)
          </div>

          <label>Current password
            <input type="password" name="current_password" placeholder="Required only if changing password">
          </label>

          <div class="form-row">
            <label>New password
              <input type="password" name="new_password" placeholder="Min 6 characters">
            </label>
            <label>Confirm new password
              <input type="password" name="confirm_password" placeholder="Re-type new password">
            </label>
          </div>

          <div class="form-actions" style="margin-top:20px;">
            <button type="submit" class="primary">Update Profile</button>
          </div>
        </form>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
