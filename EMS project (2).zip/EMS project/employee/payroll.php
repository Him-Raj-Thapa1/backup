<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'payroll';
$root_path = '../';

// Strict IDOR protection: only use authenticated employee's session ID
$employeeId = $_SESSION['employee_id'] ?? 0;
if ($employeeId <= 0) {
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employeeId = (int)$stmt->fetchColumn();
    $_SESSION['employee_id'] = $employeeId;
}

$stmt = $pdo->prepare("
    SELECT 
        pr.id, 
        pr.pay_month, 
        pr.basic_salary, 
        pr.allowances, 
        pr.deductions, 
        pr.net_salary, 
        pr.generated_at, 
        u.full_name, 
        d.name AS dept_name, 
        p.name AS pos_name 
    FROM payroll pr 
    JOIN employees e ON pr.employee_id = e.id 
    JOIN users u ON e.user_id = u.id 
    LEFT JOIN departments d ON e.department_id = d.id 
    LEFT JOIN positions p ON e.position_id = p.id 
    WHERE pr.employee_id = ? 
    ORDER BY pr.pay_month DESC
");
$stmt->execute([$employeeId]);
$payslips = $stmt->fetchAll();

// Calculate total earnings
$totalEarned = 0;
foreach ($payslips as $ps) {
    $totalEarned += (float)$ps['net_salary'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — My Payslips</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>My payroll & payslips</h2>
            <p>View your monthly salary disbursements and printable payslips.</p>
          </div>
        </div>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo count($payslips); ?></b>
            <span>Total payslips issued</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--violet);">Rs. <?php echo number_format($totalEarned, 2); ?></b>
            <span>Cumulative net earnings</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Pay Period</th>
                <th>Basic Salary</th>
                <th>Allowances</th>
                <th>Deductions</th>
                <th>Net Salary</th>
                <th>Issued On</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($payslips)): ?>
                <?php foreach ($payslips as $ps): ?>
                  <tr>
                    <td><b><?php echo date('F Y', strtotime($ps['pay_month'] . '-01')); ?></b></td>
                    <td>Rs. <?php echo number_format($ps['basic_salary'], 2); ?></td>
                    <td style="color:var(--primary);">+Rs. <?php echo number_format($ps['allowances'], 2); ?></td>
                    <td style="color:var(--danger);">-Rs. <?php echo number_format($ps['deductions'], 2); ?></td>
                    <td><b style="color:var(--ink);">Rs. <?php echo number_format($ps['net_salary'], 2); ?></b></td>
                    <td style="color:var(--muted);font-size:12px;"><?php echo date('M d, Y', strtotime($ps['generated_at'])); ?></td>
                    <td>
                      <button type="button" class="action-btn tint" onclick="viewPayslip(<?php echo htmlspecialchars(json_encode($ps)); ?>)">
                        View payslip
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7">
                    <div class="empty-state">
                      <div>No payslips issued for your account yet. Payroll is processed monthly by administration.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Modal for Viewing Payslip -->
<div class="modal" id="payslipModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:520px;background:#fff;padding:28px;border-radius:18px;">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;border-bottom:2px solid var(--line);padding-bottom:14px;">
      <div>
        <h2 style="font-size:18px;font-weight:800;color:var(--primary-dark);">PeopleFlow EMS</h2>
        <div style="font-size:12px;color:var(--muted);">Official Monthly Payslip</div>
      </div>
      <button type="button" onclick="closePayslipModal()" style="font-size:22px;cursor:pointer;">×</button>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px;font-size:13px;">
      <div><span style="color:var(--muted);">Employee:</span> <b id="psName"></b></div>
      <div><span style="color:var(--muted);">Pay Period:</span> <b id="psPeriod"></b></div>
      <div><span style="color:var(--muted);">Department:</span> <b id="psDept"></b></div>
      <div><span style="color:var(--muted);">Position:</span> <b id="psPos"></b></div>
    </div>

    <div style="background:var(--bg-soft);border-radius:12px;padding:16px;margin-bottom:18px;font-size:13px;">
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);">
        <span>Basic Salary</span>
        <b id="psBasic"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);color:var(--primary);">
        <span>Allowances & Bonuses</span>
        <b id="psAllow"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);color:var(--danger);">
        <span>Deductions & Taxes</span>
        <b id="psDeduct"></b>
      </div>
      <div style="display:flex;justify-content:space-between;padding:10px 0 4px;font-size:15px;font-weight:800;color:var(--ink);">
        <span>Net Salary Payable</span>
        <b id="psNet" style="color:var(--primary);"></b>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:center;">
      <span style="font-size:11px;color:var(--muted);" id="psGenDate"></span>
      <button type="button" class="primary" onclick="window.print()">Print Payslip</button>
    </div>
  </div>
</div>

<script>
function viewPayslip(pr) {
  document.getElementById('psName').textContent = pr.full_name;
  document.getElementById('psPeriod').textContent = pr.pay_month;
  document.getElementById('psDept').textContent = pr.dept_name || 'General';
  document.getElementById('psPos').textContent = pr.pos_name || 'Employee';
  document.getElementById('psBasic').textContent = 'Rs. ' + parseFloat(pr.basic_salary).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psAllow').textContent = '+Rs. ' + parseFloat(pr.allowances).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psDeduct').textContent = '-Rs. ' + parseFloat(pr.deductions).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psNet').textContent = 'Rs. ' + parseFloat(pr.net_salary).toLocaleString(undefined, {minimumFractionDigits: 2});
  document.getElementById('psGenDate').textContent = 'Generated: ' + pr.generated_at;
  document.getElementById('payslipModal').style.display = 'flex';
}
function closePayslipModal() {
  document.getElementById('payslipModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
