<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'leave';
$root_path = '../';

$employeeId = $_SESSION['employee_id'] ?? 0;
if ($employeeId <= 0) {
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employeeId = (int)$stmt->fetchColumn();
    $_SESSION['employee_id'] = $employeeId;
}

$successMsg = $_GET['success'] ?? '';
$errorMsg = $_GET['error'] ?? '';

// Handle Leave Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $leaveType = trim($_POST['leave_type'] ?? 'Casual Leave');
    $startDate = $_POST['start_date'] ?? '';
    $endDate   = $_POST['end_date'] ?? '';
    $reason    = trim($_POST['reason'] ?? '');

    if (empty($startDate) || empty($endDate) || empty($reason)) {
        $errorMsg = 'Start date, end date, and reason are required.';
    } elseif (strtotime($startDate) > strtotime($endDate)) {
        $errorMsg = 'End date cannot be earlier than start date.';
    } else {
        try {
            $stmt = $pdo->prepare('
                INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status)
                VALUES (?, ?, ?, ?, ?, \'Pending\')
            ');
            $stmt->execute([$employeeId, $leaveType, $startDate, $endDate, $reason]);
            header('Location: leave.php?success=' . urlencode('Leave request submitted successfully. Awaiting admin approval.'));
            exit;
        } catch (PDOException $e) {
            $errorMsg = 'Database error submitting leave request: ' . $e->getMessage();
        }
    }
}

// Fetch employee's own requests
$stmt = $pdo->prepare("
    SELECT 
        id, 
        leave_type, 
        start_date, 
        end_date, 
        DATEDIFF(end_date, start_date) + 1 AS num_days, 
        reason, 
        status, 
        created_at 
    FROM leave_requests 
    WHERE employee_id = ? 
    ORDER BY id DESC
");
$stmt->execute([$employeeId]);
$myRequests = $stmt->fetchAll();

// KPI counts
$pendingCount = 0;
$approvedCount = 0;
$rejectedCount = 0;
foreach ($myRequests as $r) {
    if ($r['status'] === 'Pending') $pendingCount++;
    if ($r['status'] === 'Approved') $approvedCount++;
    if ($r['status'] === 'Rejected') $rejectedCount++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — My Leave Requests</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>My leave requests</h2>
            <p>Apply for time off and review approval status from management.</p>
          </div>
          <button type="button" class="primary" onclick="openApplyModal()">
            <span class="icoPlus"></span>Apply for leave
          </button>
        </div>

        <?php if ($successMsg): ?>
          <div style="background:var(--primary-soft);color:var(--primary-dark);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($successMsg); ?>
          </div>
        <?php endif; ?>

        <?php if ($errorMsg): ?>
          <div style="background:var(--danger-soft);color:var(--danger);padding:12px 16px;border-radius:10px;margin-bottom:16px;font-weight:600;font-size:13px;">
            <?php echo htmlspecialchars($errorMsg); ?>
          </div>
        <?php endif; ?>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--warning);"><?php echo $pendingCount; ?></b>
            <span>Pending approval</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo $approvedCount; ?></b>
            <span>Approved leaves</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--danger);"><?php echo $rejectedCount; ?></b>
            <span>Rejected leaves</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Leave Type</th>
                <th>Dates</th>
                <th>Duration</th>
                <th>Reason</th>
                <th>Status</th>
                <th>Applied On</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($myRequests)): ?>
                <?php foreach ($myRequests as $r): 
                  $badgeClass = ($r['status'] === 'Approved') ? 'present' : (($r['status'] === 'Pending') ? 'warn' : 'leave');
                ?>
                  <tr>
                    <td><b><?php echo htmlspecialchars($r['leave_type']); ?></b></td>
                    <td><?php echo date('M d, Y', strtotime($r['start_date'])); ?> – <?php echo date('M d, Y', strtotime($r['end_date'])); ?></td>
                    <td><?php echo max(1, (int)$r['num_days']); ?> days</td>
                    <td style="max-width:260px;font-size:12.5px;"><?php echo htmlspecialchars($r['reason']); ?></td>
                    <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($r['status']); ?></span></td>
                    <td style="color:var(--muted);font-size:12px;"><?php echo date('M d, Y', strtotime($r['created_at'])); ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6" class="empty-state">You haven't submitted any leave requests yet. Click "Apply for leave" above.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<!-- Modal for Applying for Leave -->
<div class="modal" id="applyModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:50;align-items:center;justify-content:center;">
  <div class="card" style="width:100%;max-width:480px;background:#fff;padding:24px;border-radius:16px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h3 style="font-size:16px;font-weight:700;">Apply for Leave</h3>
      <button type="button" onclick="closeApplyModal()" style="font-size:20px;cursor:pointer;">×</button>
    </div>
    <form method="POST" action="leave.php" class="form">
      <label>Leave Type *
        <select name="leave_type" required>
          <option value="Casual Leave">Casual Leave</option>
          <option value="Sick Leave">Sick Leave</option>
          <option value="Annual Leave">Annual Leave</option>
          <option value="Unpaid Leave">Unpaid Leave</option>
        </select>
      </label>

      <div class="form-row">
        <label>Start Date *
          <input type="date" name="start_date" value="<?php echo date('Y-m-d'); ?>" required>
        </label>
        <label>End Date *
          <input type="date" name="end_date" value="<?php echo date('Y-m-d'); ?>" required>
        </label>
      </div>

      <label>Reason *
        <textarea name="reason" rows="3" placeholder="Explain the reason for your leave request..." required style="border:1px solid var(--line);background:var(--surface);border-radius:10px;padding:10px;width:100%;font-size:13px;"></textarea>
      </label>

      <div class="form-actions" style="margin-top:16px;display:flex;gap:10px;">
        <button type="button" class="secondary" onclick="closeApplyModal()">Cancel</button>
        <button type="submit" class="primary">Submit Application</button>
      </div>
    </form>
  </div>
</div>

<script>
function openApplyModal() {
  document.getElementById('applyModal').style.display = 'flex';
}
function closeApplyModal() {
  document.getElementById('applyModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
