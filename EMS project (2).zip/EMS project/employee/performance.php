<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

$active_page = 'performance';
$root_path = '../';

$employeeId = $_SESSION['employee_id'] ?? 0;
if ($employeeId <= 0) {
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $employeeId = (int)$stmt->fetchColumn();
    $_SESSION['employee_id'] = $employeeId;
}

$stmt = $pdo->prepare("
    SELECT 
        pe.id, 
        pe.review_period, 
        pe.rating, 
        pe.strengths, 
        pe.goals, 
        pe.comments, 
        pe.created_at, 
        creator.full_name AS evaluator_name 
    FROM performance_evaluations pe 
    LEFT JOIN users creator ON pe.created_by = creator.id 
    WHERE pe.employee_id = ? 
    ORDER BY pe.id DESC
");
$stmt->execute([$employeeId]);
$evaluations = $stmt->fetchAll();

$avgRating = 0;
if (count($evaluations) > 0) {
    $sum = array_sum(array_column($evaluations, 'rating'));
    $avgRating = round($sum / count($evaluations), 1);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>EMS — My Performance Evaluations</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="app">
  <?php require_once __DIR__ . '/../includes/employee_sidebar.php'; ?>

  <main class="main">
    <?php require_once __DIR__ . '/../includes/employee_header.php'; ?>

    <section class="content">
      <div class="subpage">
        <div class="subpage-head">
          <div>
            <h2>My performance appraisals</h2>
            <p>Review official evaluations, manager feedback, and career goals.</p>
          </div>
        </div>

        <div class="kpi-row" style="margin-bottom:20px;">
          <div class="mini-kpi">
            <b style="color:var(--primary);"><?php echo count($evaluations); ?></b>
            <span>Total reviews received</span>
          </div>
          <div class="mini-kpi">
            <b style="color:var(--warning);"><?php echo $avgRating ? $avgRating . ' / 5.0' : '—'; ?></b>
            <span>Average rating score</span>
          </div>
        </div>

        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Review Period</th>
                <th>Rating</th>
                <th>Strengths</th>
                <th>Development Goals</th>
                <th>Evaluator Remarks</th>
                <th>Appraiser</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($evaluations)): ?>
                <?php foreach ($evaluations as $ev): 
                  $stars = str_repeat('★', (int)$ev['rating']) . str_repeat('☆', 5 - (int)$ev['rating']);
                ?>
                  <tr>
                    <td><b><?php echo htmlspecialchars($ev['review_period']); ?></b></td>
                    <td>
                      <span style="color:#F0A421;font-size:14px;letter-spacing:1px;"><?php echo $stars; ?></span>
                      <b style="font-size:12px;margin-left:4px;">(<?php echo $ev['rating']; ?>/5)</b>
                    </td>
                    <td style="max-width:200px;font-size:12.5px;"><?php echo !empty($ev['strengths']) ? htmlspecialchars($ev['strengths']) : '—'; ?></td>
                    <td style="max-width:200px;font-size:12.5px;color:var(--muted);"><?php echo !empty($ev['goals']) ? htmlspecialchars($ev['goals']) : '—'; ?></td>
                    <td style="max-width:220px;font-size:12.5px;"><?php echo !empty($ev['comments']) ? htmlspecialchars($ev['comments']) : '—'; ?></td>
                    <td><?php echo htmlspecialchars($ev['evaluator_name'] ?? 'Management'); ?></td>
                    <td style="color:var(--muted);font-size:12px;"><?php echo date('M d, Y', strtotime($ev['created_at'])); ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7">
                    <div class="empty-state">
                      <div>No performance evaluations conducted yet. Performance reviews are generated periodically by administration.</div>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
