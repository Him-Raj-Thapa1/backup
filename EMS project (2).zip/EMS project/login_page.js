// ==========================================================================
// VIEW SWITCHING
// There are 3 top-level right-panel containers:
//   1. Login container    (.login-container)   -> holds BOTH the Admin
//      Login form and the Employee Login form, switched by the tab toggle
//      at the top of the card instead of being separate containers.
//   2. Admin Register     (.register-container)
//   3. Employee Register  (.employee-register-container)
// Only one of these three is ever visible at a time.
// ==========================================================================

function hideAllContainers() {
    const loginCard = document.querySelector('.login-container');
    if (loginCard) loginCard.style.display = 'none';
    const empRegCard = document.querySelector('.employee-register-container');
    if (empRegCard) empRegCard.style.display = 'none';
}

function showLoginContainer() {
    hideAllContainers();
    const loginCard = document.querySelector('.login-container');
    if (loginCard) loginCard.style.display = 'flex';
}

// Employee Register
function showEmployeeRegister() {
    hideAllContainers();
    const empRegCard = document.querySelector('.employee-register-container');
    if (empRegCard) empRegCard.style.display = 'flex';
}

// Employee Register
function showEmployeeRegister() {
    hideAllContainers();
    document.querySelector('.employee-register-container').style.display = 'flex';
}

// ==========================================================================
// LOGIN TAB TOGGLE (Admin Login / Employee Login)
// Switches which form is shown INSIDE the login card, and which tab
// is marked active, without moving/resizing the card itself.
// ==========================================================================

function setActiveLoginTab(role) {
    const adminTab = document.getElementById('tab-admin-login');
    const employeeTab = document.getElementById('tab-employee-login');
    const adminForm = document.getElementById('login-form');
    const employeeForm = document.getElementById('employee-login-form');

    const isAdmin = role === 'admin';

    adminTab.classList.toggle('active', isAdmin);
    employeeTab.classList.toggle('active', !isAdmin);
    adminForm.style.display = isAdmin ? 'block' : 'none';
    employeeForm.style.display = isAdmin ? 'none' : 'block';
}

// Admin Login tab
function showAdminLogin() {
    showLoginContainer();
    setActiveLoginTab('admin');
}

// Employee Login tab
function showEmployeeLogin() {
    showLoginContainer();
    setActiveLoginTab('employee');
}

// Helper to view/hide password (unchanged - works for any field id/icon pair,
// reused by the Admin AND Employee password fields)
function toggleView(fieldId, iconElement) {
    const inputField = document.getElementById(fieldId);
    if (inputField.type === 'password') {
        inputField.type = 'text';
        iconElement.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        inputField.type = 'password';
        iconElement.classList.replace('fa-eye-slash', 'fa-eye');
    }
}

// ==========================================================================
// DYNAMIC FORM HANDLING (talks to PHP/MySQL backend)
// All four forms submit via fetch() instead of a normal page reload,
// so the card layout never flashes/reloads. Each form has a matching
// .form-message div (added in index.php) used to show success/error text.
// ==========================================================================

function showMessage(messageId, text, type) {
    const box = document.getElementById(messageId);
    if (!box) return;
    box.textContent = text;
    box.classList.remove('error', 'success');
    box.classList.add(type);
}

function clearMessage(messageId) {
    const box = document.getElementById(messageId);
    if (!box) return;
    box.textContent = '';
    box.classList.remove('error', 'success');
}

function postForm(url, data) {
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(data)
    }).then(function (res) {
        return res.json();
    });
}

document.addEventListener('DOMContentLoaded', function () {

    // ---------------- ADMIN LOGIN ----------------
    document.getElementById('login-form').addEventListener('submit', function (e) {
        e.preventDefault();
        clearMessage('login-message');

        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('password').value;

        postForm('auth/login.php', { role: 'admin', email: email, password: password })
            .then(function (data) {
                if (data.success) {
                    showMessage('login-message', 'Login successful. Redirecting...', 'success');
                    setTimeout(function () { window.location.href = data.redirect; }, 700);
                } else {
                    showMessage('login-message', data.message, 'error');
                }
            })
            .catch(function () {
                showMessage('login-message', 'Something went wrong. Please try again.', 'error');
            });
    });

    // ---------------- EMPLOYEE LOGIN ----------------
    document.getElementById('employee-login-form').addEventListener('submit', function (e) {
        e.preventDefault();
        clearMessage('employee-login-message');

        const email = document.getElementById('emp-login-email').value.trim();
        const password = document.getElementById('emp-password').value;

        postForm('auth/login.php', { role: 'employee', email: email, password: password })
            .then(function (data) {
                if (data.success) {
                    showMessage('employee-login-message', 'Login successful. Redirecting...', 'success');
                    setTimeout(function () { window.location.href = data.redirect; }, 700);
                } else {
                    showMessage('employee-login-message', data.message, 'error');
                }
            })
            .catch(function () {
                showMessage('employee-login-message', 'Something went wrong. Please try again.', 'error');
            });
    });

    // ---------------- EMPLOYEE REGISTER ----------------
    document.getElementById('employee-register-form').addEventListener('submit', function (e) {
        e.preventDefault();
        clearMessage('employee-register-message');

        const fullname = document.getElementById('emp-fullname').value.trim();
        const email = document.getElementById('emp-email').value.trim();
        const password = document.getElementById('emp-new-password').value;
        const confirmPassword = document.getElementById('emp-confirm-password').value;

        postForm('auth/register.php', {
            role: 'employee',
            fullname: fullname,
            email: email,
            password: password,
            confirm_password: confirmPassword
        })
            .then(function (data) {
                if (data.success) {
                    showMessage('employee-register-message', data.message, 'success');
                    document.getElementById('employee-register-form').reset();
                    setTimeout(showEmployeeLogin, 1200);
                } else {
                    showMessage('employee-register-message', data.message, 'error');
                }
            })
            .catch(function () {
                showMessage('employee-register-message', 'Something went wrong. Please try again.', 'error');
            });
    });

});
