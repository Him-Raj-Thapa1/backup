<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$roleReq  = trim($_POST['role'] ?? '');

if (!$email || !$password) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
    exit;
}

try {
    // Central lookup from users table
    $stmt = $pdo->prepare('SELECT id, full_name, email, password, role FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
        exit;
    }

    $role = $user['role'];

    // ---------------- ADMIN LOGIN ----------------
    if ($role === 'admin') {
        // Fetch or create associated admin profile
        $adminStmt = $pdo->prepare('
            SELECT a.id AS admin_id, a.organization_id, o.name AS organization_name 
            FROM admins a 
            LEFT JOIN organizations o ON o.id = a.organization_id 
            WHERE a.user_id = ? 
            LIMIT 1
        ');
        $adminStmt->execute([$user['id']]);
        $admin = $adminStmt->fetch();

        if (!$admin) {
            $createAdmin = $pdo->prepare('INSERT INTO admins (user_id, organization_id) VALUES (?, 1)');
            $createAdmin->execute([$user['id']]);
            $adminId = (int)$pdo->lastInsertId();
            $orgName = 'PeopleFlow';
        } else {
            $adminId = $admin['admin_id'];
            $orgName = $admin['organization_name'] ?? 'PeopleFlow';
        }

        session_regenerate_id(true);
        $_SESSION['user_id']           = (int)$user['id'];
        $_SESSION['admin_id']          = (int)$adminId;
        $_SESSION['role']              = 'admin';
        $_SESSION['full_name']         = $user['full_name'];
        $_SESSION['email']             = $user['email'];
        $_SESSION['organization_name'] = $orgName;

        echo json_encode(['success' => true, 'redirect' => 'admin/dashboard.php']);
        exit;
    }

    // ---------------- EMPLOYEE LOGIN ----------------
    if ($role === 'employee') {
        // Fetch employee profile
        $empStmt = $pdo->prepare('
            SELECT e.id AS employee_id, e.status, e.department_id, e.position_id, o.name AS organization_name
            FROM employees e 
            LEFT JOIN organizations o ON o.id = e.organization_id 
            WHERE e.user_id = ? 
            LIMIT 1
        ');
        $empStmt->execute([$user['id']]);
        $emp = $empStmt->fetch();

        if (!$emp) {
            // Self-heal: ensure employee row exists
            $insEmp = $pdo->prepare('INSERT INTO employees (user_id, organization_id, status) VALUES (?, 1, \'Active\')');
            $insEmp->execute([$user['id']]);
            $employeeId = (int)$pdo->lastInsertId();
            $status = 'Active';
            $orgName = 'PeopleFlow';
        } else {
            $employeeId = (int)$emp['employee_id'];
            $status = $emp['status'];
            $orgName = $emp['organization_name'] ?? 'PeopleFlow';
        }

        if ($status === 'Inactive') {
            echo json_encode(['success' => false, 'message' => 'Your account has been deactivated. Please contact administration.']);
            exit;
        }

        session_regenerate_id(true);
        $_SESSION['user_id']           = (int)$user['id'];
        $_SESSION['employee_id']       = $employeeId;
        $_SESSION['role']              = 'employee';
        $_SESSION['full_name']         = $user['full_name'];
        $_SESSION['email']             = $user['email'];
        $_SESSION['organization_name'] = $orgName;

        echo json_encode(['success' => true, 'redirect' => 'employee/dashboard.php']);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid account role.']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error during login. Please try again.']);
}
