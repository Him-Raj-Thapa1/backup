<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

$role = trim($_POST['role'] ?? '');

try {
    // ---------------- ADMIN REGISTER DISABLED ----------------
    // Public user registration is strictly limited to employees.
    // Administrator accounts cannot be created publicly to prevent unauthorized admin dashboard access.
    if ($role === 'admin') {
        echo json_encode([
            'success' => false, 
            'message' => 'Admin registration is disabled. Administrator accounts are provisioned internally by system administration.'
        ]);
        exit;
    }

    // ---------------- EMPLOYEE REGISTER ----------------
    if ($role === 'employee') {
        $fullname         = trim($_POST['fullname'] ?? '');
        $email            = trim($_POST['email'] ?? '');
        $password         = $_POST['password'] ?? '';
        $confirmPassword  = $_POST['confirm_password'] ?? '';

        if (!$fullname || !$email || !$password || !$confirmPassword) {
            echo json_encode(['success' => false, 'message' => 'All fields are required.']);
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
            exit;
        }

        if ($password !== $confirmPassword) {
            echo json_encode(['success' => false, 'message' => 'Passwords do not match.']);
            exit;
        }

        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters.']);
            exit;
        }

        $check = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            echo json_encode(['success' => false, 'message' => 'This email is already registered.']);
            exit;
        }

        $pdo->beginTransaction();

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmtUser = $pdo->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, \'employee\')');
        $stmtUser->execute([$fullname, $email, $hashed]);
        $userId = (int)$pdo->lastInsertId();

        // Create linked employee profile
        $stmtEmp = $pdo->prepare('INSERT INTO employees (user_id, organization_id, status) VALUES (?, 1, \'Active\')');
        $stmtEmp->execute([$userId]);

        $pdo->commit();

        echo json_encode(['success' => true, 'message' => 'Employee account created successfully. Please login.']);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid registration request.']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => 'Registration failed due to a database error.']);
}
