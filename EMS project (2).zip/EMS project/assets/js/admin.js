/* ============================= ICONS ============================= */
const ICONS = {
  home:'<path d="M4 10.5 12 4l8 6.5"/><path d="M6 9.5V19a1 1 0 0 0 1 1h3v-5h4v5h3a1 1 0 0 0 1-1V9.5"/>',
  users:'<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.5-3.2 2.8-5 5.5-5s5 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.2 14.3c2.3.3 4 1.9 4.4 4.7"/>',
  check:'<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.3 2.3 4.7-5"/>',
  calendar:'<rect x="4" y="5.5" width="16" height="14.5" rx="2.5"/><path d="M4 10h16M8 3.5v3M16 3.5v3"/>',
  wallet:'<rect x="3.5" y="6.5" width="17" height="12" rx="2.5"/><path d="M15.5 12.5h3M3.5 10h17"/>',
  chart:'<path d="M5 19V11M12 19V5M19 19v-7"/><path d="M3.5 19.5h17"/>',
  building:'<rect x="5" y="3.5" width="10" height="17" rx="1.5"/><path d="M9 8h2M9 12h2M9 16h2M15 10h4v10.5H15"/>',
  briefcase:'<rect x="3.5" y="8" width="17" height="11" rx="2"/><path d="M8.5 8V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v2M3.5 13h17"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2M12 18.5v2M20.5 12h-2M5.5 12h-2M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4M17.7 17.7l-1.4-1.4M7.7 7.7 6.3 6.3"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="M19 19l-4-4"/>',
  bell:'<path d="M6 10.5a6 6 0 0 1 12 0c0 4.2 1.5 5.5 1.5 5.5H4.5S6 14.7 6 10.5Z"/><path d="M10 19a2 2 0 0 0 4 0"/>',
  menu:'<path d="M4 6.5h16M4 12h16M4 17.5h16"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  x:'<path d="M6 6l12 12M18 6 6 18"/>',
  edit:'<path d="M4 19.5l1-4L15.5 5l3.5 3.5L8.5 19H4.5"/><path d="M13.5 6.5L17.5 10"/>',
  trash:'<path d="M5 7h14M9.5 7V5a1.5 1.5 0 0 1 1.5-1.5h2A1.5 1.5 0 0 1 14.5 5v2M7 7l1 12.5A1.5 1.5 0 0 0 9.5 21h5a1.5 1.5 0 0 0 1.5-1.5L17 7"/>',
  eye:'<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.7"/>',
  download:'<path d="M12 4v11.5M8 12l4 4 4-4"/><path d="M4.5 18.5h15v1.5h-15Z"/>',
  clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.2 2"/>',
  inbox:'<path d="M4 12.5h4.2l1.3 2.6h4.9l1.3-2.6H20"/><path d="M5 6.5h14l1.3 6.4V19a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4.3 19v-6.1Z"/>',
  swap:'<path d="M6 8h11l-3-3M18 16H7l3 3"/>'
};

function ic(name, cls){
  return `<svg class="ic ${cls||''}" viewBox="0 0 24 24">${ICONS[name]||''}</svg>`;
}

/* ============================= HELPERS ============================= */
function esc(v){
  return String(v??'').replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

function timeAgo(ts){
  const s = Math.floor((Date.now()-ts)/1000);
  if(s<60) return 'just now';
  const m = Math.floor(s/60); if(m<60) return m+'m ago';
  const h = Math.floor(m/60); if(h<24) return h+'h ago';
  return Math.floor(h/24)+'d ago';
}

function toneColor(tone){
  return {
    primary:['var(--primary-soft)','var(--primary-dark)'],
    warning:['var(--warning-soft)','#966212'],
    info:['var(--info-soft)','#2360c4'],
    danger:['var(--danger-soft)','#b6383c'],
    violet:['var(--violet-soft)','#5c3fd6']
  }[tone] || ['var(--bg-soft)','var(--ink-soft)'];
}

/* ============================= TOASTS ============================= */
function toast(msg, tone){
  const wrap = document.getElementById('toastWrap');
  if(!wrap) return;
  const el = document.createElement('div');
  el.className = 'toast' + (tone?(' '+tone):'');
  el.innerHTML = `<span class="tdot"></span><span>${esc(msg)}</span>`;
  wrap.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('show'));
  setTimeout(()=>{ el.classList.remove('show'); setTimeout(()=>el.remove(),300); }, 2600);
}

/* ============================= MODAL / CONFIRM ============================= */
function openModal(title, bodyHtml, onSubmit){
  const box = document.getElementById('modalBox');
  const modal = document.getElementById('modal');
  if(!box || !modal) return;
  box.innerHTML = `<div class="modal-head"><h2>${esc(title)}</h2><button class="close" data-action="close-modal">${ic('x')}</button></div>${bodyHtml}`;
  modal.classList.add('show');
  window.__modalSubmit = onSubmit || null;
}

function closeModal(){
  const modal = document.getElementById('modal');
  if(modal) modal.classList.remove('show');
  window.__modalSubmit = null;
}

function openConfirm(title, text, onConfirm, danger){
  const box = document.getElementById('confirmBox');
  const backdrop = document.getElementById('confirmBackdrop');
  if(!box || !backdrop) return;
  box.innerHTML = `
    <div class="aicon" style="background:${danger?'var(--danger-soft)':'var(--warning-soft)'};color:${danger?'#b6383c':'#966212'}">${ic(danger?'trash':'clock')}</div>
    <h3>${esc(title)}</h3><p>${esc(text)}</p>
    <div class="confirm-actions"><button class="secondary" data-action="close-confirm">Cancel</button><button class="${danger?'danger-btn':'primary'}" data-action="confirm-ok">Confirm</button></div>`;
  backdrop.classList.add('show');
  window.__confirmFn = onConfirm;
}

function closeConfirm(){
  const backdrop = document.getElementById('confirmBackdrop');
  if(backdrop) backdrop.classList.remove('show');
  window.__confirmFn = null;
}

/* ============================= CHARTS ============================= */
function smoothPath(points){
  if(!points || points.length === 0) return '';
  let d = `M${points[0][0]},${points[0][1]}`;
  for(let i=1;i<points.length;i++){
    const [x0,y0]=points[i-1], [x1,y1]=points[i];
    d += ` Q${x0},${y0} ${(x0+x1)/2},${(y0+y1)/2}`;
  }
  const last = points[points.length-1];
  d += ` L${last[0]},${last[1]}`;
  return d;
}

const DEFAULT_WEEKLY = {
  week:[74,77,71,80,76,68,0],
  month:[73,78,75,82],
  year:[70,72,75,74,78,80,77,79,81,76,78,0]
};

function getCounts(){
  if(window.DASHBOARD_COUNTS) {
    return window.DASHBOARD_COUNTS;
  }
  return {total:0, present:0, leave:0, absent:0, rate:0};
}

function renderAreaChart(){
  const chartEl = document.getElementById('areaChart');
  const periodEl = document.getElementById('chartPeriod');
  if(!chartEl) return;
  
  const period = periodEl ? periodEl.value : 'week';
  let data;
  let labels;
  if (period === 'week' && window.WEEKLY_DATA && window.WEEKLY_DATA.length > 0) {
    data = window.WEEKLY_DATA.slice();
    labels = window.WEEKLY_LABELS ? window.WEEKLY_LABELS.slice() : ['Mon','Tue','Wed','Thu','Fri','Sat','Today'];
  } else {
    data = (period==='week' ? DEFAULT_WEEKLY.week.slice() : period==='month' ? DEFAULT_WEEKLY.month.slice() : DEFAULT_WEEKLY.year.slice());
    const c = getCounts();
    data[data.length-1] = c.rate || 0;
    labels = period==='week' ? ['Mon','Tue','Wed','Thu','Fri','Sat','Today']
      : period==='month' ? ['Wk 1','Wk 2','Wk 3','Now']
      : ['J','F','M','A','M','J','J','A','S','O','N','Now'];
  }
  
  const w=700, h=220, pad=40, top=20, bot=40;
  const max=100, min=0;
  const step = (w-pad-20)/(data.length-1);
  const pts = data.map((v,i)=>[pad+i*step, top + (h-top-bot)*(1-(v-min)/(max-min))]);
  
  const gridLines = [0,25,50,75,100].map(pct=>{
    const y = top + (h-top-bot)*(1-pct/100);
    return `<line class="chart-grid" x1="${pad}" y1="${y}" x2="${w-10}" y2="${y}"/><text x="6" y="${y+3}" class="axis">${pct}</text>`;
  }).join('');
  
  const linePath = smoothPath(pts);
  const areaPath = linePath + ` L${pts[pts.length-1][0]},${h-bot} L${pts[0][0]},${h-bot} Z`;
  const dots = pts.map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#fff" stroke="var(--primary)" stroke-width="2"/>`).join('');
  const labelsSvg = pts.map((p,i)=>`<text x="${p[0]}" y="${h-14}" class="axis" text-anchor="middle">${labels[i]||''}</text>`).join('');
  
  chartEl.innerHTML = `
    <defs><linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="var(--primary)" stop-opacity="0.22"/><stop offset="100%" stop-color="var(--primary)" stop-opacity="0"/></linearGradient></defs>
    ${gridLines}
    <path d="${areaPath}" fill="url(#areaGrad)"/>
    <path d="${linePath}" fill="none" stroke="var(--primary)" stroke-width="3" stroke-linecap="round"/>
    ${dots}${labelsSvg}`;
}

function renderRing(){
  const ringChart = document.getElementById('ringChart');
  const ringText = document.getElementById('ringText');
  const breakdown = document.getElementById('attBreakdown');
  if(!ringChart) return;
  
  const c = getCounts();
  const r=54, cx=75, cy=75, circ = 2*Math.PI*r, sw=14;
  const total = c.total || 0;
  
  const segs = [
    {v:c.present, color:'var(--primary)'},
    {v:c.leave, color:'var(--warning)'},
    {v:c.absent, color:'var(--danger)'}
  ];
  
  let offset = 0;
  const arcs = total > 0 ? segs.map(s=>{
    const len = circ * (s.v/total);
    const dash = `${len} ${circ-len}`;
    const el = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${s.color}" stroke-width="${sw}" stroke-dasharray="${dash}" stroke-dashoffset="${-offset}" stroke-linecap="round" transform="rotate(-90 ${cx} ${cy})"/>`;
    offset += len + (total>1?2:0);
    return el;
  }).join('') : '';
  
  ringChart.innerHTML = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="var(--bg-soft)" stroke-width="${sw}"/>${arcs}`;
  if(ringText) ringText.innerHTML = `<b>${c.rate}%</b><span>Present</span>`;
  if(breakdown) {
    breakdown.innerHTML = `
      <div class="att-row"><div><div class="att-name">Present</div><div class="bar"><i style="width:${total?c.present/total*100:0}%;background:var(--primary)"></i></div></div><b>${c.present}</b></div>
      <div class="att-row"><div><div class="att-name">On leave</div><div class="bar"><i style="width:${total?c.leave/total*100:0}%;background:var(--warning)"></i></div></div><b>${c.leave}</b></div>
      <div class="att-row"><div><div class="att-name">Absent</div><div class="bar"><i style="width:${total?c.absent/total*100:0}%;background:var(--danger)"></i></div></div><b>${c.absent}</b></div>`;
  }
}

/* ============================= NOTIFICATIONS DRAWER ============================= */
function openNotifications(){
  const backdrop = document.getElementById('notifBackdrop');
  const notifList = document.getElementById('notifList');
  if(!backdrop) return;
  if(notifList) {
    notifList.innerHTML = `<div class="empty-note">You're all caught up.</div>`;
  }
  backdrop.classList.add('show');
}

function closeNotifications(){
  const backdrop = document.getElementById('notifBackdrop');
  if(backdrop) backdrop.classList.remove('show');
}

function clearNotifications(){
  const notifDot = document.getElementById('notifDot');
  if(notifDot) notifDot.style.display = 'none';
  openNotifications();
  toast('Notifications cleared');
}

/* ============================= ACTION DISPATCH ============================= */
const ACTIONS = {
  'toggle-sidebar': ()=> {
    const sidebar = document.getElementById('sidebar');
    if(sidebar) sidebar.classList.toggle('open');
  },
  'help': ()=> toast('Help center: For assistance, contact the system administrator.'),
  'open-notifications': ()=> openNotifications(),
  'close-notifications': ()=> closeNotifications(),
  'clear-notifications': ()=> clearNotifications(),
  'close-modal': ()=> closeModal(),
  'modal-submit': ()=> { if(window.__modalSubmit) window.__modalSubmit(); },
  'close-confirm': ()=> closeConfirm(),
  'confirm-ok': ()=> { const fn = window.__confirmFn; closeConfirm(); if(fn) fn(); },
  'chart-period': ()=> renderAreaChart()
};

document.addEventListener('click', e=>{
  const btn = e.target.closest('[data-action]');
  if(!btn) return;
  const action = btn.dataset.action;
  if(ACTIONS[action]) {
    ACTIONS[action](btn, btn.dataset.id, e);
  }
});

document.addEventListener('change', e=>{
  const el = e.target.closest('[data-action]');
  if(!el || !(el.tagName==='SELECT'||el.tagName==='INPUT')) return;
  const action = el.dataset.action;
  if(ACTIONS[action]) {
    ACTIONS[action](el, el.dataset.id, e);
  }
});

document.addEventListener('DOMContentLoaded', ()=>{
  const menuBtn = document.querySelector('.menu');
  if(menuBtn) menuBtn.innerHTML = ic('menu');
  
  const searchSpan = document.querySelector('.search span');
  if(searchSpan) searchSpan.innerHTML = ic('search');
  
  const bellIcon = document.getElementById('bellIcon');
  if(bellIcon) bellIcon.innerHTML = ic('bell');
  
  document.querySelectorAll('.icoPlus').forEach(e=>e.innerHTML=ic('plus'));
  document.querySelectorAll('.icoCheck').forEach(e=>e.innerHTML=ic('check'));
  document.querySelectorAll('.icoWallet').forEach(e=>e.innerHTML=ic('wallet'));

  // Render Charts if on dashboard
  renderAreaChart();
  renderRing();
});

document.addEventListener('keydown', e=>{
  if(e.key==='Escape'){ closeModal(); closeConfirm(); closeNotifications(); }
});
