
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>new design</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="login_style.css">
    <script src="login_page.js" defer></script>
</head>
<body>
    <!--This is new design-->
    <div class="main-container">
        <div class="EMS-container">
        <i class="fa-solid fa-users-gear logo"></i>
        <h2>EMS</h2>
        <p class="EMS-fullform">Employee Management System</p>
        <p class="description">
        A complete solution to manage employee information,
        departments and organizational data efficiently.</p>
        <p class="footer">
        <i class="fa-solid fa-graduation-cap"></i>
        BCA 4th Semester Project (TU)</p>
        </div>

        <!--This is the combined Login side. Admin Login and Employee Login
        now live in the SAME card and are switched with a top tab toggle
        instead of separate links/containers.-->
    <div class="login-container" id="login-container">
     <div class="login-card">
        <div class="lock-icon">
            <i class="fa-solid fa-shield-halved"></i>
        </div>

        <!--Tab toggle: replaces the old "Are you an Employee?" links-->
        <div class="login-tabs">
            <button type="button" class="login-tab active" id="tab-admin-login" onclick="showAdminLogin()">Admin</button>
            <button type="button" class="login-tab" id="tab-employee-login" onclick="showEmployeeLogin()">Employee</button>
        </div>

        <!--Admin Login form (visible by default)-->
        <form id="login-form">
         <div class="form-message" id="login-message"></div>
         <div class="form-group">
            <label>Email Address</label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-envelope input-field-icon"></i>
                    <input type="email" id="login-email" placeholder="Enter email address" required>
                </div>
         </div>
         <div class="form-group">
                <div class="pass">
                    <label>Password</label>
                    <a href="#" class="forgot-link">Forgot?</a>
                </div>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-field-icon"></i>
                    <input type="password" id="password" placeholder="Enter password" required>
                    <i class="fa-solid fa-eye toggle-password" onclick="toggleView('password', this)"></i>
                </div>
            </div>
         <div class="remember-me">
                <input type="checkbox" id="rememberMe">
                <label for="rememberMe">Remember me</label>
            </div>
        <button type="submit" class="login-btn">
                <i class="fa-solid fa-lock"></i> Login
            </button>
            <p class="register-btn" style="color: #8B9A90; font-size: 11.5px; margin-top: 14px;">
                Administrator access is restricted to authorized personnel.
            </p>
        </form>

        <!--Employee Login form (hidden by default)-->
        <form id="employee-login-form" style="display:none;">
         <div class="form-message" id="employee-login-message"></div>
         <div class="form-group">
            <label>Email Address</label>
                <div class="input-wrapper">
                    <i class="fa-solid fa-envelope input-field-icon"></i>
                    <input type="email" id="emp-login-email" placeholder="Enter email address" required>
                </div>
         </div>
         <div class="form-group">
                <div class="pass">
                    <label>Password</label>
                    <a href="#" class="forgot-link">Forgot?</a>
                </div>
                <div class="input-wrapper">
                    <i class="fa-solid fa-lock input-field-icon"></i>
                    <input type="password" id="emp-password" placeholder="Enter password" required>
                    <i class="fa-solid fa-eye toggle-password" onclick="toggleView('emp-password', this)"></i>
                </div>
            </div>
         <div class="remember-me">
                <input type="checkbox" id="empRememberMe">
                <label for="empRememberMe">Remember me</label>
            </div>
        <button type="submit" class="login-btn">
                <i class="fa-solid fa-lock"></i> Login
            </button>
            <p class="register-btn">Don't have an account?
            <a href="#" onclick="showEmployeeRegister()">Register as Employee</a>
            </p>
        </form>

        <div class="card-footer">
            © 2026 Employee Management System
        </div>
     </div>
    </div>

    <!--This is Employee Register side-->
    <div class="employee-register-container" id="employee-register-container">
        <div class="register-card">
            <div class="add-icon">
                <i class="fa-solid fa-user-plus"></i>
            </div>
            <h2>Employee Register</h2>
     <!--This is employee register-form-->
            <form id="employee-register-form">
    <div class="form-message" id="employee-register-message"></div>
    <div class="form-group">
     <label>Full Name</label>
       <div class="input-wrapper">
            <i class="fa-solid fa-user input-field-icon"></i>
               <input type="text" id="emp-fullname" placeholder="Enter your full name" required>
        </div>
    </div>
    <div class="form-group">
        <label>Email Address</label>
        <div class="input-wrapper">
            <i class="fa-solid fa-envelope input-field-icon"></i>
            <input type="email" id="emp-email" placeholder="Enter email address" required>
        </div>
    </div>
    <div class="form-group">
        <label>Password</label>
        <div class="input-wrapper">
            <i class="fa-solid fa-lock input-field-icon"></i>
            <input type="password" id="emp-new-password" placeholder="Enter password" required>
            <i class="fa-solid fa-eye toggle-password" onclick="toggleView('emp-new-password',this)"></i>
        </div>
    </div>
    <div class="form-group">
        <label>Confirm Password</label>
        <div class="input-wrapper">
        <i class="fa-solid fa-key input-field-icon"></i>
        <input type="password" id="emp-confirm-password" placeholder="Confirm password" required>
        <i class="fa-solid fa-eye toggle-password" onclick="toggleView('emp-confirm-password',this)"></i>
        </div>
    </div>
    <button type="submit" class="register">
        <i class="fa-solid fa-user-check"></i>Register
    </button>
    <p class="switch-text">Already have an account?
        <a href="#" onclick="showEmployeeLogin()">Login</a>
    </p>
    </form>
       <div class="footer">
        © 2026 Employee Management System
           </div>
      </div>
   </div>

</div>
</body>
</html>